const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('nookletDesktop', {
  translateInterfaceText: (text, language) => ipcRenderer.invoke('nooklet:translate-interface', text, language),
  checkForUpdates: () => ipcRenderer.invoke('nooklet:check-for-updates'),
  installUpdate: () => ipcRenderer.invoke('nooklet:install-update'),
});
