const { app, BrowserWindow, protocol, ipcMain, net, shell } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const extractZip = require('extract-zip');

const distPath = path.resolve(__dirname, '..', 'dist');
const updatesPath = path.join(app.getPath('userData'), 'ui-updates');
const repo = 'krgkonekpro04-cpu/Nooklet';
let pendingUpdate = null;
let activeDistPath = distPath;
const supportedLanguages = new Set(['es', 'zh-CN', 'hi', 'ar', 'pt', 'bn', 'ru', 'ja', 'fr', 'de', 'ur', 'id', 'tr', 'ko', 'vi', 'it', 'pl', 'fa', 'sw']);

function compareVersions(left, right) {
  const parse = (version) => version.replace(/^v/, '').split(/[.+-]/).map((part) => /^\d+$/.test(part) ? Number(part) : part);
  const a = parse(left); const b = parse(right);
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const x = a[i] ?? 0; const y = b[i] ?? 0;
    if (x === y) continue;
    if (typeof x === 'number' && typeof y === 'number') return x > y ? 1 : -1;
    if (typeof x === 'number') return 1;
    if (typeof y === 'number') return -1;
    return String(x).localeCompare(String(y));
  }
  return 0;
}

async function getRelease() {
  const response = await net.fetch(`https://api.github.com/repos/${repo}/releases?per_page=20`, {
    headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'Nooklet-Desktop' },
  });
  if (!response.ok) throw new Error(`Release lookup failed (${response.status})`);
  const releases = await response.json();
  const release = releases.find((candidate) => !candidate.draft);
  if (!release) throw new Error('No Nooklet release is published yet.');
  return release;
}

ipcMain.handle('nooklet:check-for-updates', async () => {
  try {
    const release = await getRelease();
    const version = String(release.tag_name || '').replace(/^v/, '');
    if (!version) throw new Error('The release has no version tag.');
    const current = app.getVersion();
    if (compareVersions(version, current) <= 0) return { status: 'up-to-date', currentVersion: current };
    const zip = release.assets?.find((asset) => asset.name === 'nooklet-ui.zip');
    const checksum = release.assets?.find((asset) => asset.name === 'nooklet-ui.zip.sha256');
    if (!zip || !checksum) throw new Error('This release does not include an installable Nooklet interface update.');
    const [zipResponse, hashResponse] = await Promise.all([
      net.fetch(zip.browser_download_url, { headers: { 'User-Agent': 'Nooklet-Desktop' } }),
      net.fetch(checksum.browser_download_url, { headers: { 'User-Agent': 'Nooklet-Desktop' } }),
    ]);
    if (!zipResponse.ok || !hashResponse.ok) throw new Error('The update download failed.');
    const archive = Buffer.from(await zipResponse.arrayBuffer());
    const expectedHash = (await hashResponse.text()).trim().split(/\s+/)[0].toLowerCase();
    const actualHash = crypto.createHash('sha256').update(archive).digest('hex');
    if (!/^[a-f0-9]{64}$/.test(expectedHash) || actualHash !== expectedHash) throw new Error('The update failed its integrity check.');
    await fs.mkdir(updatesPath, { recursive: true });
    const staged = path.join(updatesPath, `${version}.staged`);
    const ready = path.join(updatesPath, version);
    await fs.rm(staged, { recursive: true, force: true });
    await fs.mkdir(staged, { recursive: true });
    const zipPath = path.join(updatesPath, `nooklet-ui-${version}.zip`);
    await fs.writeFile(zipPath, archive);
    try {
      await extractZip(zipPath, { dir: staged });
    } finally {
      await fs.rm(zipPath, { force: true });
    }
    await fs.access(path.join(staged, 'index.html'));
    await fs.rm(ready, { recursive: true, force: true });
    await fs.rename(staged, ready);
    pendingUpdate = { version, directory: ready };
    return { status: 'available', currentVersion: current, version };
  } catch (error) {
    return { status: 'error', currentVersion: app.getVersion(), message: error instanceof Error ? error.message : 'Update check failed.' };
  }
});

ipcMain.handle('nooklet:install-update', async () => {
  if (!pendingUpdate) return { status: 'error', message: 'There is no downloaded update to install.' };
  const activeFile = path.join(updatesPath, 'active-ui.json');
  await fs.writeFile(`${activeFile}.tmp`, JSON.stringify({ version: pendingUpdate.version }));
  await fs.rename(`${activeFile}.tmp`, activeFile);
  activeDistPath = pendingUpdate.directory;
  pendingUpdate = null;
  for (const window of BrowserWindow.getAllWindows()) window.reload();
  return { status: 'installed' };
});

ipcMain.handle('nooklet:translate-interface', async (_event, text, language) => {
  if (typeof text !== 'string' || text.length > 240 || typeof language !== 'string' || !supportedLanguages.has(language)) return null;
  const query = new URLSearchParams({ client: 'gtx', sl: 'en', tl: language, dt: 't', q: text });
  try {
    const response = await net.fetch(`https://translate.googleapis.com/translate_a/single?${query.toString()}`);
    if (!response.ok) return null;
    const payload = await response.json();
    return payload[0]?.map((part) => part[0]).join('').trim() || null;
  } catch {
    return null;
  }
});

protocol.registerSchemesAsPrivileged([
  { scheme: 'nooklet', privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true } },
]);

function registerAppProtocol() {
  protocol.handle('nooklet', async (request) => {
    const requestUrl = new URL(request.url);
    if (requestUrl.host !== 'app') {
      return new Response('Not found', { status: 404 });
    }

    const requestedPath = decodeURIComponent(requestUrl.pathname);
    const filePath = path.resolve(activeDistPath, `.${requestedPath}`);
    if (filePath !== activeDistPath && !filePath.startsWith(`${activeDistPath}${path.sep}`)) {
      return new Response('Forbidden', { status: 403 });
    }

    try {
      const body = await fs.readFile(filePath);
      const contentTypes = {
        '.css': 'text/css; charset=utf-8',
        '.html': 'text/html; charset=utf-8',
        '.ico': 'image/x-icon',
        '.js': 'text/javascript; charset=utf-8',
        '.json': 'application/json; charset=utf-8',
        '.svg': 'image/svg+xml',
      };
      return new Response(body, {
        headers: { 'Content-Type': contentTypes[path.extname(filePath)] || 'application/octet-stream' },
      });
    } catch {
      return new Response('Not found', { status: 404 });
    }
  });
}

function createWindow() {
  const window = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 760,
    minHeight: 600,
    title: 'Nooklet',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.cjs'),
    },
  });

  window.webContents.setWindowOpenHandler(({ url }) => {
    try {
      const destination = new URL(url);
      if (destination.protocol === 'https:' || destination.protocol === 'http:') void shell.openExternal(destination.toString());
    } catch { /* Block malformed and non-web URLs. */ }
    return { action: 'deny' };
  });

  window.loadURL('nooklet://app/index.html');
}

app.whenReady().then(() => {
  fs.readFile(path.join(updatesPath, 'active-ui.json'), 'utf8').then(async (contents) => {
    const { version } = JSON.parse(contents);
    const candidate = path.join(updatesPath, version);
    await fs.access(path.join(candidate, 'index.html'));
    activeDistPath = candidate;
  }).catch(() => {}).finally(() => {
    registerAppProtocol();
    createWindow();
  });
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
