# Nooklet

Nooklet is a small-forums app for macOS and Windows.

## Updates

Nooklet checks the public releases in this repository when it opens. When a newer interface bundle is available, choose **Install update** in the app. Your sign-in and saved local forums remain in the app's data folder.

Each release builds and publishes `nooklet-ui.zip` and its SHA-256 checksum automatically. GitHub Actions needs the existing Supabase client settings as repository Actions secrets named `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`; these are intentionally kept out of the public source archive. Once configured, a version tag beginning with `v` (for example, `v0.2.0-alpha.11`) builds the interface and attaches both update files to the release.

The in-app updater replaces the interface bundle. Changes to Electron itself or its secure desktop bridge still require a new macOS or Windows app package.

## Developer setup

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and set the Supabase URL and public anonymous key for your own backend.
3. Run `npm ci` and then `npm run desktop:dev`.

The `.env` file is ignored by Git and must never be added to a release.
