# Nooklet

Nooklet is a small-forums app for macOS and Windows.

## Updates

Nooklet checks the public releases in this repository when it opens. When a newer interface bundle is available, choose **Install update** in the app. Your sign-in and saved local forums remain in the app's data folder.

Each release publishes `nooklet-ui.zip` and its SHA-256 checksum automatically. Before a release, build the interface locally using your private `.env`, then refresh `nooklet-source.zip` with the source and compiled `dist` folder. Commit that archive and push a version tag beginning with `v` (for example, `v0.2.0-alpha.11`). GitHub Actions attaches the prebuilt interface bundle and checksum to the release. The raw `.env` file is never included.

The in-app updater replaces the interface bundle. Changes to Electron itself or its secure desktop bridge still require a new macOS or Windows app package.

## Developer setup

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and set the Supabase URL and public anonymous key for your own backend.
3. Run `npm ci` and then `npm run desktop:dev`.

The `.env` file is ignored by Git and must never be added to a release.
