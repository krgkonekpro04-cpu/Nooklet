module.exports = {
  packagerConfig: {
    asar: true,
    name: 'Nooklet',
    appBundleId: 'com.nooklet.forums',
    icon: 'assets/nooklet.icns',
    ignore: [/\/\.env$/],
  },
  makers: [
    {
      name: '@electron-forge/maker-zip',
      platforms: ['darwin', 'win32'],
    },
  ],
};
