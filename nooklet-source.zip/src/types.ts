export interface CurrentWeather {
  time?: string;
  temperature_2m: number;
  relative_humidity_2m: number;
  apparent_temperature: number;
  precipitation: number;
  weather_code: number;
  wind_speed_10m: number;
  wind_direction_10m: number;
  pressure_msl: number;
  cloud_cover: number;
  uv_index: number;
}

export interface HourlyForecast {
  time: string[];
  temperature_2m: number[];
  weather_code: number[];
  precipitation_probability: number[];
}

export interface DailyForecast {
  time: string[];
  weather_code: number[];
  temperature_2m_max: number[];
  temperature_2m_min: number[];
  precipitation_sum: number[];
  precipitation_probability_max: number[];
  wind_speed_10m_max: number[];
  uv_index_max: number[];
  sunrise: string[];
  sunset: string[];
}

export interface WeatherResponse {
  current: CurrentWeather;
  hourly: HourlyForecast;
  daily: DailyForecast;
  timezone: string;
}

export interface GeoResult {
  lat: number;
  lon: number;
  name: string;
  country: string;
  admin1?: string;
}

export interface MemeReaction {
  emoji: string;
  count: number;
}

export interface WeatherMeme {
  id: string;
  title: string;
  caption: string;
  imageUrl: string;
  overlayText: string[];
  reactions: string[];
  vibe: string;
}
