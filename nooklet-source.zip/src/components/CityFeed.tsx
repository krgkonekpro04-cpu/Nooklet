import { useState, useEffect, useCallback, useRef } from "react";
import { WeatherSlide, type CitySlideData } from "@/components/WeatherSlide";
import type { GeoResult } from "@/types";
import type { LanguageCode } from "@/lib/i18n";
import type { TempUnit } from "@/lib/temperature";
import { getWeather } from "@/lib/weather";
import { Loader2 } from "lucide-react";

const FEED_CITIES: { name: string; lat: number; lon: number; country: string; admin1?: string }[] = [
  { name: "Tokyo", lat: 35.6762, lon: 139.6503, country: "Japan", admin1: "Tokyo" },
  { name: "New York", lat: 40.7128, lon: -74.006, country: "United States", admin1: "NY" },
  { name: "London", lat: 51.5074, lon: -0.1278, country: "United Kingdom", admin1: "England" },
  { name: "Paris", lat: 48.8566, lon: 2.3522, country: "France", admin1: "Île-de-France" },
  { name: "Sydney", lat: -33.8688, lon: 151.2093, country: "Australia", admin1: "NSW" },
  { name: "Dubai", lat: 25.2048, lon: 55.2708, country: "UAE", admin1: "Dubai" },
  { name: "Reykjavik", lat: 64.1466, lon: -21.9426, country: "Iceland", admin1: "Capital Region" },
  { name: "Singapore", lat: 1.3521, lon: 103.8198, country: "Singapore" },
  { name: "Rio de Janeiro", lat: -22.9068, lon: -43.1729, country: "Brazil", admin1: "RJ" },
  { name: "Moscow", lat: 55.7558, lon: 37.6173, country: "Russia", admin1: "Moscow" },
  { name: "Cairo", lat: 30.0444, lon: 31.2357, country: "Egypt", admin1: "Cairo" },
  { name: "Mumbai", lat: 19.076, lon: 72.8777, country: "India", admin1: "Maharashtra" },
  { name: "Toronto", lat: 43.6532, lon: -79.3832, country: "Canada", admin1: "ON" },
  { name: "Cape Town", lat: -33.9249, lon: 18.4241, country: "South Africa", admin1: "WC" },
  { name: "Bangkok", lat: 13.7563, lon: 100.5018, country: "Thailand" },
  { name: "Buenos Aires", lat: -34.6037, lon: -58.3816, country: "Argentina" },
  { name: "Seoul", lat: 37.5665, lon: 126.978, country: "South Korea" },
  { name: "Istanbul", lat: 41.0082, lon: 28.9784, country: "Turkey", admin1: "Istanbul" },
  { name: "Lagos", lat: 6.5244, lon: 3.3792, country: "Nigeria", admin1: "Lagos" },
  { name: "Mexico City", lat: 19.4326, lon: -99.1332, country: "Mexico", admin1: "CDMX" },
  { name: "Berlin", lat: 52.52, lon: 13.405, country: "Germany", admin1: "Berlin" },
  { name: "Nairobi", lat: -1.2921, lon: 36.8219, country: "Kenya", admin1: "Nairobi" },
  { name: "Anchorage", lat: 61.2181, lon: -149.9003, country: "United States", admin1: "AK" },
  { name: "Hanoi", lat: 21.0285, lon: 105.8542, country: "Vietnam" },
  { name: "Stockholm", lat: 59.3293, lon: 18.0686, country: "Sweden", admin1: "Stockholm" },
  { name: "Lima", lat: -12.0464, lon: -77.0428, country: "Peru", admin1: "Lima" },
  { name: "Tehran", lat: 35.6892, lon: 51.389, country: "Iran", admin1: "Tehran" },
  { name: "Jakarta", lat: -6.2088, lon: 106.8456, country: "Indonesia" },
  { name: "Helsinki", lat: 60.1699, lon: 24.9384, country: "Finland", admin1: "Uusimaa" },
  { name: "Athens", lat: 37.9838, lon: 23.7275, country: "Greece", admin1: "Attica" },
];

interface CityFeedProps {
  uiLang: LanguageCode;
  memeLang: LanguageCode;
  unit: TempUnit;
  initialCity?: GeoResult | null;
}

let slideIdCounter = 0;

export function CityFeed({ uiLang, memeLang, unit, initialCity }: CityFeedProps) {
  const [slides, setSlides] = useState<CitySlideData[]>([]);
  const [feedIndex, setFeedIndex] = useState(0);
  const loadingMoreRef = useRef(false);
  const feedIndexRef = useRef(0);

  useEffect(() => {
    feedIndexRef.current = feedIndex;
  }, [feedIndex]);

  useEffect(() => {
    const initial: CitySlideData[] = [];
    if (initialCity) {
      initial.push({
        id: `slide-${slideIdCounter++}`,
        geo: initialCity,
        weather: null,
        loading: true,
        error: null,
      });
    }
    for (let i = 0; i < 2; i++) {
      const city = FEED_CITIES[i] ?? FEED_CITIES[i % FEED_CITIES.length];
      initial.push({
        id: `slide-${slideIdCounter++}`,
        geo: { name: city.name, lat: city.lat, lon: city.lon, country: city.country, admin1: city.admin1 },
        weather: null,
        loading: true,
        error: null,
      });
    }
    setSlides(initial);
    setFeedIndex(initial.length);
    feedIndexRef.current = initial.length;
    initial.forEach((s) => fetchWeatherForSlide(s));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const fetchWeatherForSlide = useCallback(async (slide: CitySlideData) => {
    try {
      const data = await getWeather(slide.geo.lat, slide.geo.lon);
      setSlides((prev) =>
        prev.map((s) => (s.id === slide.id ? { ...s, weather: data, loading: false } : s))
      );
    } catch (err) {
      setSlides((prev) =>
        prev.map((s) =>
          s.id === slide.id
            ? { ...s, loading: false, error: err instanceof Error ? err.message : "Failed" }
            : s
        )
      );
    }
  }, []);

  const addMoreSlides = useCallback(() => {
    if (loadingMoreRef.current) return;
    loadingMoreRef.current = true;

    const currentIdx = feedIndexRef.current;
    const newSlides: CitySlideData[] = [];
    for (let i = 0; i < 3; i++) {
      const idx = (currentIdx + i) % FEED_CITIES.length;
      const city = FEED_CITIES[idx];
      const newSlide: CitySlideData = {
        id: `slide-${slideIdCounter++}`,
        geo: { name: city.name, lat: city.lat, lon: city.lon, country: city.country, admin1: city.admin1 },
        weather: null,
        loading: true,
        error: null,
      };
      newSlides.push(newSlide);
      fetchWeatherForSlide(newSlide);
    }

    setFeedIndex((prev) => prev + 3);
    feedIndexRef.current = currentIdx + 3;
    setSlides((prev) => [...prev, ...newSlides]);

    setTimeout(() => {
      loadingMoreRef.current = false;
    }, 500);
  }, [fetchWeatherForSlide]);

  const handleRemove = useCallback((id: string) => {
    setSlides((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length < 3) {
        setTimeout(() => addMoreSlides(), 100);
      }
      return filtered;
    });
  }, [addMoreSlides]);

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const scrollTop = el.scrollTop;
    const scrollHeight = el.scrollHeight;
    const clientHeight = el.clientHeight;
    if (scrollHeight - scrollTop - clientHeight < clientHeight * 1.5) {
      addMoreSlides();
    }
  }, [addMoreSlides]);

  return (
    <div
      className="h-full overflow-y-auto snap-y snap-mandatory scroll-smooth"
      onScroll={handleScroll}
    >
      {slides.map((slide) => (
        <div key={slide.id} className="h-screen w-full snap-start">
          <WeatherSlide slide={slide} uiLang={uiLang} memeLang={memeLang} unit={unit} onRemove={handleRemove} />
        </div>
      ))}

      <div className="h-32 flex items-center justify-center">
        <Loader2 className="w-6 h-6 text-cyan-400 animate-spin" />
      </div>
    </div>
  );
}
