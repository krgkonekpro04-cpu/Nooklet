interface LogoProps {
  className?: string;
  size?: number;
}

export function Logo({ className = "", size = 48 }: LogoProps) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className} role="img" aria-label="Nooklet logo">
      <rect x="5" y="6" width="28" height="26" rx="9" fill="#DDEBDD" />
      <path d="M12 32v6l7-6" fill="#DDEBDD" />
      <rect x="15" y="15" width="28" height="25" rx="9" fill="#315D3D" />
      <path d="M35 40v5l-7-5" fill="#315D3D" />
      <circle cx="23" cy="27.5" r="1.8" fill="#F7F6F2" />
      <circle cx="29" cy="27.5" r="1.8" fill="#F7F6F2" />
      <circle cx="35" cy="27.5" r="1.8" fill="#F7F6F2" />
      <path d="M12 16h13" stroke="#78977A" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M12 22h7" stroke="#78977A" strokeWidth="2.2" strokeLinecap="round" />
    </svg>
  );
}
