import { useState, useEffect, useCallback } from "react";
import { Flame, RefreshCw } from "lucide-react";
import type { CurrentWeather } from "@/types";
import { getCondition } from "@/lib/memes";
import { formatTemp, type TempUnit } from "@/lib/temperature";
import { playSound } from "@/lib/sounds";

interface WeatherRoastProps {
  current: CurrentWeather;
  location: string;
  unit: TempUnit;
}

function generateRoast(current: CurrentWeather, location: string, unit: TempUnit, previous = ""): string {
  const temp = current.apparent_temperature;
  const condition = getCondition(current.weather_code);
  const humidity = current.relative_humidity_2m;
  const wind = current.wind_speed_10m;
  const uv = current.uv_index;
  const clouds = current.cloud_cover;
  const tempStr = formatTemp(temp, unit);

  const roasts: string[] = [];

  if (temp <= -10) {
    roasts.push(`${location} is currently ${tempStr} which is colder than my ex's heart. Penguins would pack extra layers.`);
  } else if (temp <= 0) {
    roasts.push(`${tempStr} in ${location}. Your face will hurt. Your tears will freeze. This is nature's way of saying "stay in bed."`);
  } else if (temp <= 10) {
    roasts.push(`${tempStr} in ${location}. Not cold enough to cancel plans, but cold enough to make you regret having them.`);
  } else if (temp >= 10 && temp < 18) {
    roasts.push(`${tempStr} in ${location}. The temperature can't make up its mind, just like your weekend plans.`);
  } else if (temp >= 18 && temp < 25) {
    roasts.push(`${tempStr} in ${location}. This is the weather sweet spot. Don't mess it up by staying inside.`);
  } else if (temp >= 25 && temp < 32) {
    roasts.push(`${tempStr} in ${location}. You'll pretend it's fine while secretly calculating the distance to the nearest AC.`);
  } else if (temp >= 32 && temp < 38) {
    roasts.push(`${tempStr} in ${location}. The sun is not your friend today. The sun is a personal attack.`);
  } else if (temp >= 38) {
    roasts.push(`${tempStr} in ${location}. You could literally cook an egg on the sidewalk. The sidewalk knows this. The sidewalk is scared.`);
  }

  if (condition === "rain") {
    roasts.push(`It's raining and you still forgot your umbrella. Classic ${location}.`);
  } else if (condition === "thunderstorm") {
    roasts.push(`Thunderstorm in ${location}. Nature's throwing a tantrum and you're caught in the middle of it.`);
  } else if (condition === "snow") {
    roasts.push(`Snow in ${location}. It looks magical for exactly 5 minutes before you remember you have to shovel.`);
  } else if (condition === "fog") {
    roasts.push(`Fog so thick in ${location} you can't see your own bad decisions. Convenient.`);
  } else if (condition === "drizzle") {
    roasts.push(`It's not rain, it's not dry — it's the annoying middle child of weather in ${location}.`);
  }

  if (humidity > 80) {
    roasts.push(`${humidity}% humidity. The air is basically soup. You're swimming without a pool.`);
  } else if (humidity < 20) {
    roasts.push(`${humidity}% humidity. You're basically a raisin. Moisturize immediately.`);
  }

  if (wind > 30) {
    roasts.push(`Wind at ${Math.round(wind)} km/h. Your hair has surrendered. Your umbrella has filed for divorce.`);
  }

  if (uv > 7) {
    roasts.push(`UV index ${Math.round(uv)}. The sun called — it wants to personally fight you.`);
  }

  if (clouds > 90 && condition === "cloudy") {
    roasts.push(`${clouds}% cloud cover. The sky is just a gray ceiling. Inspirational.`);
  }

  roasts.push(
    `Today's ${condition.replace(/-/g, " ")} in ${location} has strong “cancel plans, blame the sky” energy.`,
    `The forecast says ${tempStr} in ${location}. Your jacket has been promoted to main character.`,
    `Weather report for ${location}: look outside, disagree with the forecast, regret it later.`,
    `Somewhere in ${location}, an umbrella is about to have a very important day.`,
  );

  const choices = roasts.filter((roast) => roast !== previous);
  return choices[Math.floor(Math.random() * choices.length)];
}

export function WeatherRoast({ current, location, unit }: WeatherRoastProps) {
  const [roastText, setRoastText] = useState(() => generateRoast(current, location, unit));

  useEffect(() => {
    setRoastText(generateRoast(current, location, unit));
  }, [current, location, unit]);

  const newRoast = useCallback(() => {
    playSound("vineBoom");
    setRoastText((previous) => generateRoast(current, location, unit, previous));
  }, [current, location, unit]);

  return (
    <div className="rounded-3xl bg-gradient-to-br from-orange-500/10 to-red-500/10 backdrop-blur-md border border-orange-400/20 p-5 sm:p-6">
      <div className="flex items-center gap-2 mb-3">
        <Flame className="w-5 h-5 text-orange-400" />
        <h3 className="text-lg font-bold text-white">Weather Roast</h3>
      </div>
      <p className="text-slate-300 text-sm leading-relaxed">{roastText}</p>
      <button
        onClick={newRoast}
        className="flex items-center gap-1.5 mt-3 text-xs text-orange-400 hover:text-orange-300 transition-colors font-medium"
      >
        <RefreshCw className="w-3.5 h-3.5" />
        Roast me again
      </button>
    </div>
  );
}
