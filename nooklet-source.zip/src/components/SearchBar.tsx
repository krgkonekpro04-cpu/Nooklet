import { useState } from "react";
import { Search, MapPin, Loader2 } from "lucide-react";

interface SearchBarProps {
  onSearch: (city: string) => void;
  onUseLocation: () => void;
  loading: boolean;
  geoLoading: boolean;
  placeholder?: string;
  myLocationLabel?: string;
}

export function SearchBar({ onSearch, onUseLocation, loading, geoLoading, placeholder = "Search any city worldwide...", myLocationLabel = "My Location" }: SearchBarProps) {
  const [value, setValue] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (value.trim()) {
      onSearch(value.trim());
    }
  };

  return (
    <div className="flex flex-col sm:flex-row gap-3 w-full max-w-2xl">
      <form onSubmit={handleSubmit} className="relative flex-1">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder={placeholder}
          disabled={loading}
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder:text-slate-300/60 focus:outline-none focus:ring-2 focus:ring-cyan-400/60 focus:border-transparent transition-all disabled:opacity-50"
        />
      </form>
      <button
        onClick={onUseLocation}
        disabled={geoLoading}
        className="flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-white font-semibold transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 shadow-lg shadow-cyan-500/30"
      >
        {geoLoading ? (
          <Loader2 className="w-5 h-5 animate-spin" />
        ) : (
          <MapPin className="w-5 h-5" />
        )}
        <span className="hidden sm:inline">{myLocationLabel}</span>
      </button>
    </div>
  );
}
