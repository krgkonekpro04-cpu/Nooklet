import { useState } from "react";
import { createPortal } from "react-dom";
import { Bug, Loader2, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { t, type LanguageCode } from "@/lib/i18n";
import { APP_VERSION } from "@/lib/app-meta";

interface BugReportDialogProps {
  uiLang: LanguageCode;
  onClose: () => void;
}

const CATEGORIES = [
  ["app", "bugCatApp"],
  ["weather", "bugCatWeather"],
  ["community", "bugCatCommunity"],
  ["memes", "bugCatMemes"],
  ["other", "bugCatOther"],
] as const;

export function BugReportDialog({ uiLang, onClose }: BugReportDialogProps) {
  const [category, setCategory] = useState<string>("app");
  const [description, setDescription] = useState("");
  const [steps, setSteps] = useState("");
  const [contact, setContact] = useState("");
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<"idle" | "sent" | "error">("idle");

  const sendReport = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (description.trim().length < 10 || sending) return;
    setSending(true);
    setStatus("idle");
    try {
      const { error } = await supabase.from("app_bug_reports").insert({
        app_version: APP_VERSION,
        category,
        description: description.trim(),
        reproduction_steps: steps.trim() || null,
        contact_email: contact.trim() || null,
        platform: navigator.platform || "Unknown",
      });
      setStatus(error ? "error" : "sent");
    } catch {
      setStatus("error");
    } finally {
      setSending(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[11000] flex items-end justify-center overflow-y-auto bg-slate-950/80 p-3 backdrop-blur-sm sm:items-center sm:p-6" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section role="dialog" aria-modal="true" aria-labelledby="bug-report-title" className="my-auto w-full max-w-xl overflow-hidden rounded-3xl border border-white/15 bg-slate-900 shadow-2xl">
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-400/15 text-orange-200"><Bug className="h-5 w-5" /></span>
            <div>
              <h2 id="bug-report-title" className="font-bold text-white">{t(uiLang, "bugTitle")}</h2>
              <p className="text-xs text-slate-400">MemeWeather {APP_VERSION}</p>
            </div>
          </div>
          <button type="button" onClick={onClose} aria-label={t(uiLang, "cancel")} className="rounded-lg p-2 text-slate-400 hover:bg-white/10 hover:text-white"><X className="h-5 w-5" /></button>
        </div>

        <form onSubmit={sendReport} className="space-y-4 p-5 sm:p-6">
          <label className="block space-y-1.5">
            <span className="text-sm font-medium text-slate-200">{t(uiLang, "bugCategory")}</span>
            <select value={category} onChange={(event) => setCategory(event.target.value)} className="w-full rounded-xl border border-white/15 bg-slate-800 px-3 py-3 text-sm text-white outline-none focus:border-cyan-300">
              {CATEGORIES.map(([value, key]) => <option key={value} value={value}>{t(uiLang, key)}</option>)}
            </select>
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium text-slate-200">{t(uiLang, "bugDescription")}</span>
            <textarea required minLength={10} maxLength={5000} rows={4} value={description} onChange={(event) => setDescription(event.target.value)} className="w-full resize-y rounded-xl border border-white/15 bg-slate-800 px-3 py-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-300" placeholder={t(uiLang, "bugDescription")} />
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium text-slate-200">{t(uiLang, "bugSteps")}</span>
            <textarea maxLength={5000} rows={2} value={steps} onChange={(event) => setSteps(event.target.value)} className="w-full resize-y rounded-xl border border-white/15 bg-slate-800 px-3 py-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-300" />
          </label>
          <label className="block space-y-1.5">
            <span className="text-sm font-medium text-slate-200">{t(uiLang, "bugContact")}</span>
            <input type="email" maxLength={320} value={contact} onChange={(event) => setContact(event.target.value)} className="w-full rounded-xl border border-white/15 bg-slate-800 px-3 py-3 text-sm text-white outline-none placeholder:text-slate-500 focus:border-cyan-300" />
          </label>

          {status === "sent" && <p role="status" className="rounded-xl border border-green-300/20 bg-green-400/10 p-3 text-sm text-green-100">{t(uiLang, "bugSent")}</p>}
          {status === "error" && <p role="alert" className="rounded-xl border border-red-300/20 bg-red-400/10 p-3 text-sm text-red-100">{t(uiLang, "bugFailed")}</p>}

          <div className="flex flex-wrap justify-end gap-2 pt-1">
            <button type="button" onClick={onClose} className="rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-200 hover:bg-white/10">{t(uiLang, "cancel")}</button>
            <button type="submit" disabled={sending || description.trim().length < 10} className="inline-flex items-center gap-2 rounded-xl bg-orange-400 px-4 py-2.5 text-sm font-semibold text-slate-950 hover:bg-orange-300 disabled:cursor-not-allowed disabled:opacity-50">
              {sending && <Loader2 className="h-4 w-4 animate-spin" />}{t(uiLang, "sendBug")}
            </button>
          </div>
        </form>
      </section>
    </div>,
    document.body,
  );
}
