import { useState, useCallback, useEffect, useRef } from "react";
import { supabase } from "@/lib/supabase";
import { ArrowLeft, Loader2, Send, MessageCircle, Reply, Trash2, Camera, X, Heart, ImagePlus, BadgeCheck } from "lucide-react";
import type { User } from "@supabase/supabase-js";
import { t, type LanguageCode } from "@/lib/i18n";
import { UserProfileDialog } from "@/components/UserProfileDialog";
import { DEVELOPER_EMAIL, DEVELOPER_USERNAME } from "@/lib/app-meta";
import { getCommunityError, isMissingColumn } from "@/lib/community-compat";

interface ForumPost {
  id: string;
  user_id: string;
  username: string;
  avatar_emoji: string;
  avatar_url: string | null;
  body: string;
  photo_url: string | null;
  reply_count: number;
  created_at: string;
  like_count: number;
  liked_by_me: boolean;
}

interface ForumReply {
  id: string;
  post_id: string;
  user_id: string;
  username: string;
  avatar_emoji: string;
  avatar_url: string | null;
  body: string;
  photo_url: string | null;
  created_at: string;
}

interface CommunityProps {
  user: User;
  username: string;
  avatarEmoji: string;
  avatarUrl: string | null;
  onAvatarUrlChange: (url: string) => void;
  uiLang: LanguageCode;
  forumId: string;
  forumName: string;
  onBackToForums: () => void;
  onSignOut: () => void;
}

function ProfileAvatar({ url, emoji, className }: { url: string | null; emoji: string; className: string }) {
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  if (url && failedUrl !== url) return <img src={url} alt="" onError={() => setFailedUrl(url)} className={`${className} object-cover`} />;
  return <span className={`${className} flex items-center justify-center bg-white/5 text-2xl`}>{emoji || "🪴"}</span>;
}

async function cropToSquareJpeg(file: File, position = { x: 50, y: 50 }): Promise<File> {
  if (!file.type.startsWith("image/")) throw new Error("Choose an image file.");
  if (file.size > 20 * 1024 * 1024) throw new Error("Choose an image smaller than 20 MB.");

  const bitmap = await createImageBitmap(file);
  try {
    const side = Math.min(bitmap.width, bitmap.height);
    const sx = (bitmap.width - side) * position.x / 100;
    const sy = (bitmap.height - side) * position.y / 100;
    const canvas = document.createElement("canvas");
    canvas.width = 512;
    canvas.height = 512;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("This image could not be prepared.");
    context.drawImage(bitmap, sx, sy, side, side, 0, 0, 512, 512);
    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((result) => result ? resolve(result) : reject(new Error("This image could not be prepared.")), "image/jpeg", 0.86);
    });
    return new File([blob], `${file.name.replace(/\.[^.]+$/, "") || "forum-photo"}.jpg`, { type: "image/jpeg" });
  } finally {
    bitmap.close();
  }
}

function withTimeout<T>(request: PromiseLike<T>, message: string, timeoutMs = 12_000): Promise<T> {
  return new Promise((resolve, reject) => {
    const timeout = window.setTimeout(() => reject(new Error(message)), timeoutMs);
    Promise.resolve(request).then(
      (value) => { window.clearTimeout(timeout); resolve(value); },
      (error: unknown) => { window.clearTimeout(timeout); reject(error); },
    );
  });
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

export function Community({ user, username, avatarEmoji, avatarUrl, onAvatarUrlChange, uiLang, forumId, forumName, onBackToForums, onSignOut }: CommunityProps) {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [replyPosting, setReplyPosting] = useState(false);
  const [avatarSaving, setAvatarSaving] = useState(false);
  const [avatarCropFile, setAvatarCropFile] = useState<File | null>(null);
  const [avatarCropPreview, setAvatarCropPreview] = useState<string | null>(null);
  const [avatarCropPosition, setAvatarCropPosition] = useState({ x: 50, y: 50 });
  const [profileToView, setProfileToView] = useState<string | null>(null);
  const [developerAccountId, setDeveloperAccountId] = useState<string | null>(null);
  const [body, setBody] = useState("");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [expandedPost, setExpandedPost] = useState<string | null>(null);
  const [replies, setReplies] = useState<Record<string, ForumReply[]>>({});
  const [replyBody, setReplyBody] = useState("");
  const [replyPhoto, setReplyPhoto] = useState<File | null>(null);
  const [replyPhotoPreview, setReplyPhotoPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [likeLoading, setLikeLoading] = useState<Set<string>>(new Set());
  const fileInputRef = useRef<HTMLInputElement>(null);
  const replyFileInputRef = useRef<HTMLInputElement>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);
  const isDeveloper = user.id === developerAccountId || user.email?.toLowerCase() === DEVELOPER_EMAIL.toLowerCase();

  useEffect(() => {
    let active = true;
    void supabase.from("profiles").select("id").eq("username", DEVELOPER_USERNAME).maybeSingle().then(({ data }) => {
      if (!active) return;
      setDeveloperAccountId(user.email?.toLowerCase() === DEVELOPER_EMAIL.toLowerCase() ? user.id : data?.id ?? (username.trim().toLowerCase() === DEVELOPER_USERNAME.toLowerCase() ? user.id : null));
    });
    return () => { active = false; };
  }, [username, user.id]);

  useEffect(() => () => {
    if (photoPreview) URL.revokeObjectURL(photoPreview);
    if (replyPhotoPreview) URL.revokeObjectURL(replyPhotoPreview);
    if (avatarCropPreview) URL.revokeObjectURL(avatarCropPreview);
  }, [photoPreview, replyPhotoPreview, avatarCropPreview]);

  const loadPosts = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    let data: ForumPost[] | null = null;
    let err: Error | null = null;
    try {
      const result = await withTimeout(
        supabase.from("forum_posts").select("*").eq("forum_id", forumId).order("created_at", { ascending: false }).limit(50),
        "The community took too long to respond. Check your connection and try again.",
      );
      data = result.data as ForumPost[] | null;
      err = result.error;
    } catch (requestError) {
      err = requestError instanceof Error ? requestError : new Error("Could not load community posts.");
    }

    if (err) {
      setLoadError(err.message || "Failed to load posts");
      setLoading(false);
      return;
    }

    const posts = (data ?? []) as Omit<ForumPost, "like_count" | "liked_by_me">[];

    // Fetch like counts and whether current user liked each post
    let likes: { post_id: string; user_id: string }[] | null = [];
    if (posts.length) {
      try {
        const likeResult = await withTimeout(
          supabase.from("forum_likes").select("post_id, user_id").in("post_id", posts.map((post) => post.id)),
          "The community took too long to respond. Try refreshing.",
      );
        likes = likeResult.data;
      } catch {
        // Posts remain readable when the optional likes query fails.
      }
    }

    const likeMap = new Map<string, { count: number; liked: boolean }>();
    for (const like of likes ?? []) {
      const entry = likeMap.get(like.post_id) ?? { count: 0, liked: false };
      entry.count += 1;
      if (like.user_id === user.id) entry.liked = true;
      likeMap.set(like.post_id, entry);
    }

    const enriched: ForumPost[] = posts.map((p) => {
      const info = likeMap.get(p.id) ?? { count: 0, liked: false };
      return { ...p, like_count: info.count, liked_by_me: info.liked };
    });

    setPosts(enriched);
    setLoading(false);
  }, [user.id, forumId]);

  useEffect(() => {
    loadPosts();
  }, [loadPosts]);

  const uploadPhoto = useCallback(async (file: File, position = { x: 50, y: 50 }): Promise<string> => {
    const squarePhoto = await cropToSquareJpeg(file, position);
    const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;
    const { error: uploadErr } = await supabase.storage
      .from("forum-photos")
      .upload(fileName, squarePhoto, { contentType: "image/jpeg", cacheControl: "3600" });

    if (uploadErr) throw uploadErr;

    const { data: urlData } = supabase.storage
      .from("forum-photos")
      .getPublicUrl(fileName);

    return urlData.publicUrl;
  }, [user.id]);

  const handlePost = useCallback(async () => {
    if (!body.trim() && !photoFile) return;
    setPosting(true);
    setError(null);
    try {
      const photoUrl = photoFile ? await uploadPhoto(photoFile) : null;
      const postPayload = {
        forum_id: forumId,
        user_id: user.id,
        username,
        avatar_emoji: avatarEmoji,
        avatar_url: avatarUrl,
        body: body.trim(),
        photo_url: photoUrl,
      };
      let { data, error: insertErr } = await supabase
        .from("forum_posts")
        .insert(postPayload)
        .select()
        .single();
      if (insertErr && isMissingColumn(insertErr, "avatar_url")) {
        const legacyPayload = Object.fromEntries(Object.entries(postPayload).filter(([key]) => key !== "avatar_url"));
        ({ data, error: insertErr } = await supabase.from("forum_posts").insert(legacyPayload).select().single());
      }
      if (insertErr) throw insertErr;
      if (data) {
        const newPost = data as Omit<ForumPost, "like_count" | "liked_by_me">;
        setPosts((prev) => [{ ...newPost, avatar_url: newPost.avatar_url ?? avatarUrl, like_count: 0, liked_by_me: false }, ...prev]);
        setBody("");
        setPhotoFile(null);
        setPhotoPreview(null);
      }
    } catch (err) {
      setError(getCommunityError(err, "Could not publish your post."));
    } finally {
      setPosting(false);
    }
  }, [body, photoFile, forumId, user.id, username, avatarEmoji, avatarUrl, uploadPhoto]);

  const handleToggleLike = useCallback(async (postId: string) => {
    if (likeLoading.has(postId)) return;
    const post = posts.find((p) => p.id === postId);
    if (!post) return;
    setLikeLoading((prev) => new Set(prev).add(postId));
    const liked = !post.liked_by_me;
    const nextPost = { ...post, liked_by_me: liked, like_count: Math.max(0, post.like_count + (liked ? 1 : -1)) };
    setPosts((prev) => prev.map((p) => p.id === postId ? nextPost : p));
    try {
      const result = liked
        ? await supabase.from("forum_likes").insert({ post_id: postId, user_id: user.id })
        : await supabase.from("forum_likes").delete().eq("post_id", postId).eq("user_id", user.id);
      if (result.error) throw result.error;
    } catch {
      setPosts((prev) => prev.map((p) => p.id === postId ? post : p));
      setError("Your reaction could not be saved. Please try again.");
    } finally {
      setLikeLoading((prev) => {
        const next = new Set(prev);
        next.delete(postId);
        return next;
      });
    }
  }, [posts, user.id, likeLoading]);

  const handleProfilePhoto = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) { setError(t(uiLang, "chooseImage")); return; }
    if (file.size > 20 * 1024 * 1024) { setError(t(uiLang, "imageTooLarge")); return; }
    setError(null);
    setAvatarCropFile(file);
    setAvatarCropPreview(URL.createObjectURL(file));
    setAvatarCropPosition({ x: 50, y: 50 });
  }, [uiLang]);

  const saveProfilePhoto = useCallback(async () => {
    if (!avatarCropFile) return;
    setAvatarSaving(true);
    setError(null);
    try {
      const url = await uploadPhoto(avatarCropFile, avatarCropPosition);
      let { error: profileError } = await supabase.from("profiles").upsert({
        id: user.id, username, avatar_emoji: avatarEmoji, avatar_url: url,
      }, { onConflict: "id" });
      if (profileError && isMissingColumn(profileError, "avatar_url")) {
        const { error: metadataError } = await supabase.auth.updateUser({ data: { username, avatar_emoji: avatarEmoji, avatar_url: url } });
        if (metadataError) throw metadataError;
        profileError = null;
      }
      if (profileError) throw profileError;
      // The profile row is the source of truth for the current avatar. Updating
      // every historical post/reply here is unnecessary and can fail under a
      // deployment whose row-level-security policies only allow inserts.
      // Keep this action scoped to the profile, then update the visible feed.
      setPosts((current) => current.map((post) => post.user_id === user.id ? { ...post, avatar_url: url } : post));
      setReplies((current) => Object.fromEntries(Object.entries(current).map(([postId, items]) => [postId, items.map((reply) => reply.user_id === user.id ? { ...reply, avatar_url: url } : reply)])));
      onAvatarUrlChange(url);
      setAvatarCropFile(null);
      setAvatarCropPreview(null);
    } catch (err) {
      setError(getCommunityError(err, t(uiLang, "photoUploadFailed")));
    } finally {
      setAvatarSaving(false);
    }
  }, [avatarCropFile, avatarCropPosition, user.id, username, avatarEmoji, uploadPhoto, onAvatarUrlChange, uiLang]);

  const loadReplies = useCallback(async (postId: string) => {
    const { data } = await supabase
      .from("forum_replies")
      .select("*")
      .eq("post_id", postId)
      .order("created_at", { ascending: true });

    if (data) {
      setReplies((prev) => ({ ...prev, [postId]: data as ForumReply[] }));
    }
  }, []);

  const toggleReplies = useCallback((postId: string) => {
    setExpandedPost((prev) => {
      if (prev === postId) return null;
      loadReplies(postId);
      return postId;
    });
    setReplyBody("");
    setReplyPhoto(null);
    setReplyPhotoPreview(null);
  }, [loadReplies]);

  const handleReply = useCallback(async () => {
    if (!expandedPost || !replyBody.trim() || replyPosting) return;
    setReplyPosting(true);
    setError(null);
    try {
      const photoUrl = replyPhoto ? await uploadPhoto(replyPhoto) : null;
      const { data, error: replyError } = await supabase
        .from("forum_replies")
        .insert({
          post_id: expandedPost,
          user_id: user.id,
          username,
          avatar_emoji: avatarEmoji,
          avatar_url: avatarUrl,
          body: replyBody.trim(),
          photo_url: photoUrl,
        })
        .select()
        .single();
      if (replyError) throw replyError;
      if (data) {
        const newReply = data as ForumReply;
        setReplies((prev) => ({
          ...prev,
          [expandedPost]: [...(prev[expandedPost] ?? []), newReply],
        }));
        setPosts((prev) => prev.map((p) => p.id === expandedPost ? { ...p, reply_count: p.reply_count + 1 } : p));
        setReplyBody("");
        setReplyPhoto(null);
        setReplyPhotoPreview(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not publish your reply.");
    } finally {
      setReplyPosting(false);
    }
  }, [expandedPost, replyBody, replyPhoto, replyPosting, user.id, username, avatarEmoji, avatarUrl, uploadPhoto]);

  const handleDeletePost = useCallback(async (postId: string) => {
    const { error: delErr } = await supabase.from("forum_posts").delete().eq("id", postId);
    if (!delErr) {
      setPosts((prev) => prev.filter((p) => p.id !== postId));
    }
  }, []);

  const handleDeleteReply = useCallback(async (replyId: string, postId: string) => {
    const { error: delErr } = await supabase.from("forum_replies").delete().eq("id", replyId);
    if (!delErr) {
      setReplies((prev) => ({
        ...prev,
        [postId]: (prev[postId] ?? []).filter((r) => r.id !== replyId),
      }));
      setPosts((prev) =>
        prev.map((p) =>
          p.id === postId ? { ...p, reply_count: p.reply_count - 1 } : p
        )
      );
    }
  }, []);

  const onPhotoSelect = (e: React.ChangeEvent<HTMLInputElement>, isReply: boolean) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError(t(uiLang, "chooseImage"));
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError(t(uiLang, "imageTooLarge"));
      return;
    }
    setError(null);
    if (isReply) {
      setReplyPhoto(file);
      setReplyPhotoPreview(URL.createObjectURL(file));
    } else {
      setPhotoFile(file);
      setPhotoPreview(URL.createObjectURL(file));
    }
  };

  return (
    <div className="nooklet-community space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <button type="button" onClick={onBackToForums} className="mr-1 rounded-full border border-[#dedfd7] bg-white p-2 text-[#667066] transition hover:bg-[#f2f4ee]" aria-label="Back to all forums"><ArrowLeft className="h-4 w-4"/></button>
          <button
            type="button"
            onClick={() => avatarInputRef.current?.click()}
            disabled={avatarSaving}
            title={t(uiLang, "changeProfilePhoto")}
            aria-label={t(uiLang, "changeProfilePhoto")}
            className="group relative h-14 w-14 shrink-0 overflow-hidden rounded-full border border-white/15 bg-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-400/60"
          >
            <ProfileAvatar url={avatarUrl} emoji={avatarEmoji} className="aspect-square h-full w-full rounded-full" />
            <span className="absolute inset-0 flex items-center justify-center bg-slate-950/55 text-white opacity-0 transition-opacity group-hover:opacity-100">
              {avatarSaving ? <Loader2 className="h-5 w-5 animate-spin" /> : <ImagePlus className="h-5 w-5" />}
            </span>
          </button>
          <input ref={avatarInputRef} type="file" accept="image/*" className="hidden" onChange={handleProfilePhoto} />
          <div>
            <h2 className="text-xl font-bold text-white">{forumName}</h2>
            <button type="button" onClick={() => setProfileToView(user.id)} className="flex flex-wrap items-center gap-1.5 text-left text-xs text-slate-300 hover:text-white">
              {t(uiLang, "welcome")}, {username}
              {isDeveloper && <><BadgeCheck className="h-4 w-4 fill-sky-500 text-white" /><span className="rounded-full border border-sky-300/30 bg-sky-400/10 px-2 py-0.5 font-semibold text-sky-200">{t(uiLang, "developer")}</span></>}
            </button>
            <button type="button" onClick={() => avatarInputRef.current?.click()} disabled={avatarSaving} className="mt-1 text-xs text-cyan-300 hover:text-cyan-200 disabled:opacity-60">
              {avatarSaving ? t(uiLang, "uploadingPhoto") : t(uiLang, "changeProfilePhoto")}
            </button>
          </div>
        </div>
        <button
          onClick={onSignOut}
          className="text-xs text-slate-400 hover:text-slate-200 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
        >
          {t(uiLang, "signOut")}
        </button>
      </div>

      {/* Compose box */}
      <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5">
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={t(uiLang, "shareThoughts")}
          rows={3}
          className="w-full px-4 py-3 rounded-2xl bg-white/10 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all resize-none text-sm"
        />
        {photoPreview && (
          <div className="relative mt-3 inline-block">
            <img src={photoPreview} alt="preview" className="aspect-square h-28 w-28 rounded-xl border border-white/15 object-cover" />
            <button
              onClick={() => { setPhotoFile(null); setPhotoPreview(null); }}
              className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center text-xs"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        <div className="flex items-center justify-between mt-3">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition-colors"
          >
            <Camera className="w-4 h-4" />
            {t(uiLang, "addPhoto")}
          </button>
          <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => onPhotoSelect(e, false)} />
          <button
            onClick={handlePost}
            disabled={(!body.trim() && !photoFile) || posting}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-500/20 border border-cyan-400/30 text-cyan-300 font-medium text-sm hover:bg-cyan-500/30 transition-all active:scale-95 disabled:opacity-40"
          >
            {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {t(uiLang, "post")}
          </button>
        </div>
        {!body.trim() && !photoFile && <p className="mt-2 text-xs text-slate-500">{t(uiLang, "postNeedsContent")}</p>}
        {error && <p className="text-red-300 text-xs mt-2">{error}</p>}
      </div>

      {/* Posts list */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
        </div>
      ) : loadError && posts.length === 0 ? (
        <div className="rounded-2xl border border-red-300/20 bg-red-400/10 px-5 py-8 text-center">
          <p className="mb-4 text-sm text-red-100">{loadError}</p>
          <button type="button" onClick={() => void loadPosts()} className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm text-white hover:bg-white/15">Try again</button>
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-16 text-slate-500 text-sm">
          <p className="mb-1">{t(uiLang, "noPosts")}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <div key={post.id} className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5 card-hover-lift">
              {/* Post header */}
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <button type="button" onClick={() => setProfileToView(post.user_id)} aria-label={`${t(uiLang, "viewProfile")}: ${post.username}`}>
                    <ProfileAvatar url={post.avatar_url ?? (post.user_id === user.id ? avatarUrl : null)} emoji={post.avatar_emoji} className="aspect-square h-10 w-10 shrink-0 rounded-full border border-white/10" />
                  </button>
                  <div>
                    <button type="button" onClick={() => setProfileToView(post.user_id)} className="flex items-center gap-1 text-sm font-semibold text-white hover:text-cyan-200">
                      {post.username}
                      {post.user_id === developerAccountId && <BadgeCheck className="h-4 w-4 fill-sky-500 text-white" aria-label={t(uiLang, "verifiedDeveloper")} />}
                    </button>
                    <div className="text-xs text-slate-500">{timeAgo(post.created_at)}</div>
                  </div>
                </div>
                {post.user_id === user.id && (
                  <button
                    onClick={() => handleDeletePost(post.id)}
                    className="text-slate-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Post body */}
              <p className="text-slate-200 text-sm leading-relaxed mb-3 whitespace-pre-wrap">{post.body}</p>

              {/* Post photo */}
              {post.photo_url && (
                <img src={post.photo_url} alt="post" loading="lazy" className="mb-3 aspect-square w-full max-w-md rounded-2xl border border-white/10 object-cover" />
              )}

              {/* Like + Reply row */}
              <div className="flex items-center gap-3 mb-3">
                <button
                  onClick={() => handleToggleLike(post.id)}
                  disabled={likeLoading.has(post.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-all active:scale-90 ${
                    post.liked_by_me
                      ? "bg-red-500/15 border-red-400/30 text-red-400"
                      : "bg-white/5 border-white/10 text-slate-400 hover:bg-white/10 hover:border-white/20"
                  }`}
                >
                  <Heart className={`w-4 h-4 ${post.liked_by_me ? "fill-current" : ""}`} />
                  {post.like_count > 0 && <span className="text-xs font-medium">{post.like_count}</span>}
                </button>

                <button
                  onClick={() => toggleReplies(post.id)}
                  className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-300 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  {post.reply_count} {post.reply_count === 1 ? t(uiLang, "reply") : t(uiLang, "replies")}
                </button>
              </div>

              {/* Replies */}
              {expandedPost === post.id && (
                <div className="mt-4 pt-4 border-t border-white/10 space-y-3 animate-fade-in">
                  {(replies[post.id] ?? []).map((reply) => (
                    <div key={reply.id} className="flex items-start gap-2">
                      <button type="button" onClick={() => setProfileToView(reply.user_id)} aria-label={`${t(uiLang, "viewProfile")}: ${reply.username}`}><ProfileAvatar url={reply.avatar_url ?? (reply.user_id === user.id ? avatarUrl : null)} emoji={reply.avatar_emoji} className="aspect-square h-8 w-8 shrink-0 rounded-full border border-white/10" /></button>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <button type="button" onClick={() => setProfileToView(reply.user_id)} className="text-left text-xs font-semibold text-white hover:text-cyan-200">{reply.username}</button>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-slate-500">{timeAgo(reply.created_at)}</span>
                            {reply.user_id === user.id && (
                              <button
                                onClick={() => handleDeleteReply(reply.id, post.id)}
                                className="text-slate-500 hover:text-red-400 transition-colors"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                        <p className="text-sm text-slate-300 leading-relaxed mt-0.5">{reply.body}</p>
                        {reply.photo_url && (
                          <img src={reply.photo_url} alt="reply" loading="lazy" className="mt-2 aspect-square h-40 w-40 rounded-xl border border-white/10 object-cover" />
                        )}
                      </div>
                    </div>
                  ))}

                  {/* Reply compose */}
                  <div className="flex items-start gap-2 mt-3">
                    <ProfileAvatar url={avatarUrl} emoji={avatarEmoji} className="aspect-square h-8 w-8 shrink-0 rounded-full border border-white/10" />
                    <div className="flex-1">
                      <textarea
                        value={replyBody}
                        onChange={(e) => setReplyBody(e.target.value)}
                        placeholder={t(uiLang, "writeReply")}
                        rows={2}
                        className="w-full px-3 py-2 rounded-xl bg-white/10 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/40 transition-all resize-none text-sm"
                      />
                      {replyPhotoPreview && (
                        <div className="relative mt-2 inline-block">
                          <img src={replyPhotoPreview} alt="preview" className="aspect-square h-20 w-20 rounded-lg border border-white/15 object-cover" />
                          <button
                            onClick={() => { setReplyPhoto(null); setReplyPhotoPreview(null); }}
                            className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-xs"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <button
                          onClick={() => replyFileInputRef.current?.click()}
                          className="text-xs text-slate-400 hover:text-cyan-300 transition-colors flex items-center gap-1"
                        >
                          <Camera className="w-3.5 h-3.5" />
                          {t(uiLang, "photo")}
                        </button>
                        <input ref={replyFileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => onPhotoSelect(e, true)} />
                        <button
                          onClick={handleReply}
                          disabled={!replyBody.trim()}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-cyan-500/15 border border-cyan-400/25 text-cyan-300 text-xs font-medium hover:bg-cyan-500/25 transition-all active:scale-95 disabled:opacity-40"
                        >
                          <Reply className="w-3.5 h-3.5" />
                          {t(uiLang, "reply")}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {avatarCropPreview && avatarCropFile && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center bg-slate-950/80 p-4 backdrop-blur-sm" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !avatarSaving) setAvatarCropPreview(null); }}>
          <section className="w-full max-w-lg rounded-3xl border border-white/15 bg-slate-900 p-5 shadow-2xl sm:p-7" role="dialog" aria-modal="true" aria-labelledby="avatar-crop-title">
            <div className="mb-5 flex items-start justify-between gap-4">
              <div><h2 id="avatar-crop-title" className="text-lg font-bold text-white">{t(uiLang, "photoPreviewTitle")}</h2><p className="mt-1 text-sm text-slate-400">{t(uiLang, "photoPreviewHelp")}</p></div>
              <button type="button" disabled={avatarSaving} onClick={() => setAvatarCropPreview(null)} className="rounded-full border border-white/10 p-2 text-slate-300 hover:bg-white/10 disabled:opacity-50" aria-label={t(uiLang, "close")}><X className="h-4 w-4" /></button>
            </div>
            <div className="mx-auto mb-5 grid w-full max-w-sm grid-cols-[1fr_5rem] items-center gap-4">
              <div className="relative aspect-square overflow-hidden rounded-2xl border-2 border-cyan-300/70 bg-slate-800">
                <img src={avatarCropPreview} alt={t(uiLang, "photoPreviewAlt")} className="absolute inset-0 h-full w-full object-cover" style={{ objectPosition: `${avatarCropPosition.x}% ${avatarCropPosition.y}%` }} />
                <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/30" />
              </div>
              <div className="text-center"><div className="mx-auto aspect-square w-20 overflow-hidden rounded-full border-2 border-white/25 bg-slate-800"><img src={avatarCropPreview} alt="" className="h-full w-full object-cover" style={{ objectPosition: `${avatarCropPosition.x}% ${avatarCropPosition.y}%` }} /></div><span className="mt-2 block text-[11px] text-slate-400">{t(uiLang, "photoCirclePreview")}</span></div>
            </div>
            <label className="mb-4 block text-xs font-medium text-slate-300">{t(uiLang, "photoHorizontal")}<input type="range" min="0" max="100" value={avatarCropPosition.x} onChange={(event) => setAvatarCropPosition((current) => ({ ...current, x: Number(event.target.value) }))} className="mt-2 block w-full accent-cyan-400" /></label>
            <label className="mb-6 block text-xs font-medium text-slate-300">{t(uiLang, "photoVertical")}<input type="range" min="0" max="100" value={avatarCropPosition.y} onChange={(event) => setAvatarCropPosition((current) => ({ ...current, y: Number(event.target.value) }))} className="mt-2 block w-full accent-cyan-400" /></label>
            <div className="flex justify-end gap-3"><button type="button" disabled={avatarSaving} onClick={() => setAvatarCropPreview(null)} className="rounded-xl border border-white/15 px-4 py-2 text-sm text-slate-200 hover:bg-white/10 disabled:opacity-50">{t(uiLang, "cancel")}</button><button type="button" disabled={avatarSaving} onClick={() => void saveProfilePhoto()} className="inline-flex items-center gap-2 rounded-xl bg-cyan-500 px-4 py-2 text-sm font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-50">{avatarSaving && <Loader2 className="h-4 w-4 animate-spin" />}{avatarSaving ? t(uiLang, "uploadingPhoto") : t(uiLang, "usePhoto")}</button></div>
          </section>
        </div>
      )}
      {profileToView && <UserProfileDialog profileId={profileToView} viewerId={user.id} currentUsername={username} currentAvatarEmoji={avatarEmoji} currentAvatarUrl={avatarUrl} developerUserId={developerAccountId ?? undefined} uiLang={uiLang} onClose={() => setProfileToView(null)} />}
    </div>
  );
}
