import type { HourlyForecast } from "@/types";
import type { LanguageCode } from "@/lib/i18n";
import { t } from "@/lib/i18n";
import { formatTempShort, type TempUnit } from "@/lib/temperature";

interface HourlyStripProps {
  hourly: HourlyForecast;
  uiLang: LanguageCode;
  unit: TempUnit;
}

function getEmoji(code: number): string {
  if (code === 0 || code === 1) return "☀️";
  if (code === 2) return "⛅";
  if (code === 3) return "☁️";
  if (code === 45 || code === 48) return "🌫️";
  if (code >= 51 && code <= 57) return "🌦️";
  if (code >= 61 && code <= 67) return "🌧️";
  if (code >= 71 && code <= 77) return "🌨️";
  if (code >= 80 && code <= 82) return "🌧️";
  if (code >= 85 && code <= 86) return "🌨️";
  if (code >= 95) return "⛈️";
  return "🌤️";
}

export function HourlyStrip({ hourly, uiLang, unit }: HourlyStripProps) {
  const now = new Date();
  let startIdx = 0;
  for (let i = 0; i < hourly.time.length; i++) {
    const time = new Date(hourly.time[i]);
    if (time >= now) {
      startIdx = Math.max(0, i - 1);
      break;
    }
  }

  const hours = hourly.time.slice(startIdx, startIdx + 12).map((timeStr, i) => {
    const idx = startIdx + i;
    const date = new Date(timeStr);
    const isNow = i === 0;
    const hour = date.getHours();
    const hourLabel = isNow ? t(uiLang, "now") : `${hour % 12 || 12}${hour < 12 ? "AM" : "PM"}`;
    return {
      hourLabel,
      temp: formatTempShort(hourly.temperature_2m[idx], unit),
      emoji: getEmoji(hourly.weather_code[idx]),
      precip: hourly.precipitation_probability[idx] ?? 0,
    };
  });

  return (
    <div className="w-full">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <span className="inline-block w-1 h-5 rounded-full bg-cyan-400" />
        {t(uiLang, "next12Hours")}
      </h3>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1 scrollbar-thin">
        {hours.map((h, i) => (
          <div
            key={i}
            className={`flex-shrink-0 flex flex-col items-center gap-1 px-4 py-3 rounded-2xl border transition-all ${
              i === 0
                ? "bg-cyan-500/15 border-cyan-400/40"
                : "bg-white/5 border-white/10"
            }`}
          >
            <span className="text-xs text-slate-400 font-medium">{h.hourLabel}</span>
            <span className="text-2xl">{h.emoji}</span>
            <span className="text-lg font-bold text-white">{h.temp}</span>
            {h.precip > 0 && <span className="text-xs text-cyan-300">{h.precip}%</span>}
          </div>
        ))}
      </div>
    </div>
  );
}
