import { useMemo } from "react";
import { Shirt } from "lucide-react";
import type { CurrentWeather } from "@/types";
import { getCondition } from "@/lib/memes";

interface OutfitSuggestionProps {
  current: CurrentWeather;
}

interface OutfitItem {
  emoji: string;
  label: string;
}

function getOutfit(current: CurrentWeather): { items: OutfitItem[]; verdict: string } {
  const temp = current.apparent_temperature;
  const condition = getCondition(current.weather_code);
  const wind = current.wind_speed_10m;
  const uv = current.uv_index;
  const items: OutfitItem[] = [];

  if (temp <= -10) {
    items.push({ emoji: "🧥", label: "Heavy winter coat" });
    items.push({ emoji: "🧣", label: "Scarf & face mask" });
    items.push({ emoji: "🧤", label: "Insulated gloves" });
    items.push({ emoji: "👢", label: "Winter boots" });
    items.push({ emoji: "🧦", label: "Thermal socks (2 pairs)" });
  } else if (temp <= 0) {
    items.push({ emoji: "🧥", label: "Winter coat" });
    items.push({ emoji: "🧣", label: "Scarf" });
    items.push({ emoji: "🧤", label: "Gloves" });
    items.push({ emoji: "👢", label: "Warm boots" });
  } else if (temp <= 10) {
    items.push({ emoji: "🧥", label: "Jacket or heavy sweater" });
    items.push({ emoji: "👖", label: "Long pants" });
    if (wind > 20) items.push({ emoji: "🧣", label: "Light scarf (windy)" });
  } else if (temp <= 18) {
    items.push({ emoji: "🧥", label: "Light jacket" });
    items.push({ emoji: "👖", label: "Long pants" });
    items.push({ emoji: "👟", label: "Sneakers" });
  } else if (temp <= 25) {
    items.push({ emoji: "👕", label: "T-shirt" });
    items.push({ emoji: "👖", label: "Light pants or jeans" });
    items.push({ emoji: "👟", label: "Sneakers" });
  } else if (temp <= 32) {
    items.push({ emoji: "👕", label: "Light t-shirt" });
    items.push({ emoji: "🩳", label: "Shorts" });
    items.push({ emoji: "🩴", label: "Sandals" });
    items.push({ emoji: "🧢", label: "Cap" });
  } else {
    items.push({ emoji: "👕", label: "Lightest possible shirt" });
    items.push({ emoji: "🩳", label: "Shorts" });
    items.push({ emoji: "🩴", label: "Sandals" });
    items.push({ emoji: "🧢", label: "Hat (essential)" });
  }

  if (condition === "rain" || condition === "drizzle") {
    items.push({ emoji: "☂️", label: "Umbrella" });
    items.push({ emoji: "🥾", label: "Waterproof shoes" });
  }
  if (condition === "snow") {
    items.push({ emoji: "🥾", label: "Waterproof boots" });
  }
  if (condition === "thunderstorm") {
    items.push({ emoji: "☔", label: "Sturdy umbrella" });
  }
  if (condition === "fog") {
    items.push({ emoji: "🦺", label: "Reflective vest" });
  }
  if (uv > 7) {
    items.push({ emoji: "🧴", label: "Sunscreen (SPF 50+)" });
    items.push({ emoji: "🕶️", label: "Sunglasses" });
  } else if (uv > 3) {
    items.push({ emoji: "🧴", label: "Sunscreen" });
  }
  if (wind > 30) {
    items.push({ emoji: "🧥", label: "Windbreaker" });
  }

  let verdict = "";
  if (temp <= 0) verdict = "Stay inside if you can. If not, layer up like an onion.";
  else if (temp <= 10) verdict = "A chilly one — jacket weather for sure.";
  else if (temp <= 18) verdict = "Pleasant but bring a layer just in case.";
  else if (temp <= 25) verdict = "Perfect outfit weather. Keep it simple.";
  else if (temp <= 32) verdict = "Dress like you're on vacation.";
  else verdict = "Minimal clothing. Maximum AC. Good luck out there.";

  return { items, verdict };
}

export function OutfitSuggestion({ current }: OutfitSuggestionProps) {
  const outfit = useMemo(() => getOutfit(current), [current]);

  return (
    <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5 sm:p-6">
      <div className="flex items-center gap-2 mb-4">
        <Shirt className="w-5 h-5 text-cyan-400" />
        <h3 className="text-lg font-bold text-white">What to Wear</h3>
      </div>
      <div className="flex flex-wrap gap-2 mb-4">
        {outfit.items.map((item, i) => (
          <div
            key={i}
            className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-cyan-500/10 border border-cyan-400/20"
          >
            <span className="text-2xl">{item.emoji}</span>
            <span className="text-xs text-slate-300 font-medium">{item.label}</span>
          </div>
        ))}
      </div>
      <p className="text-slate-400 text-sm italic">{outfit.verdict}</p>
    </div>
  );
}
