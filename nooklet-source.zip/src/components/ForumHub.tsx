import { useCallback, useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { ArrowLeft, ArrowUpRight, BookOpen, Check, Compass, Hash, Loader2, Plus, Search, Sprout, Users, Wrench, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { Community } from "@/components/Community";

interface Forum {
  id: string;
  name: string;
  slug: string;
  description: string;
  topic: string;
  emoji: string;
  created_at: string;
}

interface ForumHubProps {
  user: User;
  username: string;
  avatarEmoji: string;
  avatarUrl: string | null;
  onAvatarUrlChange: (url: string) => void;
  onSignOut: () => void;
}

const TOPICS = ["Art & making", "Books & stories", "Food & home", "Games & tech", "Gardening", "Local community", "Learning", "Other"];
const EMOJIS = ["🪴", "📚", "🧶", "🎨", "🎮", "☕", "🛠️", "🍳", "🚲", "🪴", "🪐", "✍️"];
const topicStyle: Record<string, { icon: typeof Sprout; tone: string }> = {
  "Art & making": { icon: Wrench, tone: "bg-[#f0e9df] text-[#9a7046]" },
  "Books & stories": { icon: BookOpen, tone: "bg-[#eee9e3] text-[#80624d]" },
  Gardening: { icon: Sprout, tone: "bg-[#e6efe2] text-[#4f8158]" },
  "Games & tech": { icon: Hash, tone: "bg-[#e7ebf2] text-[#55739b]" },
  "Local community": { icon: Users, tone: "bg-[#f0e7e3] text-[#9a6755]" },
};

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 48);
}

export function ForumHub({ user, username, avatarEmoji, avatarUrl, onAvatarUrlChange, onSignOut }: ForumHubProps) {
  const [forums, setForums] = useState<Forum[]>([]);
  const [selected, setSelected] = useState<Forum | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [topicFilter, setTopicFilter] = useState("All topics");
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [topic, setTopic] = useState(TOPICS[0]);
  const [emoji, setEmoji] = useState(EMOJIS[0]);

  const loadForums = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    const { data, error } = await supabase.from("forums").select("id, name, slug, description, topic, emoji, created_at").order("created_at", { ascending: false });
    if (error) setLoadError(error.message.includes("forums") ? "The forum directory needs its database update before it can load." : error.message);
    else setForums((data ?? []) as Forum[]);
    setLoading(false);
  }, []);

  useEffect(() => { void loadForums(); }, [loadForums]);

  const createForum = async (event: React.FormEvent) => {
    event.preventDefault();
    if (creating || !name.trim() || !description.trim()) return;
    setCreating(true);
    setCreateError(null);
    try {
      const slug = `${slugify(name)}-${Math.random().toString(36).slice(2, 7)}`;
      const { data, error } = await supabase.from("forums").insert({ name: name.trim(), slug, description: description.trim(), topic, emoji, created_by: user.id }).select("id, name, slug, description, topic, emoji, created_at").single();
      if (error) {
        const code = (error as { code?: string }).code;
        if (code === "42P01" || code === "PGRST205") {
          setCreateError("Forum creation is not enabled on the server yet. Apply the Nooklet forums database update, then try again.");
        } else if (code === "42501" || code === "PGRST301") {
          setCreateError("Your sign-in does not have permission to create forums. Sign out and back in; if it continues, the server needs the Nooklet forum permissions update.");
        } else {
          setCreateError(error.message || "Nooklet could not save this forum. Check your connection and try again.");
        }
      } else if (data) {
        const forum = data as Forum;
        setForums((current) => [forum, ...current]);
        setName(""); setDescription(""); setTopic(TOPICS[0]); setEmoji(EMOJIS[0]); setCreateOpen(false); setSelected(forum);
      } else {
        setCreateError("Nooklet did not receive a saved forum. Please try again.");
      }
    } catch (error) {
      setCreateError(error instanceof Error ? error.message : "Could not reach the forum service. Check your connection and try again.");
    } finally {
      setCreating(false);
    }
  };

  if (selected) return (
    <div className="nooklet-community-wrap">
      <button type="button" onClick={() => setSelected(null)} className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-4 py-2 text-sm font-semibold text-[#596358] transition hover:border-[#bdcfbf] hover:text-[#315c3c]"><ArrowLeft className="h-4 w-4"/>All forums</button>
      <Community user={user} username={username} avatarEmoji={avatarEmoji} avatarUrl={avatarUrl} onAvatarUrlChange={onAvatarUrlChange} uiLang="en" forumId={selected.id} forumName={selected.name} onBackToForums={() => setSelected(null)} onSignOut={onSignOut} />
    </div>
  );

  const filtered = forums.filter((forum) => (topicFilter === "All topics" || forum.topic === topicFilter) && `${forum.name} ${forum.description} ${forum.topic}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="nooklet-hub">
      <div className="mb-9 flex flex-col justify-between gap-5 border-b border-[#e5e6df] pb-8 sm:flex-row sm:items-end">
        <div><div className="mb-3 inline-flex items-center gap-2 rounded-full bg-[#e7eee5] px-3 py-1.5 text-xs font-bold text-[#4d7655]"><Compass className="h-3.5 w-3.5"/>YOUR FORUM DIRECTORY</div><h1 className="text-3xl font-black tracking-[-0.05em] text-[#202a22] sm:text-4xl">Find your corner.</h1><p className="mt-2 max-w-xl text-sm leading-6 text-[#778076]">Browse the little communities people are building—or start one around something you love.</p></div>
        <button type="button" onClick={() => { setCreateOpen(true); setCreateError(null); }} className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-[#284f37] px-5 py-3 text-sm font-bold text-white shadow-md shadow-[#284f37]/10 transition hover:-translate-y-0.5 hover:bg-[#1f422d]"><Plus className="h-4 w-4"/>Create a forum</button>
      </div>

      <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_300px]">
        <section>
          <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><h2 className="text-xl font-extrabold tracking-tight text-[#29332a]">Explore forums <span className="ml-1 text-sm font-semibold text-[#969c92]">{filtered.length}{filtered.length !== forums.length && ` / ${forums.length}`}</span></h2><div className="flex flex-col gap-2 sm:flex-row"><label className="flex h-11 items-center gap-2 rounded-full border border-[#e2e3dc] bg-white px-4 text-[#8b9188] focus-within:border-[#9ebca2]"><Search className="h-4 w-4"/><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search communities" className="w-full bg-transparent text-sm text-[#283229] outline-none placeholder:text-[#a6aaa2] sm:w-52"/></label><select aria-label="Filter by topic" value={topicFilter} onChange={(event) => setTopicFilter(event.target.value)} className="h-11 rounded-full border border-[#e2e3dc] bg-white px-4 text-sm text-[#4f584f] outline-none focus:border-[#9ebca2]"><option>All topics</option>{TOPICS.map((item) => <option key={item}>{item}</option>)}</select></div></div>
          {loading ? <div className="flex justify-center py-24"><Loader2 className="h-7 w-7 animate-spin text-[#60956b]"/></div> : loadError ? <div className="rounded-3xl border border-amber-200 bg-amber-50 p-6 text-sm leading-6 text-amber-900"><strong>Almost ready.</strong><p className="mt-1">{loadError}</p><p className="mt-2 text-xs text-amber-800">Run the Nooklet forums database update, then refresh this page.</p><button type="button" onClick={() => void loadForums()} className="mt-4 rounded-full border border-amber-300 bg-white px-4 py-2 font-semibold">Try again</button></div> : filtered.length === 0 ? <div className="rounded-3xl border border-dashed border-[#d8ddd4] bg-white/70 px-6 py-14 text-center"><div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#e7eee5] text-[#4d7655]"><Compass className="h-6 w-6"/></div><h3 className="font-bold text-[#374139]">{search ? "No forums match that search" : "This directory is ready for its first forum"}</h3><p className="mt-2 text-sm text-[#828a80]">Start a small space for an interest, a project, or your local community.</p><button type="button" onClick={() => setCreateOpen(true)} className="mt-5 rounded-full bg-[#284f37] px-4 py-2.5 text-sm font-bold text-white">Create the first forum</button></div> : <div className="grid gap-4 md:grid-cols-2">{filtered.map((forum) => {
            const style = topicStyle[forum.topic] ?? { icon: Hash, tone: "bg-[#e9eae4] text-[#747d70]" };
            const TopicIcon = style.icon;
            return <button key={forum.id} type="button" onClick={() => setSelected(forum)} className="group rounded-[26px] border border-[#e7e7e0] bg-white p-5 text-left shadow-[0_4px_18px_rgba(42,55,43,.025)] transition hover:-translate-y-1 hover:border-[#ceddce] hover:shadow-[0_12px_32px_rgba(42,55,43,.08)]"><div className="mb-5 flex items-start justify-between"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#f0f0eb] text-2xl">{forum.emoji || "🪴"}</div><span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold ${style.tone}`}><TopicIcon className="h-3 w-3"/>{forum.topic}</span></div><h3 className="flex items-center gap-2 text-lg font-extrabold tracking-tight text-[#29332a]">{forum.name}<ArrowUpRight className="h-4 w-4 text-[#a5aca2] transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-[#4d805b]"/></h3><p className="mt-2 line-clamp-2 min-h-12 text-sm leading-6 text-[#778076]">{forum.description}</p><div className="mt-5 flex items-center justify-between border-t border-[#f0f0ec] pt-4 text-xs font-semibold text-[#8a9187]"><span>Open community</span><span className="inline-flex items-center gap-1.5"><Users className="h-3.5 w-3.5"/>Join in</span></div></button>;
          })}</div>}
        </section>

        <aside className="space-y-4 lg:pt-[58px]">
          <div className="rounded-[26px] border border-[#e6e6df] bg-[#eeefe8] p-5"><div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-white text-[#4d7655]"><Sprout className="h-5 w-5"/></div><h3 className="font-extrabold text-[#354036]">Small by design.</h3><p className="mt-2 text-sm leading-6 text-[#717a70]">No algorithmic firehose. Just a collection of focused spaces where people can actually get to know each other.</p></div>
          <div className="rounded-[26px] border border-[#e7e7e0] bg-white p-5"><h3 className="text-sm font-extrabold text-[#354036]">A good forum starts with…</h3><ul className="mt-4 space-y-3 text-sm text-[#727b71]">{["One clear shared interest","A welcoming first post","Room for curious questions"].map((item) => <li key={item} className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[#5b9267]"/>{item}</li>)}</ul></div>
          <button type="button" onClick={() => setCreateOpen(true)} className="flex w-full items-center justify-between rounded-[22px] border border-[#d7e4d6] bg-[#e9f1e6] p-4 text-left transition hover:bg-[#e1eddf]"><span><span className="block text-sm font-bold text-[#31583b]">Have an idea?</span><span className="mt-1 block text-xs text-[#68806a]">Make it a forum in a minute.</span></span><Plus className="h-5 w-5 text-[#4d805b]"/></button>
        </aside>
      </div>

      {createOpen && <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-[#20251f]/55 p-4 backdrop-blur-sm" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget && !creating) setCreateOpen(false); }}><section role="dialog" aria-modal="true" aria-labelledby="create-forum-title" className="my-auto w-full max-w-xl rounded-[30px] border border-white/70 bg-[#fbfaf7] p-6 shadow-2xl sm:p-8"><div className="mb-6 flex items-start justify-between"><div><div className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-[#5b9267]">Start a little community</div><h2 id="create-forum-title" className="text-2xl font-black tracking-tight text-[#273229]">Create a forum</h2><p className="mt-1 text-sm text-[#80877d]">Give your people a place to gather.</p></div><button type="button" onClick={() => setCreateOpen(false)} className="rounded-full border border-[#e2e2dc] p-2 text-[#778076] hover:bg-white" aria-label="Close"><X className="h-4 w-4"/></button></div><form onSubmit={(event) => void createForum(event)} className="space-y-5"><div className="flex flex-wrap gap-2">{EMOJIS.map((choice,index)=><button key={`${choice}-${index}`} type="button" onClick={()=>setEmoji(choice)} aria-label={`Choose ${choice}`} className={`flex h-10 w-10 items-center justify-center rounded-xl text-xl transition ${emoji===choice?"bg-[#e5efe3] ring-2 ring-[#6b9e72]":"bg-white ring-1 ring-[#e5e6df] hover:bg-[#f2f3ed]"}`}>{choice}</button>)}</div><label className="block"><span className="mb-1.5 block text-xs font-bold text-[#596358]">Forum name</span><input required minLength={2} maxLength={48} value={name} onChange={(event)=>setName(event.target.value)} placeholder="The Sunday Garden Club" className="w-full rounded-2xl border border-[#dedfd7] bg-white px-4 py-3 text-sm outline-none placeholder:text-[#a5aaa1] focus:border-[#88ad8d] focus:ring-4 focus:ring-[#70a27a]/10"/></label><label className="block"><span className="mb-1.5 block text-xs font-bold text-[#596358]">What is this space for?</span><textarea required minLength={4} maxLength={240} rows={3} value={description} onChange={(event)=>setDescription(event.target.value)} placeholder="A friendly place to talk about…" className="w-full resize-none rounded-2xl border border-[#dedfd7] bg-white px-4 py-3 text-sm outline-none placeholder:text-[#a5aaa1] focus:border-[#88ad8d] focus:ring-4 focus:ring-[#70a27a]/10"/></label><label className="block"><span className="mb-1.5 block text-xs font-bold text-[#596358]">Topic</span><select value={topic} onChange={(event)=>setTopic(event.target.value)} className="w-full rounded-2xl border border-[#dedfd7] bg-white px-4 py-3 text-sm text-[#424b42] outline-none focus:border-[#88ad8d]">{TOPICS.map((item)=><option key={item}>{item}</option>)}</select></label>{createError&&<p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{createError}</p>}<div className="flex justify-end gap-3 pt-1"><button type="button" onClick={()=>setCreateOpen(false)} className="rounded-full px-4 py-2.5 text-sm font-semibold text-[#727a70] hover:bg-[#efefe9]">Cancel</button><button type="submit" disabled={creating||!name.trim()||!description.trim()} className="inline-flex items-center gap-2 rounded-full bg-[#284f37] px-5 py-2.5 text-sm font-bold text-white transition hover:bg-[#1f422d] disabled:opacity-50">{creating?<Loader2 className="h-4 w-4 animate-spin"/>:<Plus className="h-4 w-4"/>}Create forum</button></div></form></section></div>}
    </div>
  );
}
