import { useMemo } from "react";
import type { WeatherResponse, WeatherMeme, GeoResult } from "@/types";
import type { LanguageCode } from "@/lib/i18n";
import type { TempUnit } from "@/lib/temperature";
import { getMemesForWeather, getCondition, getVibeSummary } from "@/lib/memes";
import { WeatherDisplay } from "@/components/WeatherDisplay";
import { HourlyStrip } from "@/components/HourlyStrip";
import { Forecast } from "@/components/Forecast";
import { MemeCard } from "@/components/MemeCard";
import { MapPin, X, Loader2 } from "lucide-react";

export interface CitySlideData {
  id: string;
  geo: GeoResult;
  weather: WeatherResponse | null;
  loading: boolean;
  error: string | null;
}

interface WeatherSlideProps {
  slide: CitySlideData;
  uiLang: LanguageCode;
  memeLang: LanguageCode;
  unit: TempUnit;
  onRemove: (id: string) => void;
}

export function WeatherSlide({ slide, uiLang, memeLang, unit, onRemove }: WeatherSlideProps) {
  const memes = useMemo<WeatherMeme[]>(() => {
    if (!slide.weather) return [];
    const condition = getCondition(slide.weather.current.weather_code);
    const temp = slide.weather.current.apparent_temperature;
    return getMemesForWeather(temp, condition, memeLang, 2, unit);
  }, [slide.weather, memeLang, unit]);

  const vibeSummary = useMemo(() => {
    if (!slide.weather) return "";
    const condition = getCondition(slide.weather.current.weather_code);
    const temp = slide.weather.current.apparent_temperature;
    return getVibeSummary(temp, condition);
  }, [slide.weather]);

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-start overflow-y-auto snap-center px-4 py-6 sm:py-10">
      <button
        onClick={() => onRemove(slide.id)}
        className="absolute top-4 right-4 z-20 w-9 h-9 rounded-full bg-white/10 backdrop-blur-md border border-white/15 flex items-center justify-center text-slate-400 hover:text-red-400 hover:bg-red-500/15 transition-all"
      >
        <X className="w-4 h-4" />
      </button>

      <div className="relative z-10 w-full max-w-2xl">
        <div className="flex items-center gap-2 mb-6 text-slate-300">
          <MapPin className="w-5 h-5 text-cyan-400" />
          <h2 className="text-xl font-bold text-white">{slide.geo.name}</h2>
          {slide.geo.country && (
            <span className="text-sm text-slate-400">
              {[slide.geo.admin1, slide.geo.country].filter(Boolean).join(", ")}
            </span>
          )}
        </div>

        {slide.loading && (
          <div className="flex flex-col items-center justify-center py-32">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin mb-3" />
            <p className="text-slate-400 text-sm">Loading...</p>
          </div>
        )}

        {slide.error && !slide.loading && (
          <div className="flex items-center gap-3 px-5 py-4 rounded-2xl bg-red-500/15 border border-red-500/30 mb-6">
            <span className="text-red-200 text-sm">{slide.error}</span>
          </div>
        )}

        {slide.weather && !slide.loading && (
          <div className="space-y-6">
            <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5 sm:p-6">
              <WeatherDisplay
                current={slide.weather.current}
                location={slide.geo.name}
                region={[slide.geo.admin1, slide.geo.country].filter(Boolean).join(", ")}
                timezone={slide.weather.timezone}
                uiLang={uiLang}
                unit={unit}
              />
            </div>

            <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5">
              <HourlyStrip hourly={slide.weather.hourly} uiLang={uiLang} unit={unit} />
            </div>

            <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-5">
              <Forecast daily={slide.weather.daily} uiLang={uiLang} unit={unit} />
            </div>

            <div>
              <p className="text-slate-400 text-sm mb-4">{vibeSummary}</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {memes.map((meme) => (
                  <MemeCard key={meme.id} meme={meme} memeLang={memeLang} />
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
