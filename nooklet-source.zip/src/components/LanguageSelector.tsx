import { useState, useRef, useLayoutEffect } from "react";
import { createPortal } from "react-dom";
import { Globe, Languages, ChevronDown, Check } from "lucide-react";
import { LANGUAGES, type LanguageCode } from "@/lib/i18n";

interface LanguageSelectorProps {
  uiLang: LanguageCode;
  memeLang: LanguageCode;
  onUiLangChange: (lang: LanguageCode) => void;
  onMemeLangChange: (lang: LanguageCode) => void;
  labels: { uiLanguage: string; memeLanguage: string };
}

interface PanelPosition {
  top: number;
  left: number;
  maxHeight: number;
}

const PANEL_WIDTH = 320;
const PANEL_HEIGHT = 360;
const VIEWPORT_GUTTER = 12;

export function LanguageSelector({ uiLang, memeLang, onUiLangChange, onMemeLangChange, labels }: LanguageSelectorProps) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<"ui" | "meme">("ui");
  const [panelPosition, setPanelPosition] = useState<PanelPosition | null>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!open) return;
    const updatePosition = () => {
      const rect = triggerRef.current?.getBoundingClientRect();
      if (!rect) return;
      const width = Math.min(PANEL_WIDTH, window.innerWidth - VIEWPORT_GUTTER * 2);
      const below = window.innerHeight - rect.bottom - VIEWPORT_GUTTER;
      const above = rect.top - VIEWPORT_GUTTER;
      const openAbove = below < Math.min(PANEL_HEIGHT, 320) && above > below;
      const maxHeight = Math.max(180, Math.min(PANEL_HEIGHT, openAbove ? above : below));
      const top = openAbove ? Math.max(VIEWPORT_GUTTER, rect.top - maxHeight - 8) : rect.bottom + 8;
      const left = Math.max(VIEWPORT_GUTTER, Math.min(rect.right - width, window.innerWidth - width - VIEWPORT_GUTTER));
      setPanelPosition({ top, left, maxHeight });
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    const handlePointerDown = (event: PointerEvent) => {
      const target = event.target as Node;
      if (!triggerRef.current?.contains(target) && !panelRef.current?.contains(target)) setOpen(false);
    };
    updatePosition();
    window.addEventListener("resize", updatePosition);
    window.addEventListener("scroll", updatePosition, true);
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("pointerdown", handlePointerDown);
    return () => {
      window.removeEventListener("resize", updatePosition);
      window.removeEventListener("scroll", updatePosition, true);
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [open]);

  const uiLanguage = LANGUAGES.find((language) => language.code === uiLang) ?? LANGUAGES[0];
  const panel = open && panelPosition && createPortal(
    <div
      ref={panelRef}
      role="dialog"
      aria-label={activeTab === "ui" ? labels.uiLanguage : labels.memeLanguage}
      style={{ top: panelPosition.top, left: panelPosition.left, maxHeight: panelPosition.maxHeight }}
      className="fixed z-[10000] flex w-[min(20rem,calc(100vw-1.5rem))] flex-col overflow-hidden rounded-2xl border border-white/15 bg-slate-950 text-slate-100 shadow-[0_20px_60px_rgba(0,0,0,0.7)] ring-1 ring-black/40"
    >
      <div className="grid shrink-0 grid-cols-2 gap-1 border-b border-white/10 bg-slate-900 p-2">
        <button type="button" onClick={() => setActiveTab("ui")} aria-pressed={activeTab === "ui"} className={`flex min-w-0 items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-xs font-semibold transition-colors ${activeTab === "ui" ? "bg-cyan-500/20 text-cyan-100" : "text-slate-300 hover:bg-white/10"}`}>
          <Globe className="h-4 w-4 shrink-0" /><span className="truncate">{labels.uiLanguage}</span>
        </button>
        <button type="button" onClick={() => setActiveTab("meme")} aria-pressed={activeTab === "meme"} className={`flex min-w-0 items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-xs font-semibold transition-colors ${activeTab === "meme" ? "bg-orange-500/20 text-orange-100" : "text-slate-300 hover:bg-white/10"}`}>
          <Languages className="h-4 w-4 shrink-0" /><span className="truncate">{labels.memeLanguage}</span>
        </button>
      </div>
      <div className="grid min-h-0 grid-cols-2 gap-1 overflow-y-auto overscroll-contain p-2">
        {LANGUAGES.map((language) => {
          const selected = activeTab === "ui" ? uiLang === language.code : memeLang === language.code;
          return (
            <button
              key={language.code}
              type="button"
              onClick={() => {
                if (activeTab === "ui") onUiLangChange(language.code);
                else onMemeLangChange(language.code);
                setOpen(false);
              }}
              aria-pressed={selected}
              className={`flex min-w-0 items-center gap-2 rounded-lg px-2.5 py-2.5 text-left text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 ${selected ? (activeTab === "ui" ? "bg-cyan-500/25 text-cyan-100" : "bg-orange-500/25 text-orange-100") : "text-slate-200 hover:bg-white/10"}`}
            >
              <span className="shrink-0 text-base">{language.flag}</span>
              <span className="truncate">{language.name}</span>
              {selected && <Check className="ml-auto h-4 w-4 shrink-0" />}
            </button>
          );
        })}
      </div>
    </div>,
    document.body,
  );

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        onClick={() => { setActiveTab("ui"); setOpen((current) => !current); }}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label={`${labels.uiLanguage}: ${uiLanguage.name}`}
        className="flex min-w-0 items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100 transition-colors hover:border-cyan-300/40 hover:bg-white/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
      >
        <Globe className="h-4 w-4 shrink-0 text-cyan-300" />
        <span className="hidden sm:inline">{uiLanguage.flag} {uiLanguage.name}</span>
        <span className="sm:hidden">{uiLanguage.flag}</span>
        <ChevronDown className={`h-4 w-4 shrink-0 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {panel}
    </>
  );
}
