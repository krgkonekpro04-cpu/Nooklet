import { useState, useCallback } from "react";
import { supabase } from "@/lib/supabase";
import { Logo } from "@/components/Logo";
import { Loader2, Mail, Lock, User, X } from "lucide-react";

interface AuthScreenProps {
  onAuthed: () => void;
  onCancel?: () => void;
}

const AVATAR_OPTIONS = ["🪴", "📚", "🧶", "🎨", "🎮", "☕", "🛠️", "🍳", "🚲", "🪐", "✍️", "🐈"];

export function AuthScreen({ onAuthed, onCancel }: AuthScreenProps) {
  const [mode, setMode] = useState<"signin" | "signup">("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [avatar, setAvatar] = useState("🪴");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (mode === "signup") {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { username, avatar_emoji: avatar } },
        });
        if (signUpError) throw signUpError;
        onAuthed();
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) throw signInError;
        onAuthed();
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Authentication failed";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [mode, email, password, username, avatar, onAuthed]);

  return (
    <div className="nooklet-auth flex min-h-[620px] items-center justify-center px-4 py-6 text-[#202a22]">
      <div className="w-full max-w-md">
        {onCancel && (
          <button onClick={onCancel} aria-label="Close sign in" className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10">
            <X className="w-5 h-5" />
          </button>
        )}
        <div className="flex flex-col items-center mb-8">
          <Logo size={64} className="mb-3 drop-shadow-lg" />
          <h1 className="text-3xl font-bold tracking-tight">
            nooklet
          </h1>
          <p className="mt-2 text-center text-sm text-[#7a8378]">
            Best place for small forums.
          </p>
        </div>

        <div className="rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 p-6 sm:p-8">
          <div className="flex gap-2 mb-6 p-1 rounded-2xl bg-white/5 border border-white/10">
            <button
              onClick={() => setMode("signup")}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
                mode === "signup" ? "bg-cyan-500/20 text-cyan-300" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Sign Up
            </button>
            <button
              onClick={() => setMode("signin")}
              className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
                mode === "signin" ? "bg-cyan-500/20 text-cyan-300" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Sign In
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <>
                <div>
                  <label className="text-xs text-slate-400 mb-1.5 block">Forum Username</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      required
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Your name around here"
                      className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white/10 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-slate-400 mb-1.5 block">Pick your avatar emoji</label>
                  <div className="flex flex-wrap gap-2">
                    {AVATAR_OPTIONS.map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setAvatar(emoji)}
                        className={`w-10 h-10 rounded-xl text-xl transition-all ${
                          avatar === emoji
                            ? "bg-cyan-500/20 border-2 border-cyan-400/50 scale-110"
                            : "bg-white/5 border border-white/10 hover:bg-white/10"
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white/10 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-xs text-slate-400 mb-1.5 block">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full pl-10 pr-4 py-3 rounded-2xl bg-white/10 border border-white/15 text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 transition-all"
                />
              </div>
            </div>

            {error && (
              <div className="px-4 py-3 rounded-2xl bg-red-500/15 border border-red-500/30 text-red-200 text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-white font-semibold transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 shadow-lg shadow-cyan-500/30"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                mode === "signup" ? "Create Account & Join Forum" : "Sign In"
              )}
            </button>
          </form>
        </div>

        <p className="text-center text-slate-500 text-xs mt-6">
          Make a home for the things you love and the people who love them too.
        </p>
      </div>
    </div>
  );
}
