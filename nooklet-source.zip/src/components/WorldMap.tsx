import { useRef, useEffect, useState, useCallback } from "react";

interface WorldMapProps {
  onLocationSelect: (lat: number, lon: number) => void;
}

interface GeoFeature {
  type: string;
  geometry: { type: string; coordinates: number[][][] | number[][][][] };
}

interface GeoCollection {
  type: string;
  features: GeoFeature[];
}

function project(lon: number, lat: number, width: number, height: number): [number, number] {
  const x = ((lon + 180) / 360) * width;
  const y = ((90 - lat) / 180) * height;
  return [x, y];
}

export function WorldMap({ onLocationSelect }: WorldMapProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [geoData, setGeoData] = useState<GeoCollection | null>(null);
  const [loading, setLoading] = useState(true);
  const [mapError, setMapError] = useState(false);
  const [hoverPos, setHoverPos] = useState<{ lon: number; lat: number; x: number; y: number } | null>(null);
  const [marker, setMarker] = useState<{ x: number; y: number } | null>(null);
  const [size, setSize] = useState({ width: 800, height: 400 });

  const loadMapData = useCallback(() => {
    setLoading(true);
    setMapError(false);
    fetch(`${import.meta.env.BASE_URL}custom.geo_minified.json`)
      .then((res) => {
        if (!res.ok) throw new Error("Map data request failed");
        return res.json();
      })
      .then((data: GeoCollection) => {
        setGeoData(data);
        setLoading(false);
      })
      .catch(() => {
        setGeoData(null);
        setMapError(true);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    loadMapData();
  }, [loadMapData]);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const w = entry.contentRect.width;
        const h = Math.min(w * 0.5, 500);
        setSize({ width: w, height: h });
      }
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Draw map (static — no animation loop)
  useEffect(() => {
    if (!canvasRef.current || !geoData) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = size.width * dpr;
    canvas.height = size.height * dpr;
    canvas.style.width = `${size.width}px`;
    canvas.style.height = `${size.height}px`;
    ctx.scale(dpr, dpr);

    ctx.fillStyle = "#0f172a";
    ctx.fillRect(0, 0, size.width, size.height);

    ctx.strokeStyle = "rgba(34, 211, 238, 0.05)";
    ctx.lineWidth = 1;
    for (let lat = -80; lat <= 80; lat += 20) {
      const [, y] = project(0, lat, size.width, size.height);
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(size.width, y);
      ctx.stroke();
    }
    for (let lon = -180; lon <= 180; lon += 20) {
      const [x] = project(lon, 0, size.width, size.height);
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, size.height);
      ctx.stroke();
    }

    ctx.fillStyle = "rgba(34, 211, 238, 0.15)";
    ctx.strokeStyle = "rgba(34, 211, 238, 0.4)";
    ctx.lineWidth = 0.8;

    for (const feature of geoData.features) {
      const geom = feature.geometry;
      if (geom.type === "Polygon") {
        const rings = geom.coordinates as number[][][];
        for (const ring of rings) {
          ctx.beginPath();
          ring.forEach((point, i) => {
            const [x, y] = project(point[0], point[1], size.width, size.height);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          });
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
        }
      } else if (geom.type === "MultiPolygon") {
        const polys = geom.coordinates as number[][][][];
        for (const poly of polys) {
          for (const ring of poly) {
            ctx.beginPath();
            ring.forEach((point, i) => {
              const [x, y] = project(point[0], point[1], size.width, size.height);
              if (i === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            });
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
          }
        }
      }
    }
  }, [geoData, size]);

  const handleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const lon = (x / size.width) * 360 - 180;
    const lat = 90 - (y / size.height) * 180;
    setMarker({ x, y });
    onLocationSelect(lat, lon);
  }, [size, onLocationSelect]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const lon = (x / size.width) * 360 - 180;
    const lat = 90 - (y / size.height) * 180;
    setHoverPos({ lon, lat, x, y });
  }, [size]);

  return (
    <div ref={containerRef} className="relative w-full rounded-3xl bg-slate-950 border border-cyan-400/20 overflow-hidden">
      {loading ? (
        <div className="flex items-center justify-center h-[400px]">
          <div className="text-cyan-400 text-sm animate-pulse">Loading world map...</div>
        </div>
      ) : geoData ? (
        <>
          <canvas
            ref={canvasRef}
            onClick={handleClick}
            onMouseMove={handleMouseMove}
            onMouseLeave={() => setHoverPos(null)}
            className="cursor-crosshair block"
            style={{ width: size.width, height: size.height }}
          />
          {/* CSS-animated marker overlay — no RAF loop */}
          {marker && (
            <div
              className="absolute pointer-events-none"
              style={{ left: marker.x - 16, top: marker.y - 16 }}
            >
              <div className="relative w-8 h-8">
                <span className="absolute inset-0 rounded-full border-2 border-orange-400/60 animate-ping" />
                <span className="absolute inset-2 rounded-full bg-orange-400 border-2 border-white shadow-lg" />
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="flex flex-col items-center justify-center gap-3 h-[400px] px-6 text-center">
          <p className="text-slate-300 text-sm">{mapError ? "The map couldn’t load." : "Map data is unavailable."} You can still search for a city above.</p>
          <button onClick={loadMapData} className="px-4 py-2 rounded-xl bg-cyan-500/15 border border-cyan-400/30 text-cyan-200 text-sm hover:bg-cyan-500/25">Try again</button>
        </div>
      )}

      {hoverPos && !loading && (
        <div
          className="absolute pointer-events-none px-3 py-1.5 rounded-lg bg-slate-800/90 border border-cyan-400/30 text-xs text-cyan-300 font-mono backdrop-blur-sm z-10"
          style={{
            left: Math.min(hoverPos.x + 12, size.width - 120),
            top: Math.max(hoverPos.y - 32, 8),
          }}
        >
          {hoverPos.lat >= 0 ? "+" : ""}{hoverPos.lat.toFixed(1)}°, {hoverPos.lon >= 0 ? "+" : ""}{hoverPos.lon.toFixed(1)}°
        </div>
      )}
    </div>
  );
}
