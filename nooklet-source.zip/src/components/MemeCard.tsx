import { useState, useEffect, useCallback, useMemo } from "react";
import type { WeatherMeme, MemeReaction } from "@/types";
import { getReactions, addReaction, removeReaction } from "@/lib/reactions";
import { getTranslatedMeme } from "@/lib/meme-i18n";
import type { LanguageCode } from "@/lib/i18n";
import { Sparkles } from "lucide-react";
import { playSound } from "@/lib/sounds";

interface MemeCardProps {
  meme: WeatherMeme;
  memeLang?: LanguageCode;
}

export function MemeCard({ meme, memeLang = "en" }: MemeCardProps) {
  const [reactions, setReactions] = useState<MemeReaction[]>([]);
  const [reactedEmojis, setReactedEmojis] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  const translated = useMemo(() => {
    if (memeLang === "en") return null;
    return getTranslatedMeme(meme.id, memeLang);
  }, [meme.id, memeLang]);

  const overlayText = translated?.boxes ?? meme.overlayText;
  const caption = translated?.caption ?? meme.caption;
  const vibe = translated?.vibe ?? meme.vibe;

  const loadReactions = useCallback(async () => {
    const data = await getReactions(meme.id);
    setReactions(data);
    setLoading(false);
  }, [meme.id]);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(`reacted_${meme.id}`);
      if (stored) {
        const parsed: unknown = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.every((item) => typeof item === "string")) {
          setReactedEmojis(new Set(parsed));
        } else {
          setReactedEmojis(new Set());
        }
      } else {
        setReactedEmojis(new Set());
      }
    } catch {
      setReactedEmojis(new Set());
    }
    loadReactions();
  }, [meme.id, loadReactions]);

  const handleReact = async (emoji: string) => {
    const hasReacted = reactedEmojis.has(emoji);
    try {
      if (hasReacted) {
        await removeReaction(meme.id, emoji);
        const next = new Set(reactedEmojis);
        next.delete(emoji);
        setReactedEmojis(next);
        localStorage.setItem(`reacted_${meme.id}`, JSON.stringify([...next]));
      } else {
        await addReaction(meme.id, emoji);
        const next = new Set(reactedEmojis);
        next.add(emoji);
        setReactedEmojis(next);
        localStorage.setItem(`reacted_${meme.id}`, JSON.stringify([...next]));
        playSound("tada");
      }
      loadReactions();
    } catch {
      // Error already logged in lib
    }
  };

  const getCount = (emoji: string): number => {
    return reactions.find((r) => r.emoji === emoji)?.count ?? 0;
  };

  const boxes = overlayText.filter((t) => t.length > 0);
  const hasTop = boxes.length > 0;
  const hasBottom = boxes.length > 1;
  const hasMiddle = boxes.length > 2;

  return (
    <div className="group relative overflow-hidden rounded-3xl bg-white/5 backdrop-blur-md border border-white/10 transition-all hover:border-cyan-400/30 hover:shadow-2xl hover:shadow-cyan-500/10">
      <div className="relative aspect-square overflow-hidden bg-slate-950">
        <img
          src={meme.imageUrl}
          alt={meme.title}
          loading="lazy"
          className="w-full h-full object-contain transition-transform duration-700 group-hover:scale-105"
        />
        {hasTop && (
          <div className="absolute top-0 left-0 right-0 flex justify-center px-2">
            <span className="meme-overlay-text meme-overlay-top">{boxes[0]}</span>
          </div>
        )}
        {hasMiddle && (
          <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 flex justify-center px-2">
            <span className="meme-overlay-text meme-overlay-middle">{boxes[1]}</span>
          </div>
        )}
        {hasBottom && (
          <div className="absolute bottom-0 left-0 right-0 flex justify-center px-2">
            <span className="meme-overlay-text meme-overlay-bottom">{boxes[hasMiddle ? 2 : 1]}</span>
          </div>
        )}
      </div>

      <div className="p-5">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-4 h-4 text-cyan-400 flex-shrink-0" />
          <span className="text-xs font-medium text-cyan-300 uppercase tracking-wider">{vibe}</span>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed italic mb-4">{caption}</p>

        <div className="flex flex-wrap gap-2">
          {meme.reactions.map((emoji) => {
            const count = getCount(emoji);
            const hasReacted = reactedEmojis.has(emoji);
            return (
              <button
                key={emoji}
                onClick={() => handleReact(emoji)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-full border transition-all active:scale-90 ${
                  hasReacted
                    ? "bg-cyan-500/30 border-cyan-400/60 scale-105"
                    : "bg-white/5 border-white/10 hover:bg-white/10 hover:border-white/20"
                }`}
              >
                <span className="text-lg">{emoji}</span>
                <span className={`text-xs font-semibold ${hasReacted ? "text-cyan-300" : "text-slate-400"}`}>
                  {loading ? "··" : count}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
