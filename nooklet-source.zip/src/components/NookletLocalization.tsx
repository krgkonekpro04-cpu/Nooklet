import { useEffect } from "react";

export const NOOKLET_LANGUAGES = [
  ["en", "English"], ["es", "Español"], ["zh-CN", "简体中文"], ["hi", "हिन्दी"],
  ["ar", "العربية"], ["pt", "Português"], ["bn", "বাংলা"], ["ru", "Русский"],
  ["ja", "日本語"], ["fr", "Français"], ["de", "Deutsch"], ["ur", "اردو"],
  ["id", "Bahasa Indonesia"], ["tr", "Türkçe"], ["ko", "한국어"], ["vi", "Tiếng Việt"],
  ["it", "Italiano"], ["pl", "Polski"], ["fa", "فارسی"], ["sw", "Kiswahili"],
] as const;

export type NookletLanguage = typeof NOOKLET_LANGUAGES[number][0];
const CACHE_PREFIX = "nooklet-ui-translation-v1:";
const ATTRIBUTES = ["placeholder", "title", "aria-label", "aria-description", "alt"] as const;

type NodeRecord = { source: string; translated: string };
// Keep originals across language changes and rerenders so switching languages never
// translates a previous translation or leaves stale copy behind.
const textSources = new WeakMap<Node, NodeRecord>();
const attributeSources = new WeakMap<Element, Map<string, NodeRecord>>();

function readCache(language: NookletLanguage): Record<string, string> {
  try { return JSON.parse(localStorage.getItem(`${CACHE_PREFIX}${language}`) ?? "{}") as Record<string, string>; }
  catch { return {}; }
}

async function translateText(text: string, language: NookletLanguage): Promise<string | null> {
  if (window.nookletDesktop) {
    return window.nookletDesktop.translateInterfaceText(text, language);
  }
  try {
    const query = new URLSearchParams({ client: "gtx", sl: "en", tl: language, dt: "t", q: text });
    const response = await fetch(`https://translate.googleapis.com/translate_a/single?${query.toString()}`);
    if (!response.ok) return null;
    const payload = await response.json() as [Array<[string]>];
    const result = payload[0]?.map((part) => part[0]).join("").trim();
    return result || null;
  } catch { return null; }
}

/** Translates only visible interface text; post bodies and editable user content are excluded. */
export function NookletLocalization({ language }: { language: NookletLanguage }) {
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = ["ar", "ur", "fa"].includes(language) ? "rtl" : "ltr";
    const root = document.querySelector<HTMLElement>(".nooklet-root");
    if (!root) return;

    if (language === "en") {
      root.querySelectorAll("*").forEach((element) => {
        element.childNodes.forEach((node) => {
          if (node.nodeType !== Node.TEXT_NODE) return;
          const record = textSources.get(node);
          if (record && node.nodeValue?.trim() === record.translated.trim()) node.nodeValue = record.source;
        });
        for (const attribute of ATTRIBUTES) {
          const record = attributeSources.get(element)?.get(attribute);
          if (record && element.getAttribute(attribute) === record.translated) element.setAttribute(attribute, record.source);
        }
      });
      return;
    }

    let cancelled = false;
    const cache = readCache(language);
    const pendingNodes = new Map<Node, { attr: string | null; source: string; prefix: string; suffix: string }>();
    let flushTimer = 0;
    let busy = false;

    const setNode = (node: Node, translation: string, attr: string | null, source: string) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const current = node.nodeValue ?? "";
        const prefix = current.match(/^\s*/)?.[0] ?? "";
        const suffix = current.match(/\s*$/)?.[0] ?? "";
        const value = `${prefix}${translation}${suffix}`;
        textSources.set(node, { source: `${prefix}${source}${suffix}`, translated: value });
        if (current !== value) node.nodeValue = value;
      } else if (attr && node instanceof Element) {
        const map = attributeSources.get(node) ?? new Map<string, NodeRecord>();
        map.set(attr, { source, translated: translation }); attributeSources.set(node, map);
        if (node.getAttribute(attr) !== translation) node.setAttribute(attr, translation);
      }
    };

    const drain = async () => {
      if (busy || cancelled || pendingNodes.size === 0) return;
      busy = true;
      const jobs = [...pendingNodes.entries()]; pendingNodes.clear();
      const uncached = [...new Set(jobs.map(([, job]) => job.source).filter((source) => !(source in cache)))];
      // Keep the request small and bounded. The source is fixed interface copy, never a post or profile value.
      for (let index = 0; index < uncached.length; index += 4) {
        if (cancelled) break;
        const batch = uncached.slice(index, index + 4);
        const values = await Promise.all(batch.map((source) => translateText(source, language)));
        batch.forEach((source, itemIndex) => { if (values[itemIndex]) cache[source] = values[itemIndex]!; });
        try { localStorage.setItem(`${CACHE_PREFIX}${language}`, JSON.stringify(cache)); } catch { /* Translation still works if storage is full. */ }
      }
      if (!cancelled) {
        for (const [node, job] of jobs) {
          const translation = cache[job.source];
          if (translation) setNode(node, translation, job.attr, job.source);
        }
      }
      busy = false;
      if (!cancelled && pendingNodes.size > 0) void drain();
    };

    const enqueue = (node: Node, source: string, attr: string | null, prefix = "", suffix = "") => {
      const phrase = source.trim();
      if (!phrase || phrase.length > 240 || !/[A-Za-z]/.test(phrase)) return;
      if (phrase in cache) { setNode(node, `${prefix}${cache[phrase]}${suffix}`, attr, phrase); return; }
      pendingNodes.set(node, { attr, source: phrase, prefix, suffix });
      window.clearTimeout(flushTimer);
      flushTimer = window.setTimeout(() => void drain(), 80);
    };

    const scan = (node: Node) => {
      if (node.nodeType === Node.TEXT_NODE) {
        const parent = node.parentElement;
        if (!parent || parent.closest("article, input, textarea, script, style, [data-user-content], [data-no-translate], [contenteditable='true']")) return;
        const current = node.nodeValue ?? "";
        const previous = textSources.get(node);
        const original = previous?.translated.trim() === current.trim() ? previous.source : current.trim();
        if (original !== previous?.source) textSources.set(node, { source: original, translated: previous?.translated ?? "" });
        const prefix = current.match(/^\s*/)?.[0] ?? "";
        const suffix = current.match(/\s*$/)?.[0] ?? "";
        enqueue(node, original, null, prefix, suffix);
        return;
      }
      if (node instanceof Element) {
        if (node.closest("article, [data-user-content]")) return;
        for (const attribute of ATTRIBUTES) {
          const current = node.getAttribute(attribute);
          if (!current) continue;
          const previous = attributeSources.get(node)?.get(attribute);
          const original = previous?.translated === current ? previous.source : current;
          if (previous?.translated !== current) {
            const map = attributeSources.get(node) ?? new Map<string, NodeRecord>();
            map.set(attribute, { source: original, translated: previous?.translated ?? "" }); attributeSources.set(node, map);
          }
          enqueue(node, original, attribute);
        }
        node.childNodes.forEach(scan);
      }
    };

    scan(root);
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "characterData") scan(mutation.target);
        else if (mutation.type === "attributes") scan(mutation.target);
        else mutation.addedNodes.forEach(scan);
      }
    });
    observer.observe(root, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: [...ATTRIBUTES] });
    return () => { cancelled = true; observer.disconnect(); window.clearTimeout(flushTimer); };
  }, [language]);

  return null;
}
