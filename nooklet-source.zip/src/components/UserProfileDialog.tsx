import { useCallback, useEffect, useState } from "react";
import { BadgeCheck, Heart, Loader2, UserRoundPlus, UserRoundCheck, X } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { t, type LanguageCode } from "@/lib/i18n";
import { getCommunityError, isMissingColumn } from "@/lib/community-compat";

interface ProfileRecord {
  id: string;
  username: string;
  avatar_emoji: string | null;
  avatar_url: string | null;
}

interface ProfilePost {
  id: string;
  body: string;
  photo_url: string | null;
  created_at: string;
  like_count: number;
}

interface UserProfileDialogProps {
  profileId: string;
  viewerId: string;
  currentUsername: string;
  currentAvatarEmoji: string;
  currentAvatarUrl: string | null;
  developerUserId?: string;
  uiLang: LanguageCode;
  onClose: () => void;
}

function ProfileAvatar({ url, emoji, className }: { url: string | null; emoji: string | null; className: string }) {
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  if (url && failedUrl !== url) {
    return <img src={url} alt="" onError={() => setFailedUrl(url)} className={`${className} object-cover`} />;
  }
  return <span className={`${className} flex items-center justify-center bg-white/10 text-3xl`}>{emoji || "🪴"}</span>;
}

export function UserProfileDialog({ profileId, viewerId, currentUsername, currentAvatarEmoji, currentAvatarUrl, developerUserId, uiLang, onClose }: UserProfileDialogProps) {
  const [profile, setProfile] = useState<ProfileRecord | null>(null);
  const [posts, setPosts] = useState<ProfilePost[]>([]);
  const [stats, setStats] = useState({ posts: 0, subscribers: 0, likes: 0 });
  const [following, setFollowing] = useState(false);
  const [busy, setBusy] = useState(true);
  const [followBusy, setFollowBusy] = useState(false);
  const [followAvailable, setFollowAvailable] = useState(true);
  const [statsNote, setStatsNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const isSelf = profileId === viewerId;
  const isDeveloper = Boolean(developerUserId && profileId === developerUserId);

  const loadProfile = useCallback(async () => {
    setBusy(true);
    setError(null);
    setProfile(null);
    setPosts([]);
    setStats({ posts: 0, subscribers: 0, likes: 0 });
    setFollowing(false);
    setStatsNote(null);
    const [profileResult, postsResult, statsResult, followResult] = await Promise.all([
      supabase.from("profiles").select("id, username, avatar_emoji, avatar_url").eq("id", profileId).maybeSingle(),
      supabase.from("forum_posts").select("id, username, avatar_emoji, avatar_url, body, photo_url, created_at").eq("user_id", profileId).order("created_at", { ascending: false }).limit(40),
      supabase.rpc("get_forum_profile_stats", { target_user_id: profileId }),
      isSelf ? Promise.resolve({ data: null, error: null }) : supabase.from("forum_follows").select("follower_id").eq("follower_id", viewerId).eq("followed_id", profileId).maybeSingle(),
    ]);
    let profilePosts = postsResult.data;
    let postsError = postsResult.error;
    if (postsError && isMissingColumn(postsError, "avatar_url")) {
      const legacyPosts = await supabase.from("forum_posts").select("id, username, avatar_emoji, body, photo_url, created_at").eq("user_id", profileId).order("created_at", { ascending: false }).limit(40);
      profilePosts = legacyPosts.data?.map((post) => ({ ...post, avatar_url: null })) ?? null;
      postsError = legacyPosts.error;
    }

    let profileData = profileResult.data as ProfileRecord | null;
    let profileError = profileResult.error;
    if (profileError && isMissingColumn(profileError, "avatar_url")) {
      const legacyResult = await supabase.from("profiles").select("id, username, avatar_emoji").eq("id", profileId).maybeSingle();
      profileData = legacyResult.data ? { ...legacyResult.data, avatar_url: null } as ProfileRecord : null;
      profileError = legacyResult.error;
    }
    if (!profileData) {
      const author = profilePosts?.[0];
      if (author) profileData = { id: profileId, username: author.username, avatar_emoji: author.avatar_emoji, avatar_url: author.avatar_url ?? null };
      else if (isSelf) profileData = { id: profileId, username: currentUsername, avatar_emoji: currentAvatarEmoji, avatar_url: currentAvatarUrl };
      else profileData = { id: profileId, username: `Member ${profileId.slice(0, 6)}`, avatar_emoji: "🪴", avatar_url: null };
      if (profileError && !isMissingColumn(profileError, "avatar_url")) setError(getCommunityError(profileError, t(uiLang, "profileUnavailable")));
    }
    if (isSelf && profileData) profileData = { ...profileData, avatar_url: profileData.avatar_url ?? currentAvatarUrl };
    setProfile(profileData);
    if (postsError) {
      setError(t(uiLang, "profilePostsUnavailable"));
      setPosts([]);
    } else {
      const records = profilePosts ?? [];
      const postIds = records.map((post) => post.id);
      let postLikes = new Map<string, number>();
      if (postIds.length) {
        const likeResult = await supabase.from("forum_likes").select("post_id").in("post_id", postIds);
        postLikes = new Map();
        for (const like of likeResult.data ?? []) postLikes.set(like.post_id, (postLikes.get(like.post_id) ?? 0) + 1);
      }
      setPosts(records.map((post) => ({ ...post, like_count: postLikes.get(post.id) ?? 0 })) as ProfilePost[]);
    }
    if (!statsResult.error && statsResult.data) {
      const row = Array.isArray(statsResult.data) ? statsResult.data[0] : statsResult.data;
      if (row) setStats({ posts: Number(row.post_count) || 0, subscribers: Number(row.subscriber_count) || 0, likes: Number(row.total_likes) || 0 });
    } else if (statsResult.error) {
      const allPosts = await supabase.from("forum_posts").select("id", { count: "exact" }).eq("user_id", profileId).limit(1000);
      const postIds = (allPosts.data ?? []).map((post) => post.id);
      let likesCount = 0;
      if (postIds.length) {
        const likesResult = await supabase.from("forum_likes").select("id", { count: "exact", head: true }).in("post_id", postIds);
        likesCount = likesResult.count ?? 0;
      }
      setStats({ posts: allPosts.count ?? postIds.length, subscribers: 0, likes: likesCount });
      setStatsNote(t(uiLang, "profileStatsLimited"));
    }
    if (!followResult.error && followResult.data) setFollowing(true);
    setFollowAvailable(!followResult.error);
    if (followResult.error) setStatsNote(t(uiLang, "profileStatsLimited"));
    setBusy(false);
  }, [profileId, viewerId, uiLang, isSelf, currentUsername, currentAvatarEmoji, currentAvatarUrl]);

  useEffect(() => { void loadProfile(); }, [loadProfile]);
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [onClose]);

  const toggleFollow = async () => {
    if (followBusy || isSelf) return;
    setFollowBusy(true);
    setError(null);
    try {
      const result = following
        ? await supabase.from("forum_follows").delete().eq("follower_id", viewerId).eq("followed_id", profileId)
        : await supabase.from("forum_follows").insert({ follower_id: viewerId, followed_id: profileId });
      if (result.error) throw result.error;
      setFollowing(!following);
      setStats((current) => ({ ...current, subscribers: Math.max(0, current.subscribers + (following ? -1 : 1)) }));
    } catch {
      setError(t(uiLang, "followFailed"));
    } finally {
      setFollowBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="max-h-[90vh] w-full max-w-2xl overflow-hidden rounded-3xl border border-white/15 bg-slate-900 shadow-2xl" role="dialog" aria-modal="true" aria-label={t(uiLang, "profileTitle")}>
        <div className="flex items-start justify-between gap-4 border-b border-white/10 p-5 sm:p-7">
          {profile ? (
            <div className="flex min-w-0 items-center gap-4">
              <ProfileAvatar url={profile.avatar_url} emoji={profile.avatar_emoji} className="h-16 w-16 shrink-0 rounded-full border border-white/15" />
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="break-all text-xl font-bold text-white">{profile.username}</h2>
                  {isDeveloper && <><BadgeCheck className="h-5 w-5 fill-sky-500 text-white" aria-label={t(uiLang, "verifiedDeveloper")} /><span className="rounded-full border border-sky-300/30 bg-sky-400/10 px-2.5 py-1 text-xs font-semibold text-sky-200">{t(uiLang, "developer")}</span></>}
                </div>
                <p className="mt-1 text-sm text-slate-400">{t(uiLang, "profileTitle")}</p>
                {!isSelf && followAvailable && <button type="button" disabled={followBusy} onClick={() => void toggleFollow()} className="mt-3 inline-flex items-center gap-2 rounded-xl border border-cyan-300/25 bg-cyan-400/10 px-3 py-1.5 text-sm font-semibold text-cyan-100 hover:bg-cyan-400/20 disabled:opacity-60">{followBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : following ? <UserRoundCheck className="h-4 w-4" /> : <UserRoundPlus className="h-4 w-4" />}{t(uiLang, following ? "following" : "subscribe")}</button>}
              </div>
            </div>
          ) : <div className="h-16" />}
          <button type="button" onClick={onClose} aria-label={t(uiLang, "close")} className="rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 hover:bg-white/10"><X className="h-5 w-5" /></button>
        </div>
        {busy ? <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-cyan-300" /></div> : (
          <div className="max-h-[calc(90vh-110px)] overflow-y-auto p-5 sm:p-7">
            {error && <p className="mb-4 rounded-xl border border-rose-300/20 bg-rose-400/10 p-3 text-sm text-rose-100">{error}</p>}
            <div className="mb-6 grid grid-cols-3 gap-2 sm:gap-3">
              {[[t(uiLang, "profilePosts"), stats.posts], [t(uiLang, "subscribers"), stats.subscribers], [t(uiLang, "totalLikes"), stats.likes]].map(([label, value]) => <div key={String(label)} className="rounded-2xl border border-white/10 bg-white/5 p-3 text-center sm:p-4"><div className="text-xl font-bold text-white">{value}</div><div className="mt-1 text-xs text-slate-400">{label}</div></div>)}
            </div>
            {statsNote && <p className="-mt-3 mb-5 text-xs text-amber-200/80">{statsNote}</p>}
            <h3 className="mb-3 text-base font-semibold text-white">{t(uiLang, "profilePosts")}</h3>
            {posts.length === 0 ? <p className="rounded-2xl border border-white/10 bg-white/5 p-6 text-center text-sm text-slate-400">{t(uiLang, "noProfilePosts")}</p> : <div className="space-y-3">{posts.map((post) => <article key={post.id} className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-200">{post.body}</p>{post.photo_url && <img src={post.photo_url} alt="" onError={(event) => { event.currentTarget.style.display = "none"; }} loading="lazy" className="mt-3 aspect-square w-full max-w-sm rounded-xl object-cover" />}<div className="mt-3 flex items-center gap-1.5 text-xs text-slate-400"><Heart className="h-3.5 w-3.5" />{post.like_count}<span className="ml-2">{new Date(post.created_at).toLocaleDateString()}</span></div></article>)}</div>}
            {posts.length < stats.posts && <p className="mt-3 text-center text-xs text-slate-500">{t(uiLang, "profileRecentPosts")}</p>}
          </div>
        )}
      </section>
    </div>
  );
}
