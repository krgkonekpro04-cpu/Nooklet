import type { DailyForecast } from "@/types";
import { t, getWeatherLabelByLang, DAY_NAMES_BY_LANG } from "@/lib/i18n";
import type { LanguageCode } from "@/lib/i18n";
import { formatTempShort, formatWind, type TempUnit } from "@/lib/temperature";
import { Droplets, Wind } from "lucide-react";

interface ForecastProps {
  daily: DailyForecast;
  uiLang: LanguageCode;
  unit: TempUnit;
}

function getWeatherEmoji(code: number): string {
  if (code === 0 || code === 1) return "☀️";
  if (code === 2) return "⛅";
  if (code === 3) return "☁️";
  if (code === 45 || code === 48) return "🌫️";
  if (code >= 51 && code <= 57) return "🌦️";
  if (code >= 61 && code <= 67) return "🌧️";
  if (code >= 71 && code <= 77) return "🌨️";
  if (code >= 80 && code <= 82) return "🌧️";
  if (code >= 85 && code <= 86) return "🌨️";
  if (code >= 95) return "⛈️";
  return "🌤️";
}

export function Forecast({ daily, uiLang, unit }: ForecastProps) {
  const dayNames = DAY_NAMES_BY_LANG[uiLang] ?? DAY_NAMES_BY_LANG.en;
  const days = daily.time.slice(0, 5).map((dateStr, i) => {
    const date = new Date(dateStr + "T00:00");
    const isToday = i === 0;
    const dayName = isToday ? t(uiLang, "today") : dayNames[date.getDay()];
    return {
      dayName,
      emoji: getWeatherEmoji(daily.weather_code[i]),
      label: getWeatherLabelByLang(daily.weather_code[i], uiLang),
      max: formatTempShort(daily.temperature_2m_max[i], unit),
      min: formatTempShort(daily.temperature_2m_min[i], unit),
      maxRaw: daily.temperature_2m_max[i],
      minRaw: daily.temperature_2m_min[i],
      precip: daily.precipitation_probability_max[i] ?? 0,
      wind: Math.round(daily.wind_speed_10m_max[i] ?? 0),
    };
  });

  const globalMin = Math.min(...days.map((d) => d.minRaw));
  const globalMax = Math.max(...days.map((d) => d.maxRaw));
  const range = Math.max(globalMax - globalMin, 1);

  return (
    <div className="w-full">
      <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <span className="inline-block w-1 h-5 rounded-full bg-cyan-400" />
        {t(uiLang, "fiveDayForecast")}
      </h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {days.map((day, i) => (
          <div
            key={i}
            className={`rounded-2xl p-4 border transition-all hover:scale-[1.02] ${
              i === 0
                ? "bg-cyan-500/15 border-cyan-400/40"
                : "bg-white/5 border-white/10 hover:bg-white/10"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-white">{day.dayName}</span>
              <span className="text-2xl">{day.emoji}</span>
            </div>
            <div className="text-xs text-slate-400 mb-3">{day.label}</div>
            <div className="flex items-end gap-2 mb-3">
              <span className="text-2xl font-bold text-white">{day.max}</span>
              <span className="text-lg text-slate-400">{day.min}</span>
            </div>
            <div className="relative h-1.5 rounded-full bg-white/10 mb-3 overflow-hidden">
              <div
                className="absolute h-full rounded-full bg-gradient-to-r from-cyan-400 to-orange-400"
                style={{
                  left: `${((day.minRaw - globalMin) / range) * 100}%`,
                  width: `${((day.maxRaw - day.minRaw) / range) * 100}%`,
                }}
              />
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400">
              {day.precip > 0 && (
                <span className="flex items-center gap-1">
                  <Droplets className="w-3 h-3" /> {day.precip}%
                </span>
              )}
              {day.wind > 0 && (
                <span className="flex items-center gap-1">
                  <Wind className="w-3 h-3" /> {formatWind(day.wind, unit)}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
