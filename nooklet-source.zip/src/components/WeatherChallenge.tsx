import { useMemo } from "react";
import { CalendarCheck } from "lucide-react";
import type { CurrentWeather } from "@/types";
import { getCondition } from "@/lib/memes";

interface WeatherChallengeProps {
  current: CurrentWeather;
}

interface Challenge {
  emoji: string;
  title: string;
  description: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Extreme";
}

function getChallenges(current: CurrentWeather): Challenge[] {
  const temp = current.apparent_temperature;
  const condition = getCondition(current.weather_code);
  const humidity = current.relative_humidity_2m;
  const wind = current.wind_speed_10m;
  const uv = current.uv_index;
  const challenges: Challenge[] = [];

  if (temp <= -10) {
    challenges.push({ emoji: "", title: "The Frozen Bubble", description: "Blow a soap bubble outside and watch it freeze mid-air. Take a photo before it shatters.", difficulty: "Medium" });
    challenges.push({ emoji: "", title: "Banana Hammer", description: "Leave a banana outside for 30 minutes, then try to use it as a hammer. Yes, this actually works.", difficulty: "Easy" });
  } else if (temp <= 0) {
    challenges.push({ emoji: "", title: "Ice Sculpture", description: "Freeze water in a creative shape overnight. Display it proudly. It's art.", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Hot Drink Challenge", description: "Make a hot drink, take it outside, and see how long it stays hot. Time it.", difficulty: "Easy" });
  } else if (temp <= 10) {
    challenges.push({ emoji: "", title: "Layer Master", description: "Wear exactly 3 layers. Not 2, not 4. Document your perfect layering system.", difficulty: "Easy" });
  } else if (temp >= 18 && temp < 25) {
    challenges.push({ emoji: "", title: "Perfect Picnic", description: "Go have a picnic. The weather is literally perfect. No excuses.", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Golden Hour Photo", description: "Take a photo during golden hour. The lighting will be incredible.", difficulty: "Easy" });
  } else if (temp >= 25 && temp < 32) {
    challenges.push({ emoji: "", title: "Ice Cream Race", description: "Buy ice cream, take it outside, and eat it before it melts. Go.", difficulty: "Medium" });
  } else if (temp >= 32) {
    challenges.push({ emoji: "", title: "Car Oven Experiment", description: "The sidewalk is hot enough. Try cooking something on it. Crack an egg on dark pavement.", difficulty: "Medium" });
    challenges.push({ emoji: "", title: "Cold Shower Dare", description: "Take a cold shower and see how long you can stay in. A minute is respectable.", difficulty: "Hard" });
  }

  if (condition === "rain" || condition === "drizzle") {
    challenges.push({ emoji: "", title: "Rain Dancer", description: "Go outside and do a 10-second rain dance. Film it. Don't show anyone.", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Puddle Photographer", description: "Find the most photogenic puddle and take a reflection photo. Art is everywhere.", difficulty: "Easy" });
  }
  if (condition === "snow") {
    challenges.push({ emoji: "", title: "Snow Angel", description: "Make a snow angel. The bigger, the better. Bonus points for multiple angels.", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Snowflake Catcher", description: "Catch 5 unique snowflakes on a dark surface. Examine them. They're all different.", difficulty: "Medium" });
  }
  if (condition === "thunderstorm") {
    challenges.push({ emoji: "", title: "Storm Counter", description: "Count the seconds between lightning and thunder to calculate storm distance. Science!", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Cozy Mode", description: "Make a blanket fort, grab hot chocolate, and watch the storm from a window. Peak cozy.", difficulty: "Easy" });
  }
  if (condition === "fog") {
    challenges.push({ emoji: "", title: "Fog Silhouette", description: "Take a photo of a tree or building silhouette in the fog. Mysterious vibes only.", difficulty: "Easy" });
  }
  if (wind > 30) {
    challenges.push({ emoji: "", title: "Wind Walker", description: "Try walking against the wind like a dramatic movie character. Maintain eye contact with destiny.", difficulty: "Medium" });
    challenges.push({ emoji: "", title: "Kite Master", description: "Fly a kite. If you don't have one, make one from a plastic bag and string. Innovation!", difficulty: "Hard" });
  }
  if (uv > 7) {
    challenges.push({ emoji: "", title: "Shadow Tracker", description: "Measure your shadow at noon. It should be very short. That's science, not just a tan.", difficulty: "Easy" });
  }
  if (humidity > 80) {
    challenges.push({ emoji: "", title: "Hair Status Check", description: "Take a selfie. Check your hair. Accept your new reality. You're fabulous anyway.", difficulty: "Easy" });
  }

  if (challenges.length === 0) {
    challenges.push({ emoji: "", title: "Sky Watcher", description: "Look up at the sky for 2 full minutes. Just look. Notice something you've never noticed before.", difficulty: "Easy" });
    challenges.push({ emoji: "", title: "Weather Gratitude", description: "Write down 3 things you appreciate about today's weather. Even if it's boring, find the beauty.", difficulty: "Easy" });
  }

  return challenges;
}

const difficultyColors: Record<string, string> = {
  Easy: "text-green-400 bg-green-500/10 border-green-400/20",
  Medium: "text-yellow-400 bg-yellow-500/10 border-yellow-400/20",
  Hard: "text-orange-400 bg-orange-500/10 border-orange-400/20",
  Extreme: "text-red-400 bg-red-500/10 border-red-400/20",
};

export function WeatherChallenge({ current }: WeatherChallengeProps) {
  const challenges = useMemo(() => getChallenges(current), [current]);
  const challenge = useMemo(
    () => challenges[Math.floor(Math.random() * challenges.length)],
    [challenges],
  );

  return (
    <div className="rounded-3xl bg-gradient-to-br from-green-500/10 to-emerald-500/10 backdrop-blur-md border border-green-400/20 p-5 sm:p-6">
      <div className="flex items-center gap-2 mb-4">
        <CalendarCheck className="w-5 h-5 text-green-400" />
        <h3 className="text-lg font-bold text-white">Weather Challenge</h3>
      </div>
      <div className="flex items-start gap-3 mb-3">
        <span className="text-3xl flex-shrink-0">{challenge.emoji}</span>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-white font-bold text-sm">{challenge.title}</span>
            <span className={`text-xs px-2 py-0.5 rounded-full border ${difficultyColors[challenge.difficulty]}`}>
              {challenge.difficulty}
            </span>
          </div>
          <p className="text-slate-300 text-sm leading-relaxed">{challenge.description}</p>
        </div>
      </div>
      <div className="text-xs text-slate-500 mt-3">
        {challenges.length} {challenges.length === 1 ? "challenge" : "challenges"} available for this weather
      </div>
    </div>
  );
}
