import { useState, useCallback } from "react";
import { Share2, Check } from "lucide-react";
import type { CurrentWeather } from "@/types";
import { getWeatherLabelByLang, type LanguageCode } from "@/lib/i18n";
import { formatTemp, type TempUnit } from "@/lib/temperature";
import { playSound } from "@/lib/sounds";

interface ShareWeatherProps {
  current: CurrentWeather;
  location: string;
  region?: string;
  uiLang: LanguageCode;
  unit: TempUnit;
}

export function ShareWeather({ current, location, region, uiLang, unit }: ShareWeatherProps) {
  const [shared, setShared] = useState(false);

  const handleShare = useCallback(async () => {
    playSound("tada");
    const label = getWeatherLabelByLang(current.weather_code, uiLang);
    const tempStr = formatTemp(current.apparent_temperature, unit);
    const regionStr = region ? `, ${region}` : "";
    const text = `It's ${tempStr} and ${label.toLowerCase()} in ${location}${regionStr}. What's it like where you are?`;

    if (navigator.share) {
      try {
        const shareUrl = window.location.protocol === "http:" || window.location.protocol === "https:"
          ? { url: window.location.href }
          : {};
        await navigator.share({
          title: `MemeWeather — ${location}`,
          text,
          ...shareUrl,
        });
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch {
        // user cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        setShared(true);
        setTimeout(() => setShared(false), 2000);
      } catch {
        // clipboard failed
      }
    }
  }, [current, location, region, uiLang, unit]);

  return (
    <button
      onClick={handleShare}
      className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-medium text-sm transition-all active:scale-95 ${
        shared
          ? "bg-green-500/20 border border-green-400/40 text-green-300"
          : "bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 hover:bg-cyan-500/25"
      }`}
    >
      {shared ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
      {shared ? "Copied!" : "Share Weather"}
    </button>
  );
}
