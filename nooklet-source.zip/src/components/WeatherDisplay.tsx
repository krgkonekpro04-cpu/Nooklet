import { Wind, Droplets, Gauge, Cloud, Sun, Thermometer } from "lucide-react";
import type { CurrentWeather } from "@/types";
import { t, getWeatherLabelByLang } from "@/lib/i18n";
import type { LanguageCode } from "@/lib/i18n";
import { formatTemp, formatWind, type TempUnit } from "@/lib/temperature";

interface WeatherDisplayProps {
  current: CurrentWeather;
  location: string;
  region?: string;
  timezone: string;
  uiLang: LanguageCode;
  unit: TempUnit;
}

export function WeatherDisplay({ current, location, region, timezone, uiLang, unit }: WeatherDisplayProps) {
  const stats = [
    { icon: Thermometer, label: t(uiLang, "feelsLike"), value: formatTemp(current.apparent_temperature, unit) },
    { icon: Droplets, label: t(uiLang, "humidity"), value: `${current.relative_humidity_2m}%` },
    { icon: Wind, label: t(uiLang, "wind"), value: formatWind(current.wind_speed_10m, unit) },
    { icon: Gauge, label: t(uiLang, "pressure"), value: `${Math.round(current.pressure_msl)} hPa` },
    { icon: Cloud, label: t(uiLang, "cloudCover"), value: `${current.cloud_cover}%` },
    { icon: Sun, label: t(uiLang, "uvIndex"), value: `${Math.round(current.uv_index)}` },
  ];

  return (
    <div className="w-full">
      <div className="flex flex-col items-center text-center mb-6">
        <div className="flex items-center gap-2 text-slate-300 text-sm mb-1">
          <span className="inline-block w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.35)]" />
          {t(uiLang, "liveWeather")}
        </div>
        <h2 className="text-3xl sm:text-4xl font-bold text-white">
          {location}
          {region && <span className="text-slate-400 text-lg font-normal ml-2">{region}</span>}
        </h2>
        <p className="text-slate-400 text-xs mt-1">{timezone}</p>
      </div>

      <div className="flex flex-col items-center mb-8">
        <div
          className={`text-7xl sm:text-8xl font-extralight text-white tracking-tight ${
            current.apparent_temperature >= 32
              ? "text-orange-300"
              : current.apparent_temperature <= 0
              ? "text-cyan-200"
              : ""
          }`}
        >
          {formatTemp(current.temperature_2m, unit).replace(/°[CF]$/, "°")}
        </div>
        <div className="text-xl text-cyan-300 font-medium mt-1">
          {getWeatherLabelByLang(current.weather_code, uiLang)}
        </div>
        {current.precipitation > 0 && (
          <div className="text-sm text-slate-400 mt-1">
            {current.precipitation} mm
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="flex items-center gap-3 px-4 py-3 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10 transition-all hover:bg-white/10"
          >
            <stat.icon className="w-5 h-5 text-cyan-400 flex-shrink-0" />
            <div className="min-w-0">
              <div className="text-xs text-slate-400 truncate">{stat.label}</div>
              <div className="text-sm font-semibold text-white">{stat.value}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
