import type { CurrentWeather, DailyForecast, HourlyForecast } from "@/types";
import { formatTemp, formatWind, type TempUnit } from "@/lib/temperature";
import { Activity, ArrowDown, ArrowUp, Compass, Droplets, Eye, Gauge, Sun, Wind } from "lucide-react";

interface AdvancedWeatherProps {
  current: CurrentWeather;
  daily: DailyForecast;
  hourly: HourlyForecast;
  unit: TempUnit;
}

function dewPointC(tempC: number, humidity: number): number {
  const safeHumidity = Math.max(1, Math.min(humidity, 100));
  const gamma = Math.log(safeHumidity / 100) + (17.625 * tempC) / (243.04 + tempC);
  return (243.04 * gamma) / (17.625 - gamma);
}

function compassDirection(degrees: number): string {
  return ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"][Math.round(degrees / 22.5) % 16];
}

function localTime(value?: string): string {
  if (!value) return "—";
  const time = value.split("T")[1];
  return time ? time.slice(0, 5) : "—";
}

export function AdvancedWeather({ current, daily, hourly, unit }: AdvancedWeatherProps) {
  const uvRisk = current.uv_index <= 2 ? "Low" : current.uv_index <= 5 ? "Moderate" : current.uv_index <= 7 ? "High" : current.uv_index <= 10 ? "Very high" : "Extreme";
  const nextHourRain = hourly.precipitation_probability[0] ?? 0;
  const items = [
    { icon: Activity, label: "Dew point · estimated", value: formatTemp(dewPointC(current.temperature_2m, current.relative_humidity_2m), unit) },
    { icon: Wind, label: "Wind direction", value: `${compassDirection(current.wind_direction_10m)} · ${Math.round(current.wind_direction_10m)}°` },
    { icon: Gauge, label: "Sea-level pressure", value: `${Math.round(current.pressure_msl)} hPa` },
    { icon: Droplets, label: "Relative humidity", value: `${current.relative_humidity_2m}%` },
    { icon: Eye, label: "Cloud cover", value: `${current.cloud_cover}%` },
    { icon: Sun, label: "UV risk", value: `${uvRisk} · ${Math.round(current.uv_index)}` },
    { icon: Droplets, label: "Precipitation now", value: `${current.precipitation.toFixed(1)} mm` },
    { icon: Droplets, label: "Next-hour rain chance", value: `${nextHourRain}%` },
  ];

  return (
    <section className="rounded-3xl bg-slate-950/55 border border-cyan-400/20 p-5 sm:p-6" aria-label="Advanced weather details">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-cyan-300" />
        <h3 className="text-lg font-bold text-white">Advanced weather</h3>
        <span className="ml-auto text-xs text-slate-500">More detail for weather nerds</span>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {items.map(({ icon: Icon, label, value }) => (
          <div key={label} className="rounded-2xl bg-white/5 border border-white/10 p-3">
            <div className="flex items-center gap-2 text-slate-400 text-xs mb-2"><Icon className="w-4 h-4 text-cyan-300" />{label}</div>
            <div className="font-semibold text-white text-sm">{value}</div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3">
        <div className="rounded-2xl bg-white/5 border border-white/10 p-3">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-2"><ArrowUp className="w-4 h-4 text-orange-300" />Today’s high</div>
          <div className="font-semibold text-white text-sm">{formatTemp(daily.temperature_2m_max[0], unit)}</div>
        </div>
        <div className="rounded-2xl bg-white/5 border border-white/10 p-3">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-2"><ArrowDown className="w-4 h-4 text-cyan-300" />Today’s low</div>
          <div className="font-semibold text-white text-sm">{formatTemp(daily.temperature_2m_min[0], unit)}</div>
        </div>
        <div className="rounded-2xl bg-white/5 border border-white/10 p-3">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-2"><Sun className="w-4 h-4 text-amber-300" />Sunrise / sunset</div>
          <div className="font-semibold text-white text-sm">{localTime(daily.sunrise[0])} / {localTime(daily.sunset[0])}</div>
        </div>
        <div className="rounded-2xl bg-white/5 border border-white/10 p-3">
          <div className="flex items-center gap-2 text-slate-400 text-xs mb-2"><Compass className="w-4 h-4 text-cyan-300" />Peak wind today</div>
          <div className="font-semibold text-white text-sm">{formatWind(daily.wind_speed_10m_max[0] ?? 0, unit)}</div>
        </div>
      </div>
      <p className="text-xs text-slate-500 mt-3">Dew point is estimated from temperature and humidity. Sunrise and sunset use the selected city’s local time.</p>
    </section>
  );
}
