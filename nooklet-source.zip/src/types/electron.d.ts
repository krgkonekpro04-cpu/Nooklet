export {};

declare global {
  interface Window {
    nookletDesktop?: {
      translateInterfaceText: (text: string, language: string) => Promise<string | null>;
      checkForUpdates: () => Promise<{ status: "available" | "up-to-date" | "error" | "unsupported"; currentVersion: string; version?: string; message?: string }>;
      installUpdate: () => Promise<{ status: "installed" | "error"; message?: string }>;
    };
  }
}
