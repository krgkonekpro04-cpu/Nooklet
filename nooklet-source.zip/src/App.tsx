import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { Download, LogIn, LogOut, MessageCircle, Palette, RefreshCw, Sparkles } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { AuthScreen } from "@/components/AuthScreen";
import { LocalForumHub } from "@/components/LocalForumHub";
import { Logo } from "@/components/Logo";
import { APP_CHANNEL, APP_VERSION } from "@/lib/app-meta";
import { NookletLocalization, NOOKLET_LANGUAGES, type NookletLanguage } from "@/components/NookletLocalization";

type NookletTheme = "paper" | "ocean" | "lilac" | "sunset" | "midnight";
const THEMES: { id: NookletTheme; label: string }[] = [
  { id: "paper", label: "Paper" }, { id: "ocean", label: "Ocean" },
  { id: "lilac", label: "Lilac" }, { id: "sunset", label: "Sunset" },
  { id: "midnight", label: "Midnight" },
];

interface UserProfile {
  username: string;
  avatarEmoji: string;
  avatarUrl: string | null;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [guestId, setGuestId] = useState<string | null>(() => localStorage.getItem("nooklet-guest-account-id"));
  const [theme, setTheme] = useState<NookletTheme>(() => {
    const saved = localStorage.getItem("nooklet-theme");
    return THEMES.some((option) => option.id === saved) ? saved as NookletTheme : "paper";
  });
  const [language, setLanguage] = useState<NookletLanguage>(() => {
    const saved = localStorage.getItem("nooklet-language");
    return NOOKLET_LANGUAGES.some(([id]) => id === saved) ? saved as NookletLanguage : "en";
  });
  const [updateState, setUpdateState] = useState<{ status: "checking" | "available" | "up-to-date" | "error" | "unsupported"; version?: string }>(() => ({ status: "checking" }));

  const checkForUpdates = async () => {
    if (!window.nookletDesktop) { setUpdateState({ status: "unsupported" }); return; }
    setUpdateState({ status: "checking" });
    try {
      const result = await window.nookletDesktop.checkForUpdates();
      setUpdateState({ status: result.status, version: result.version });
    } catch {
      setUpdateState({ status: "error" });
    }
  };

  const installUpdate = async () => {
    if (!window.nookletDesktop) return;
    try {
      const result = await window.nookletDesktop.installUpdate();
      if (result.status === "error") setUpdateState({ status: "error" });
    } catch {
      setUpdateState({ status: "error" });
    }
  };

  useEffect(() => { void checkForUpdates(); }, []);

  useEffect(() => {
    document.documentElement.dataset.nookletTheme = theme;
    localStorage.setItem("nooklet-theme", theme);
  }, [theme]);

  useEffect(() => { localStorage.setItem("nooklet-language", language); }, [language]);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data }) => {
      if (active) {
        setUser(data.session?.user ?? null);
        setAuthReady(true);
      }
    }).catch(() => { if (active) setAuthReady(true); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      setAuthReady(true);
    });
    return () => { active = false; listener.subscription.unsubscribe(); };
  }, []);

  useEffect(() => {
    if (!user) { setProfile(null); return; }
    const metadata = user.user_metadata ?? {};
    const fallback = {
      username: typeof metadata.username === "string" ? metadata.username : user.email?.split("@")[0] ?? "New member",
      avatarEmoji: typeof metadata.avatar_emoji === "string" ? metadata.avatar_emoji : "🪴",
      avatarUrl: typeof metadata.avatar_url === "string" ? metadata.avatar_url : null,
    };
    setProfile(fallback);
  }, [user]);

  return (
    <div className="nooklet-root min-h-screen bg-[#f7f6f2] text-[#20251f] selection:bg-emerald-200">
      <NookletLocalization language={language} />
      <header className="sticky top-0 z-30 border-b border-[#e7e6df] bg-[#f7f6f2]/90 backdrop-blur-xl">
        <div className="mx-auto flex h-[76px] max-w-7xl items-center justify-between px-5 sm:px-8">
          <a href="#home" className="flex items-center gap-3" aria-label="Nooklet home">
            <Logo size={42} />
            <div className="leading-tight">
              <span className="text-[21px] font-extrabold tracking-[-0.06em] text-[#1d2820]">nooklet</span>
              <span className="ml-2 hidden text-xs font-medium text-[#7c827b] sm:inline">small forums, good company</span>
            </div>
          </a>
          <div className="flex items-center gap-3">
            <span className="hidden rounded-full bg-[#eeeee8] px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-[#74796f] sm:inline-flex">{APP_CHANNEL} · {APP_VERSION}</span>
            <label className="inline-flex items-center gap-1.5 rounded-full border border-[#dedfd7] bg-white px-3 py-2 text-sm font-semibold text-[#4f584f]" title="Translate the interface">
              <span aria-hidden="true">文</span><span className="sr-only">Language</span>
              <select aria-label="Language" data-no-translate value={language} onChange={(event) => setLanguage(event.target.value as NookletLanguage)} className="max-w-[7.5rem] bg-transparent outline-none">
                {NOOKLET_LANGUAGES.map(([id, label]) => <option key={id} value={id}>{label}</option>)}
              </select>
            </label>
            <label className="inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-3 py-2 text-sm font-semibold text-[#4f584f]" title="Choose a color theme">
              <Palette className="h-4 w-4" />
              <span className="sr-only">Color theme</span>
              <select aria-label="Color theme" value={theme} onChange={(event) => setTheme(event.target.value as NookletTheme)} className="max-w-[6.5rem] bg-transparent outline-none">
                {THEMES.map((option) => <option key={option.id} value={option.id}>{option.label}</option>)}
              </select>
            </label>
            {window.nookletDesktop && <div className="flex items-center gap-1">
              {updateState.status === "available" ? <button type="button" onClick={() => void installUpdate()} className="inline-flex items-center gap-1.5 rounded-full bg-[#284f37] px-3 py-2 text-xs font-bold text-white transition hover:bg-[#1f422d]"><Download className="h-3.5 w-3.5"/>Install update {updateState.version}</button> : <button type="button" onClick={() => void checkForUpdates()} disabled={updateState.status === "checking"} title={updateState.status === "up-to-date" ? "You have the latest version" : "Check for updates"} aria-label="Check for updates" className="inline-flex items-center gap-1.5 rounded-full border border-[#dedfd7] bg-white px-3 py-2 text-xs font-semibold text-[#4f584f] transition hover:border-[#c2d7c6] disabled:opacity-60"><RefreshCw className={`h-3.5 w-3.5 ${updateState.status === "checking" ? "animate-spin" : ""}`}/><span className="hidden md:inline">{updateState.status === "checking" ? "Checking…" : updateState.status === "up-to-date" ? "Up to date" : "Check updates"}</span></button>}
            </div>}
            {user ? (
              <div className="flex items-center gap-2">
                <button type="button" onClick={() => void supabase.auth.signOut()} className="inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-4 py-2 text-sm font-semibold text-[#4f584f] transition hover:border-[#c2d7c6] hover:text-[#2d6740]"><LogOut className="h-4 w-4"/><span className="hidden sm:inline">Sign out</span></button>
              </div>
            ) : guestId ? (
              <div className="flex items-center gap-2"><button type="button" onClick={() => setAuthOpen(true)} className="inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-4 py-2.5 text-sm font-semibold text-[#4f584f]"><LogIn className="h-4 w-4"/>Sign in</button><button type="button" onClick={() => { localStorage.removeItem("nooklet-guest-account-id"); setGuestId(null); }} className="inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-4 py-2.5 text-sm font-semibold text-[#4f584f]">Exit guest</button></div>
            ) : (
              <div className="flex items-center gap-2"><button type="button" onClick={() => setAuthOpen(true)} className="inline-flex items-center gap-2 rounded-full border border-[#dedfd7] bg-white px-4 py-2.5 text-sm font-semibold text-[#4f584f]"><LogIn className="h-4 w-4"/>Sign in</button><button type="button" onClick={() => { const id = `guest-${crypto.randomUUID()}`; localStorage.setItem("nooklet-guest-account-id", id); localStorage.setItem("nooklet-guest-name", `Guest ${id.slice(-4)}`); setGuestId(id); }} className="inline-flex items-center gap-2 rounded-full bg-[#284f37] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1f422d]">Continue as guest</button></div>
            )}
          </div>
        </div>
      </header>

      <main id="home" className="mx-auto max-w-7xl px-5 pb-20 pt-9 sm:px-8 sm:pt-14">
        {!user && !guestId ? (
          <>
            <section className="mx-auto mb-14 max-w-3xl text-center">
              <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-[#dce7dc] bg-white/80 px-4 py-2 text-xs font-bold uppercase tracking-[0.15em] text-[#4a7154]"><Sparkles className="h-4 w-4"/>A little corner of the internet</div>
              <h1 className="text-4xl font-black leading-[1.04] tracking-[-0.06em] text-[#202a22] sm:text-6xl">Your people.<br/><span className="text-[#4d805b]">Your little corner.</span></h1>
              <p className="mx-auto mt-5 max-w-xl text-base leading-7 text-[#6f786e] sm:text-lg">The best place for small forums. Make a space for your niche, your neighbors, your favorite thing—and let the good conversations grow.</p>
              <button type="button" onClick={() => setAuthOpen(true)} className="mt-7 inline-flex items-center gap-2 rounded-full bg-[#284f37] px-6 py-3.5 font-bold text-white shadow-lg shadow-[#284f37]/15 transition hover:-translate-y-0.5 hover:bg-[#1f422d]"><MessageCircle className="h-4 w-4"/>Join the conversation</button>
            </section>
            <section className="mx-auto max-w-5xl">
              <div className="mb-5 flex items-end justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-[0.18em] text-[#81897e]">A preview of the good stuff</p><h2 className="mt-1 text-2xl font-extrabold tracking-tight">Small spaces, big interests</h2></div><span className="hidden text-sm text-[#82877d] sm:block">Find your corner below</span></div>
              <div className="grid gap-4 sm:grid-cols-3">
                {[["🪴","Plant people","Trade cuttings, celebrate new leaves, ask why that one plant is being dramatic.","#e4efe2"],["📚","The reading nook","Book recs, buddy reads, and spoiler-friendly chats for people who always pack one more book.","#eee8df"],["🛠️","Weekend makers","Tiny projects, big plans, half-finished shelves—we’ve all been there.","#e8e9dd"]].map(([emoji,title,desc,color])=><article key={title} className="rounded-[26px] border border-[#e8e7df] bg-white p-5 shadow-[0_6px_24px_rgba(42,55,43,.035)]"><div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl text-2xl" style={{backgroundColor:color}}>{emoji}</div><h3 className="text-lg font-bold tracking-tight">{title}</h3><p className="mt-2 text-sm leading-6 text-[#778076]">{desc}</p><div className="mt-5 flex items-center gap-2 text-xs font-semibold text-[#748071]"><span className="h-2 w-2 rounded-full bg-[#71a77c]"/>A place to start</div></article>)}
              </div>
            </section>
          </>
        ) : user && profile ? (
          <LocalForumHub key={user.id} accountId={user.id} email={user.email ?? null} canMakeMajor={user.email?.toLowerCase() === "shjsnsnh186@gmail.com" || user.app_metadata?.role === "moderator" || user.app_metadata?.verified === true} username={profile.username} avatarEmoji={profile.avatarEmoji} avatarUrl={profile.avatarUrl} onAvatarUrlChange={(avatarUrl) => setProfile((current) => current ? { ...current, avatarUrl } : current)} />
        ) : guestId ? (
          <LocalForumHub key={guestId} accountId={guestId} email={null} canMakeMajor={false} username={localStorage.getItem("nooklet-guest-name") ?? "Guest member"} avatarEmoji="🪴" avatarUrl={null} onAvatarUrlChange={() => undefined} />
        ) : (
          <div className="py-24 text-center text-[#7c827b]">Getting your nook ready…</div>
        )}
      </main>

      <footer className="border-t border-[#e7e6df] px-5 py-7 text-center text-xs text-[#81877d]">nooklet · best place for small forums</footer>

      {authOpen && <div className="fixed inset-0 z-50 overflow-y-auto bg-[#20251f]/55 p-4 backdrop-blur-sm"><div className="mx-auto my-5 max-w-lg overflow-hidden rounded-[30px] bg-[#f7f6f2] shadow-2xl"><AuthScreen onAuthed={() => setAuthOpen(false)} onCancel={() => setAuthOpen(false)} /></div></div>}
      {!authReady && <div className="fixed bottom-4 right-4 rounded-full bg-white px-3 py-2 text-xs text-[#778076] shadow-lg">Connecting…</div>}
    </div>
  );
}
