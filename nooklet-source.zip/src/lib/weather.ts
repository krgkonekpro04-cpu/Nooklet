import type { WeatherResponse, GeoResult } from "@/types";

const functionUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/weather`;
const headers = {
  Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
  "Content-Type": "application/json",
};
const requestTimeoutMs = 12_000;

async function fetchJson(url: string, init: RequestInit = {}): Promise<Response> {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), requestTimeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
}

async function directCitySearch(city: string, lang: string): Promise<GeoResult> {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.search = new URLSearchParams({ name: city, count: "1", language: lang, format: "json" }).toString();
  const response = await fetchJson(url.toString());
  if (!response.ok) throw new Error(`City search failed (${response.status})`);
  const data = await response.json() as { results?: Array<{ latitude: number; longitude: number; name: string; country?: string; admin1?: string }> };
  const place = data.results?.[0];
  if (!place) throw new Error("City not found");
  return { lat: place.latitude, lon: place.longitude, name: place.name, country: place.country ?? "", admin1: place.admin1 };
}

function directWeatherUrl(lat: number, lon: number): string {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.search = new URLSearchParams({
    latitude: String(lat),
    longitude: String(lon),
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,uv_index",
    hourly: "temperature_2m,weather_code,precipitation_probability",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,uv_index_max,sunrise,sunset",
    timezone: "auto",
    forecast_days: "5",
  }).toString();
  return url.toString();
}

export async function searchCity(city: string, lang: string = "en"): Promise<GeoResult> {
  const url = `${functionUrl}?city=${encodeURIComponent(city)}&lang=${encodeURIComponent(lang)}`;
  try {
    const response = await fetchJson(url, { headers });
    if (response.ok) {
      const data = await response.json() as GeoResult;
      if (typeof data.lat === "number" && typeof data.lon === "number") return data;
      throw new Error("City not found");
    }
    if (response.status < 500) {
      const data = await response.json().catch(() => ({ error: "City search failed" }));
      throw new Error(data.error || `City search failed (${response.status})`);
    }
  } catch (error) {
    if (error instanceof Error && error.message === "City not found") throw error;
    // The Supabase function can time out while its weather provider is unavailable.
    // Retry geocoding directly against Open-Meteo so city search still works.
  }
  return directCitySearch(city, lang);
}

export async function getWeather(lat: number, lon: number): Promise<WeatherResponse> {
  const url = `${functionUrl}?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}`;
  try {
    const response = await fetchJson(url, { headers });
    if (response.ok) {
      const data = await response.json() as WeatherResponse;
      if (data.current && data.daily) return data;
      throw new Error("Invalid weather data received");
    }
    if (response.status < 500) {
      const data = await response.json().catch(() => ({ error: "Weather fetch failed" }));
      throw new Error(data.error || `Weather fetch failed (${response.status})`);
    }
  } catch (error) {
    if (error instanceof Error && error.message === "Invalid weather data received") throw error;
    // Retry against the public provider when the Edge Function times out or fails.
  }

  const directResponse = await fetchJson(directWeatherUrl(lat, lon));
  if (!directResponse.ok) throw new Error(`Weather service unavailable (${directResponse.status})`);
  const data = await directResponse.json() as WeatherResponse;
  if (!data.current || !data.daily) throw new Error("Invalid weather data received");
  return data;
}
