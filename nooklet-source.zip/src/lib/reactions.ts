import { supabase } from "./supabase";
import type { MemeReaction } from "@/types";

export async function getReactions(memeId: string): Promise<MemeReaction[]> {
  const { data, error } = await supabase
    .from("meme_reactions")
    .select("reaction")
    .eq("meme_id", memeId);

  if (error) {
    console.error("Failed to fetch reactions:", error);
    return [];
  }

  const counts: Record<string, number> = {};
  for (const row of data ?? []) {
    counts[row.reaction] = (counts[row.reaction] ?? 0) + 1;
  }

  return Object.entries(counts)
    .map(([emoji, count]) => ({ emoji, count }))
    .sort((a, b) => b.count - a.count);
}

export async function addReaction(memeId: string, emoji: string): Promise<void> {
  const { error } = await supabase
    .from("meme_reactions")
    .insert({ meme_id: memeId, reaction: emoji });

  if (error) {
    console.error("Failed to add reaction:", error);
    throw error;
  }
}

export async function removeReaction(memeId: string, emoji: string): Promise<void> {
  const { error } = await supabase
    .from("meme_reactions")
    .delete()
    .eq("meme_id", memeId)
    .eq("reaction", emoji)
    .limit(1);

  if (error) {
    console.error("Failed to remove reaction:", error);
    throw error;
  }
}
