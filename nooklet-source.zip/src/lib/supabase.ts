import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    // Keep the signed-in session in the app's persistent origin storage on both
    // desktop platforms. Electron does not clear this storage between launches.
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
});
