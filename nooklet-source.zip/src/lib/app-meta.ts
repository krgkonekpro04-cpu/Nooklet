export const APP_VERSION = "0.2.0-alpha.10";
export const APP_CHANNEL = "Alpha";
export const DEVELOPER_USERNAME = "Nooklet";
export const DEVELOPER_EMAIL = "shjsnsnh186@gmail.com";
