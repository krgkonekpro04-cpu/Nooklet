import type { WeatherMeme } from "@/types";
import type { LanguageCode } from "@/lib/i18n";
import type { TempUnit } from "@/lib/temperature";

// WMO weather codes mapped to descriptions and conditions
export const WEATHER_CODES: Record<number, { label: string; condition: string }> = {
  0: { label: "Clear sky", condition: "clear" },
  1: { label: "Mainly clear", condition: "clear" },
  2: { label: "Partly cloudy", condition: "partly-cloudy" },
  3: { label: "Overcast", condition: "cloudy" },
  45: { label: "Foggy", condition: "fog" },
  48: { label: "Depositing rime fog", condition: "fog" },
  51: { label: "Light drizzle", condition: "drizzle" },
  53: { label: "Moderate drizzle", condition: "drizzle" },
  55: { label: "Dense drizzle", condition: "drizzle" },
  56: { label: "Light freezing drizzle", condition: "drizzle" },
  57: { label: "Dense freezing drizzle", condition: "drizzle" },
  61: { label: "Slight rain", condition: "rain" },
  63: { label: "Moderate rain", condition: "rain" },
  65: { label: "Heavy rain", condition: "rain" },
  66: { label: "Light freezing rain", condition: "rain" },
  67: { label: "Heavy freezing rain", condition: "rain" },
  71: { label: "Slight snow", condition: "snow" },
  73: { label: "Moderate snow", condition: "snow" },
  75: { label: "Heavy snow", condition: "snow" },
  77: { label: "Snow grains", condition: "snow" },
  80: { label: "Slight rain showers", condition: "rain" },
  81: { label: "Moderate rain showers", condition: "rain" },
  82: { label: "Violent rain showers", condition: "rain" },
  85: { label: "Slight snow showers", condition: "snow" },
  86: { label: "Heavy snow showers", condition: "snow" },
  95: { label: "Thunderstorm", condition: "thunderstorm" },
  96: { label: "Thunderstorm with slight hail", condition: "thunderstorm" },
  99: { label: "Thunderstorm with heavy hail", condition: "thunderstorm" },
};

export function getCondition(code: number): string {
  return WEATHER_CODES[code]?.condition ?? "clear";
}

export function getWeatherLabel(code: number): string {
  return WEATHER_CODES[code]?.label ?? "Unknown";
}

// --- Real Imgflip meme templates ---
// Each meme uses an actual template image from Imgflip with text boxes overlaid.
// The text boxes are rendered on top of the image in the MemeCard component.

interface MemeTemplate {
  id: string; // unique identifier for this weather meme
  templateId: string; // Imgflip template ID
  templateName: string;
  templateUrl: string;
  boxCount: number;
  boxes: string[]; // text for each box
  caption: string; // human-readable caption shown below
  reactions: string[];
  vibe: string;
}

// Helper to define a meme concisely
function meme(
  id: string,
  templateId: string,
  templateName: string,
  templateUrl: string,
  boxCount: number,
  boxes: string[],
  caption: string,
  reactions: string[],
  vibe: string,
): MemeTemplate {
  return { id, templateId, templateName, templateUrl, boxCount, boxes, caption, reactions, vibe };
}

// ============ TEMPERATURE-BASED MEMES ============

const TEMP_MEMES: { min: number; max: number; memes: MemeTemplate[] }[] = [
  {
    min: -100,
    max: -10,
    memes: [
      meme(
        "arctic-drake",
        "181913649",
        "Drake Hotline Bling",
        "https://i.imgflip.com/30b1gx.jpg",
        2,
        ["Going outside in this cold", "Staying in bed with 47 blankets"],
        "When it's so cold your soul left your body and froze to the sidewalk.",
        ["🥶", "💀", "😭", "❄️"],
        "Absolutely unhinged cold",
      ),
      meme(
        "arctic-disaster-girl",
        "97984",
        "Disaster Girl",
        "https://i.imgflip.com/23ls.jpg",
        2,
        ["", "The weather forecast says -15°C"],
        "Smiling while the world freezes around you.",
        ["🥶", "💀", "😈", "❄️"],
        "Arctic survival mode",
      ),
    ],
  },
  {
    min: -10,
    max: 0,
    memes: [
      meme(
        "cold-two-buttons",
        "87743020",
        "Two Buttons",
        "https://i.imgflip.com/1g8my4.jpg",
        3,
        ["Go outside", "Stay in bed forever", "It's literally freezing"],
        "The impossible choice when it's below zero.",
        ["🥶", "🧊", "😰", "🐧"],
        "Brutally cold",
      ),
      meme(
        "cold-gru",
        "131940431",
        "Gru's Plan",
        "https://i.imgflip.com/26jxvz.jpg",
        4,
        ["Plan: Go outside", "Get dressed in 10 layers", "Step outside", "Immediately go back inside"],
        "Gru had the right idea about cold weather.",
        ["🧣", "😂", "🥶", "🚪"],
        "The Gru plan for winter",
      ),
    ],
  },
  {
    min: 0,
    max: 10,
    memes: [
      meme(
        "chilly-drake",
        "181913649",
        "Drake Hotline Bling",
        "https://i.imgflip.com/30b1gx.jpg",
        2,
        ["Complaining about the cold", "Embracing sweater season"],
        "When it's cold but not freezing — sweater weather supremacy.",
        ["🧥", "☕", "😊", "🍂"],
        "Sweater weather perfection",
      ),
      meme(
        "chilly-this-is-fine",
        "55311130",
        "This Is Fine",
        "https://i.imgflip.com/wxica.jpg",
        2,
        ["It's only 5 degrees outside", "This is fine. I have a jacket."],
        "Casually pretending the cold doesn't bother you.",
        ["🧥", "😤", "❄️", "👌"],
        "Coping with the chill",
      ),
    ],
  },
  {
    min: 10,
    max: 18,
    memes: [
      meme(
        "mild-change-my-mind",
        "129242436",
        "Change My Mind",
        "https://i.imgflip.com/24y43o.jpg",
        2,
        ["15 degrees is the perfect temperature and I will not be taking questions", ""],
        "Actually nice outside and no one can convince me otherwise.",
        ["😊", "👍", "🌿", "😌"],
        "Pleasantly mild",
      ),
    ],
  },
  {
    min: 18,
    max: 25,
    memes: [
      meme(
        "perfect-leonardo",
        "5496396",
        "Leonardo Dicaprio Cheers",
        "https://i.imgflip.com/39t1o.jpg",
        2,
        ["", "When the weather is finally 22°C and life is good"],
        "Peak human comfort temperature. Time to celebrate.",
        ["😎", "☀️", "🎉", "🙌"],
        "God-tier weather",
      ),
      meme(
        "perfect-drake",
        "181913649",
        "Drake Hotline Bling",
        "https://i.imgflip.com/30b1gx.jpg",
        2,
        ["Staying indoors on a perfect day", "Touching grass immediately"],
        "When Drake knows you should go outside.",
        ["😎", "🌿", "☀️", "🥂"],
        "Perfect day energy",
      ),
    ],
  },
  {
    min: 25,
    max: 32,
    memes: [
      meme(
        "hot-sweating-spongebob",
        "102156234",
        "Mocking Spongebob",
        "https://i.imgflip.com/1otk96.jpg",
        2,
        ["When you step outside and it's 30 degrees:", "wHeN yOu sTeP oUtSiDe aNd iT's 30 dEgReEs"],
        "The heat starts mocking you directly.",
        ["🥵", "💧", "😅", "🔥"],
        "Getting uncomfortable",
      ),
      meme(
        "hot-bike-fall",
        "79132341",
        "Bike Fall",
        "https://i.imgflip.com/1b42wl.jpg",
        3,
        ["Going outside in 30°C", "Start sweating immediately", "Go back inside"],
        "The bike fall of summer temperatures.",
        ["🥵", "😅", "💦", "🔥"],
        "Sweat zone activated",
      ),
    ],
  },
  {
    min: 32,
    max: 100,
    memes: [
      meme(
        "melting-this-is-fine",
        "55311130",
        "This Is Fine",
        "https://i.imgflip.com/wxica.jpg",
        2,
        ["It's 38°C and I'm melting", "This is fine 🔥"],
        "When the sun decided to personally attack you today.",
        ["🔥", "🫠", "💀", "🥵"],
        "Surface of the sun",
      ),
      meme(
        "melting-yall-got-any-more",
        "124055727",
        "Y'all Got Any More Of That",
        "https://i.imgflip.com/21uy0f.jpg",
        2,
        ["Y'all got any more of that", "AIR CONDITIONING"],
        "Begging for AC when it's scorching outside.",
        ["🫠", "🥵", "❄️", "💀"],
        "Dangerously hot",
      ),
      meme(
        "melting-distracted-boyfriend",
        "112126428",
        "Distracted Boyfriend",
        "https://i.imgflip.com/1ur9b0.jpg",
        3,
        ["Me", "Staying outside", "Going to the freezer section"],
        "When the supermarket freezer section becomes your sanctuary.",
        ["🔥", "😍", "🥶", "🏃"],
        "Seeking refuge in the freezer aisle",
      ),
    ],
  },
];

// ============ CONDITION-BASED MEMES ============

const CONDITION_MEMES: Record<string, MemeTemplate[]> = {
  rain: [
    meme(
      "rain-disaster-girl",
      "97984",
      "Disaster Girl",
      "https://i.imgflip.com/23ls.jpg",
      2,
      ["", "When it starts raining and you didn't bring an umbrella"],
      "Smiling menacingly at the rain because you didn't bring an umbrella.",
      ["🌧️", "😢", "🪟", "🎶"],
      "Melancholic rain mood",
    ),
    meme(
      "rain-one-does-not-simply",
      "61579",
      "One Does Not Simply",
      "https://i.imgflip.com/1bij.jpg",
      2,
      ["One does not simply", "walk outside without getting soaked"],
      "One does not simply avoid the rain.",
      ["🌧️", "😂", "🌂", "💧"],
      "Rainy day struggles",
    ),
  ],
  drizzle: [
    meme(
      "drizzle-is-this-a-pigeon",
      "100777631",
      "Is This A Pigeon",
      "https://i.imgflip.com/1o00in.jpg",
      3,
      ["Me looking at the sky", "Is this rain?", "(it's just drizzle)"],
      "When it's not quite rain but it's definitely ruining your hair.",
      ["🌦️", "😒", "💧", "🌂"],
      "Annoying drizzle",
    ),
  ],
  snow: [
    meme(
      "snow-gru",
      "131940431",
        "Gru's Plan",
      "https://i.imgflip.com/26jxvz.jpg",
      4,
      ["Look at the beautiful snow", "Build a snowman", "Realize you have to shovel the driveway", "Go back to bed"],
      "Gru's plan for snow day always ends in regret.",
      ["⛄", "❄️", "✨", "😭"],
      "Deceptively beautiful snow",
    ),
  ],
  fog: [
    meme(
      "fog-anakin",
      "322841258",
      "Anakin Padme 4 Panel",
      "https://i.imgflip.com/5c7lwq.png",
      3,
      ["I think the fog is creepy", "Is it dangerous?", "...it's just fog", "happy for you"],
      "When the fog rolls in and suddenly life is a thriller movie.",
      ["🌫️", "🕵️", "😶‍🌫️", "🤔"],
      "Mysterious and eerie",
    ),
    meme(
      "fog-is-this-a-pigeon",
      "100777631",
      "Is This A Pigeon",
      "https://i.imgflip.com/1o00in.jpg",
      3,
      ["Me looking through the fog", "Is that my car?", "(it's a tree)"],
      "When the fog is so thick you can't tell what's real anymore.",
      ["🌫️", "😱", "🌲", "🔦"],
      "Horror movie atmosphere",
    ),
  ],
  thunderstorm: [
    meme(
      "storm-epic-handshake",
      "135256802",
      "Epic Handshake",
      "https://i.imgflip.com/28j0te.jpg",
      3,
      ["Me", "Staying inside during a thunderstorm", "Free light show"],
      "When nature puts on a free concert and you didn't even buy tickets.",
      ["⛈️", "⚡", "😱", "🔥"],
      "Dramatic and electric",
    ),
    meme(
      "storm-panik",
      "226297822",
      "Panik Kalm Panik",
      "https://i.imgflip.com/3qqcim.png",
      3,
      ["panik: thunder", "kalm: it's far away", "panik: it's getting closer"],
      "The emotional rollercoaster of a thunderstorm approaching.",
      ["⚡", "😰", "😅", "😱"],
      "Storm panic cycle",
    ),
  ],
  cloudy: [
    meme(
      "cloudy-hide-pain",
      "27813981",
      "Hide the Pain Harold",
      "https://i.imgflip.com/gk5el.jpg",
      2,
      ["When it's overcast all day", "but you tell everyone you're doing great"],
      "Smiling through the gray skies because the aesthetic is on point.",
      ["☁️", "😐", "📸", "🩶"],
      "Moody overcast",
    ),
  ],
  "partly-cloudy": [
    meme(
      "partly-cloudy-x-everywhere",
      "91538330",
      "X, X Everywhere",
      "https://i.imgflip.com/1ihzfe.jpg",
      2,
      ["Clouds", "Clouds everywhere"],
      "When there's a few clouds and the meme writes itself.",
      ["⛅", "☁️", "👀", "😅"],
      "Partly cloudy, fully meme",
    ),
  ],
};

interface TrendingTemplate {
  id: string;
  name: string;
  url: string;
  box_count: number;
  captions?: number;
}

const TRENDING_FALLBACK: TrendingTemplate[] = [
  { id: "222403160", name: "Bernie Asking", url: "https://i.imgflip.com/3oevdk.jpg", box_count: 2 },
  { id: "217743513", name: "UNO Draw 25 Cards", url: "https://i.imgflip.com/3lmzyx.jpg", box_count: 2 },
  { id: "252600902", name: "Always Has Been", url: "https://i.imgflip.com/46e43q.png", box_count: 2 },
  { id: "124822590", name: "Left Exit 12 Off Ramp", url: "https://i.imgflip.com/22bdq6.jpg", box_count: 3 },
  { id: "131087935", name: "Running Away Balloon", url: "https://i.imgflip.com/261o3j.jpg", box_count: 5 },
  { id: "4087833", name: "Waiting Skeleton", url: "https://i.imgflip.com/2fm6x.jpg", box_count: 2 },
  { id: "80707627", name: "Sad Pablo Escobar", url: "https://i.imgflip.com/1c1uej.jpg", box_count: 3 },
  { id: "309868304", name: "Trade Offer", url: "https://i.imgflip.com/54hjww.jpg", box_count: 3 },
  { id: "188390779", name: "Woman Yelling At Cat", url: "https://i.imgflip.com/345v97.jpg", box_count: 2 },
  { id: "438680", name: "Batman Slapping Robin", url: "https://i.imgflip.com/9ehk.jpg", box_count: 2 },
  { id: "161865971", name: "Marked Safe From", url: "https://i.imgflip.com/2odckz.jpg", box_count: 2 },
  { id: "101470", name: "Ancient Aliens", url: "https://i.imgflip.com/26am.jpg", box_count: 2 },
  { id: "247375501", name: "Buff Doge vs Cheems", url: "https://i.imgflip.com/43a45p.png", box_count: 4 },
  { id: "177682295", name: "You Guys Are Getting Paid", url: "https://i.imgflip.com/2xscjb.png", box_count: 2 },
  { id: "180190441", name: "They're The Same Picture", url: "https://i.imgflip.com/2za3u1.jpg", box_count: 3 },
  { id: "505705955", name: "Absolute Cinema", url: "https://i.imgflip.com/8d317n.png", box_count: 2 },
  { id: "3218037", name: "Trophy If I Had One", url: "https://i.imgflip.com/1wz1x.jpg", box_count: 2 },
  { id: "67452763", name: "Squidward Window", url: "https://i.imgflip.com/145qvv.jpg", box_count: 2 },
  { id: "93895088", name: "Expanding Brain", url: "https://i.imgflip.com/1jwhww.jpg", box_count: 4 },
  { id: "28251713", name: "Oprah You Get A", url: "https://i.imgflip.com/gtj5t.jpg", box_count: 2 },
  { id: "370867422", name: "Megamind Peeking", url: "https://i.imgflip.com/64sz4u.png", box_count: 2 },
  { id: "178591752", name: "Tuxedo Winnie The Pooh", url: "https://i.imgflip.com/2ybua0.png", box_count: 2 },
  { id: "77045868", name: "Pawn Stars Best I Can Do", url: "https://i.imgflip.com/19vcz0.jpg", box_count: 2 },
  { id: "208915813", name: "George Bush 9/11", url: "https://i.imgflip.com/3gdsh1.jpg", box_count: 2 },
  { id: "110163934", name: "I Bet He's Thinking About Other Women", url: "https://i.imgflip.com/1tl71a.jpg", box_count: 2 },
  { id: "533936279", name: "Bell Curve", url: "https://i.imgflip.com/8tw3vb.png", box_count: 3 },
  { id: "148909805", name: "Monkey Puppet", url: "https://i.imgflip.com/2gnnjh.jpg", box_count: 2 },
  { id: "195515965", name: "Clown Applying Makeup", url: "https://i.imgflip.com/38el31.jpg", box_count: 4 },
  { id: "89370399", name: "Roll Safe Think About It", url: "https://i.imgflip.com/1h7in3.jpg", box_count: 2 },
  { id: "163573", name: "Imagination SpongeBob", url: "https://i.imgflip.com/3i7p.jpg", box_count: 2 },
  { id: "206151308", name: "Spider-Man Pointing", url: "https://i.imgflip.com/3eqjd8.jpg", box_count: 3 },
  { id: "84341851", name: "Evil Kermit", url: "https://i.imgflip.com/1e7ql7.jpg", box_count: 2 },
  { id: "1035805", name: "Boardroom Meeting Suggestion", url: "https://i.imgflip.com/m78d.jpg", box_count: 4 },
  { id: "61585", name: "Bad Luck Brian", url: "https://i.imgflip.com/1bip.jpg", box_count: 2 },
  { id: "259237855", name: "Laughing Leo", url: "https://i.imgflip.com/4acd7j.png", box_count: 2 },
  { id: "99683372", name: "Sleeping Shaq", url: "https://i.imgflip.com/1nck6k.jpg", box_count: 2 },
  { id: "129315248", name: "No - Yes", url: "https://i.imgflip.com/24zoa8.jpg", box_count: 2 },
  { id: "119139145", name: "Blank Nut Button", url: "https://i.imgflip.com/1yxkcp.jpg", box_count: 2 },
  { id: "29562797", name: "I'm The Captain Now", url: "https://i.imgflip.com/hlmst.jpg", box_count: 2 },
  { id: "309668311", name: "Two Paths", url: "https://i.imgflip.com/54d9lj.png", box_count: 3 },
  { id: "101288", name: "Third World Skeptical Kid", url: "https://i.imgflip.com/265k.jpg", box_count: 2 },
  { id: "61520", name: "Futurama Fry", url: "https://i.imgflip.com/1bgw.jpg", box_count: 2 },
  { id: "5496396", name: "Leonardo DiCaprio Cheers", url: "https://i.imgflip.com/39t1o.jpg", box_count: 2 },
  { id: "92084495", name: "Charlie Conspiracy", url: "https://i.imgflip.com/1itoun.jpg", box_count: 2 },
];

type MemeMood = "cold" | "hot" | "wet" | "mild";
const TRENDING_COPY: Record<LanguageCode, Record<MemeMood, [string, string]>> = {
  en: { cold: ["Forecast: stay cozy", "Cold outside, blanket inside"], hot: ["Forecast: find some shade", "Too hot for main character energy"], wet: ["Forecast: bring the umbrella", "Plans vs. the weather"], mild: ["Forecast: go touch grass", "A rare weather win"] },
  es: { cold: ["Pronóstico: quédate calentito", "Frío fuera, manta dentro"], hot: ["Pronóstico: busca sombra", "Demasiado calor para salir"], wet: ["Pronóstico: lleva paraguas", "Los planes contra el tiempo"], mild: ["Pronóstico: sal a disfrutar", "Una rara victoria del tiempo"] },
  fr: { cold: ["Prévisions : reste au chaud", "Froid dehors, plaid dedans"], hot: ["Prévisions : cherche l’ombre", "Trop chaud pour sortir"], wet: ["Prévisions : prends un parapluie", "Les plans contre la météo"], mild: ["Prévisions : profite du soleil", "Une météo enfin sympa"] },
  de: { cold: ["Prognose: gemütlich bleiben", "Draußen kalt, drinnen Decke"], hot: ["Prognose: Schatten suchen", "Zu heiß für große Pläne"], wet: ["Prognose: Schirm einpacken", "Pläne gegen das Wetter"], mild: ["Prognose: raus an die Luft", "Ein seltener Wettererfolg"] },
  it: { cold: ["Previsioni: resta al caldo", "Freddo fuori, coperta dentro"], hot: ["Previsioni: cerca l’ombra", "Troppo caldo per uscire"], wet: ["Previsioni: porta l’ombrello", "I piani contro il meteo"], mild: ["Previsioni: goditi la giornata", "Una rara vittoria del meteo"] },
  pt: { cold: ["Previsão: fique quentinho", "Frio lá fora, manta cá dentro"], hot: ["Previsão: procure sombra", "Calor demais para sair"], wet: ["Previsão: leve o guarda-chuva", "Os planos contra o tempo"], mild: ["Previsão: aproveite o dia", "Uma rara vitória do tempo"] },
  ja: { cold: ["予報：あたたかくして過ごそう", "外は寒い、室内は毛布"], hot: ["予報：日陰を探そう", "暑すぎて出かけられない"], wet: ["予報：傘を忘れずに", "予定と天気の勝負"], mild: ["予報：外を楽しもう", "珍しく天気の勝ち"] },
  zh: { cold: ["天气预报：待在温暖的地方", "外面冷，屋里盖毯子"], hot: ["天气预报：找个阴凉处", "太热了，不想出门"], wet: ["天气预报：记得带伞", "计划和天气的较量"], mild: ["天气预报：出去走走", "难得的好天气"] },
  ru: { cold: ["Прогноз: оставайся в тепле", "На улице холодно, дома плед"], hot: ["Прогноз: ищи тень", "Слишком жарко, чтобы выходить"], wet: ["Прогноз: возьми зонт", "Планы против погоды"], mild: ["Прогноз: пора на улицу", "Редкая победа погоды"] },
  ar: { cold: ["التوقعات: ابقَ دافئاً", "البرد في الخارج والبطانية في الداخل"], hot: ["التوقعات: ابحث عن الظل", "الحر شديد للخروج"], wet: ["التوقعات: أحضر مظلة", "الخطط في مواجهة الطقس"], mild: ["التوقعات: استمتع بالخارج", "طقس جميل على غير العادة"] },
  hi: { cold: ["पूर्वानुमान: गर्म रहो", "बाहर ठंड, अंदर कंबल"], hot: ["पूर्वानुमान: छाँव ढूँढो", "बाहर जाने के लिए बहुत गर्मी"], wet: ["पूर्वानुमान: छाता साथ रखो", "योजनाएँ बनाम मौसम"], mild: ["पूर्वानुमान: बाहर घूमो", "मौसम की दुर्लभ जीत"] },
  ko: { cold: ["예보: 따뜻하게 있기", "밖은 춥고 안은 포근하게"], hot: ["예보: 그늘 찾기", "나가기엔 너무 더워"], wet: ["예보: 우산 챙기기", "계획과 날씨의 대결"], mild: ["예보: 밖을 즐겨봐", "드문 날씨 승리"] },
};

const ENGLISH_RELATABLE_LINES: Record<MemeMood, string[]> = {
  cold: [
    "At {temp}, my bed has a very convincing argument.",
    "Me checking the forecast like the cold might apologize.",
    "One step outside at {temp} and my nose files a complaint.",
    "Forecast: {temp}. Plans: suddenly cancelled.",
    "The blanket-to-door distance is too far today.",
    "At {temp}, every errand becomes an expedition.",
    "Me: I love winter. Also me: absolutely not going out.",
    "Both hands are holding a hot drink. This is the plan.",
  ],
  hot: [
    "At {temp}, I went outside for 12 seconds. Never again.",
    "My phone is overheating. Same.",
    "Today's itinerary: shade, water, repeat.",
    "The cold side of the pillow is now a weather strategy.",
    "At {temp}, even the cat has moved to the tile floor.",
    "Me dressing for the heat and still somehow sweating indoors.",
    "The walk is cancelled. The fan and I have plans.",
    "Forecast says sunny. My air conditioner says overtime.",
  ],
  wet: [
    "Rain starts the second I leave my umbrella at home.",
    "Forecast said drizzle. My socks disagree.",
    "Me: nice outfit. Weather: absolutely not.",
    "The puddle is deeper than my life choices.",
    "At {temp} with rain: somehow my hair lost the whole day.",
    "It was sunny when I left. I have witnesses.",
    "Umbrella inside the house: perfect. Umbrella outside: missing.",
    "That tiny walk turned into a full laundry load.",
  ],
  mild: [
    "At {temp}, suddenly a walk sounds like a personality.",
    "Perfect weather. I will spend it indoors by accident.",
    "That one day my jacket is exactly right.",
    "Weather so nice the errands become a stroll.",
    "At {temp}, opening a window feels like self-care.",
    "No dramatic outfit decision today. The weather understood.",
    "The forecast finally matched the outfit in my head.",
    "A rare forecast that does not require a backup plan.",
  ],
};

const RELATABLE_LINES: Partial<Record<LanguageCode, Record<MemeMood, string[]>>> = {
  es: {
    cold: ["A {temp}, mi cama tiene un argumento muy convincente.", "Miro el pronóstico por si el frío se disculpa.", "Salgo un paso y mi nariz presenta una queja.", "Pronóstico: {temp}. Planes: cancelados."],
    hot: ["A {temp}, estuve fuera 12 segundos. Nunca más.", "Mi móvil se recalienta. Yo también.", "Plan de hoy: sombra, agua y repetir.", "El ventilador y yo tenemos una cita."],
    wet: ["Llueve justo cuando dejo el paraguas en casa.", "El pronóstico dijo llovizna. Mis calcetines discrepan.", "Yo: buen conjunto. El tiempo: ni hablar.", "El charco era más profundo que mis decisiones."],
    mild: ["A {temp}, pasear se vuelve toda una personalidad.", "Hace un día perfecto. Lo pasaré dentro sin querer.", "Ese día en que la chaqueta queda perfecta.", "Hasta los recados parecen un paseo."],
  },
  fr: {
    cold: ["À {temp}, mon lit a des arguments très convaincants.", "Je vérifie la météo au cas où le froid s'excuserait.", "Un pas dehors et mon nez dépose une réclamation.", "Prévisions : {temp}. Programme : annulé."],
    hot: ["À {temp}, je suis sorti 12 secondes. Plus jamais.", "Mon téléphone surchauffe. Moi aussi.", "Programme du jour : ombre, eau, recommencer.", "Le ventilateur et moi avons rendez-vous."],
    wet: ["Il pleut dès que je laisse mon parapluie à la maison.", "La météo disait bruine. Mes chaussettes ne sont pas d'accord.", "Moi : belle tenue. Météo : sûrement pas.", "La flaque était plus profonde que mes décisions."],
    mild: ["À {temp}, une promenade devient toute ma personnalité.", "Temps parfait. Je vais le passer dedans sans faire exprès.", "Le jour où ma veste est exactement la bonne.", "Même les courses ressemblent à une balade."],
  },
  de: {
    cold: ["Bei {temp} hat mein Bett sehr überzeugende Argumente.", "Ich prüfe die Vorhersage, falls sich die Kälte entschuldigt.", "Ein Schritt nach draußen und meine Nase beschwert sich.", "Prognose: {temp}. Pläne: abgesagt."],
    hot: ["Bei {temp} war ich 12 Sekunden draußen. Nie wieder.", "Mein Handy überhitzt. Ich auch.", "Tagesplan: Schatten, Wasser, wiederholen.", "Der Ventilator und ich haben ein Date."],
    wet: ["Es regnet genau dann, wenn der Schirm zu Hause bleibt.", "Prognose: Nieselregen. Meine Socken widersprechen.", "Ich: tolles Outfit. Wetter: ganz sicher nicht.", "Die Pfütze war tiefer als meine Entscheidungen."],
    mild: ["Bei {temp} wird Spazierengehen plötzlich zur Persönlichkeit.", "Perfektes Wetter. Ich verbringe es versehentlich drinnen.", "Der eine Tag, an dem die Jacke genau richtig ist.", "Selbst Besorgungen fühlen sich wie ein Spaziergang an."],
  },
  it: {
    cold: ["A {temp}, il mio letto ha argomenti molto convincenti.", "Controllo le previsioni, magari il freddo si scusa.", "Un passo fuori e il mio naso presenta un reclamo.", "Previsioni: {temp}. Piani: annullati."],
    hot: ["A {temp}, sono stato fuori 12 secondi. Mai più.", "Il telefono si surriscalda. Anch'io.", "Programma di oggi: ombra, acqua, ripetere.", "Io e il ventilatore abbiamo un appuntamento."],
    wet: ["Piove appena lascio l'ombrello a casa.", "Previsioni: pioggerella. I miei calzini dissentono.", "Io: bel vestito. Meteo: assolutamente no.", "La pozzanghera era più profonda delle mie scelte."],
    mild: ["A {temp}, una passeggiata diventa tutta la mia personalità.", "Tempo perfetto. Lo passerò in casa per sbaglio.", "Quel giorno in cui la giacca è proprio giusta.", "Anche le commissioni sembrano una passeggiata."],
  },
  pt: {
    cold: ["A {temp}, a minha cama tem argumentos muito convincentes.", "Vejo a previsão caso o frio peça desculpa.", "Dou um passo lá fora e o meu nariz faz uma reclamação.", "Previsão: {temp}. Planos: cancelados."],
    hot: ["A {temp}, estive fora 12 segundos. Nunca mais.", "O meu telemóvel aquece. Eu também.", "Plano de hoje: sombra, água, repetir.", "Eu e a ventoinha temos um encontro."],
    wet: ["Chove assim que deixo o guarda-chuva em casa.", "A previsão disse chuvisco. As minhas meias discordam.", "Eu: belo visual. Tempo: nem pensar.", "A poça era mais funda do que as minhas decisões."],
    mild: ["A {temp}, passear passa a ser toda a minha personalidade.", "Tempo perfeito. Vou passá-lo dentro de casa sem querer.", "Aquele dia em que o casaco fica mesmo bem.", "Até os recados parecem um passeio."],
  },
  ja: {
    cold: ["{temp}。ベッドの説得力がすごい。", "寒さが謝るかもと思って予報を確認中。", "一歩外に出たら鼻から苦情が来た。", "予報は{temp}。予定は中止。"],
    hot: ["{temp}で外にいたのは12秒。もう無理。", "スマホが熱い。私も。", "今日の予定：日陰、水分、繰り返し。", "扇風機とデートの約束。"],
    wet: ["傘を家に置いた瞬間に雨が降る。", "予報は小雨。靴下は納得していない。", "私：いい服。天気：それは無理。", "水たまりが人生の選択より深かった。"],
    mild: ["{temp}。散歩が急に趣味みたいになる。", "最高の天気。うっかり家で過ごす。", "上着がちょうどいい、あの一日。", "用事まで散歩に感じる天気。"],
  },
  zh: {
    cold: ["{temp}，我的床说服力太强了。", "看看天气预报，等冷空气道歉。", "刚出门一步，鼻子就开始投诉。", "预报：{temp}。计划：取消。"],
    hot: ["{temp}，我只在外面待了12秒。再也不。", "手机发烫。我也是。", "今日安排：找阴凉、喝水、再来一次。", "我和风扇约好了。"],
    wet: ["我刚把伞留在家里，雨就来了。", "预报说毛毛雨。我的袜子不同意。", "我：穿得真好看。天气：不行。", "水坑比我做过的决定还深。"],
    mild: ["{temp}，散步突然成了我的人设。", "天气完美。我却不小心待在室内。", "外套刚刚好的那一天。", "连办事都像在散步。"],
  },
  ru: {
    cold: ["При {temp} у кровати слишком убедительные доводы.", "Проверяю прогноз: вдруг холод извинится.", "Шаг на улицу — и нос уже подал жалобу.", "Прогноз: {temp}. Планы: отменены."],
    hot: ["При {temp} я был на улице 12 секунд. Хватит.", "Телефон перегрелся. Я тоже.", "План на день: тень, вода, повторить.", "У меня с вентилятором свидание."],
    wet: ["Дождь начинается, как только зонт остаётся дома.", "В прогнозе морось. Носки не согласны.", "Я: отличный наряд. Погода: нет.", "Лужа глубже моих жизненных решений."],
    mild: ["При {temp} прогулка внезапно становится характером.", "Идеальная погода. Я случайно проведу её дома.", "Тот день, когда куртка в самый раз.", "Даже дела похожи на прогулку."],
  },
  ar: {
    cold: ["عند {temp}، سريري يملك حججاً مقنعة جداً.", "أراجع التوقعات لعل البرد يعتذر.", "خطوة واحدة للخارج وأنفي يقدم شكوى.", "التوقعات: {temp}. الخطط: أُلغيت."],
    hot: ["عند {temp}، بقيت بالخارج 12 ثانية. لن أكررها.", "هاتفي ساخن. وأنا أيضاً.", "خطة اليوم: ظل، ماء، ثم نكرر.", "لدي موعد مع المروحة."],
    wet: ["يبدأ المطر لحظة أترك المظلة في المنزل.", "التوقعات قالت رذاذاً. جواربي تعترض.", "أنا: ملابس جميلة. الطقس: مستحيل.", "البركة أعمق من قراراتي."],
    mild: ["عند {temp}، تصبح النزهة شخصيتي بالكامل.", "طقس مثالي. سأقضيه في الداخل بالخطأ.", "ذلك اليوم الذي تكون فيه سترتي مناسبة تماماً.", "حتى المشاوير تبدو كأنها نزهة."],
  },
  hi: {
    cold: ["{temp} पर मेरा बिस्तर बहुत अच्छे तर्क देता है।", "पूर्वानुमान देखता हूँ, शायद ठंड माफी माँगे।", "बाहर एक कदम और मेरी नाक शिकायत करती है।", "पूर्वानुमान: {temp}। योजनाएँ: रद्द।"],
    hot: ["{temp} में बाहर 12 सेकंड रहा। अब कभी नहीं।", "मेरा फोन गर्म हो रहा है। मैं भी।", "आज का प्लान: छाँव, पानी, फिर दोहराएँ।", "पंखे के साथ मेरी मुलाकात तय है।"],
    wet: ["छाता घर छोड़ते ही बारिश शुरू हो जाती है।", "पूर्वानुमान में बूंदाबांदी थी। मोज़े नहीं मानते।", "मैं: बढ़िया कपड़े। मौसम: बिल्कुल नहीं।", "गड्ढा मेरे फैसलों से भी गहरा था।"],
    mild: ["{temp} पर अचानक टहलना मेरी पूरी पहचान है।", "मौसम बढ़िया है। मैं गलती से घर में रहूँगा।", "वह दिन जब जैकेट बिल्कुल सही लगती है।", "काम भी आज सैर जैसे लगते हैं।"],
  },
  ko: {
    cold: ["{temp}도, 침대의 설득력이 너무 강해.", "추위가 사과할까 봐 예보를 확인 중.", "한 걸음 나가자 코가 항의했다.", "예보: {temp}. 약속: 취소."],
    hot: ["{temp}에 밖에 12초 있었어. 다시는 안 나가.", "휴대폰이 뜨거워. 나도.", "오늘 계획: 그늘, 물, 반복.", "선풍기와 약속이 있어."],
    wet: ["우산을 집에 두고 나오자마자 비가 온다.", "예보는 이슬비. 양말은 동의하지 않는다.", "나: 멋진 옷. 날씨: 안 돼.", "웅덩이가 내 선택보다 깊었다."],
    mild: ["{temp}에 산책이 갑자기 내 캐릭터가 됐다.", "날씨가 완벽해. 실수로 집에만 있겠지.", "재킷이 딱 맞는 바로 그날.", "볼일도 산책처럼 느껴지는 날씨."],
  },
};

const TRENDING_REACTIONS = ["😂", "🌦️", "😅", "🫠", "🤷"];
let trendingCache: MemeTemplate[] | null = null;
let trendingRequest: Promise<MemeTemplate[]> | null = null;

export async function loadTrendingMemes(): Promise<MemeTemplate[]> {
  if (trendingCache) return trendingCache;
  if (trendingRequest) return trendingRequest;
  trendingRequest = (async () => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 8000);
    try {
      const endpoint = window.location.protocol === "memeweather:"
        ? new URL("/api/trending-memes", window.location.href).toString()
        : "/api/trending-memes";
      const response = await fetch(endpoint, { signal: controller.signal });
      if (!response.ok) throw new Error("Trending templates are unavailable");
      const result = await response.json() as { success?: boolean; data?: { memes?: TrendingTemplate[] } };
      const remote = result.success && Array.isArray(result.data?.memes) ? result.data.memes : [];
      const valid = remote.filter((item) => item.id && item.name && item.box_count > 0 && /^https:\/\/i\.imgflip\.com\//.test(item.url));
      const templates = valid.slice(0, 100).map((item) => meme(
        `imgflip-${item.id}`, item.id, item.name, item.url, item.box_count,
        Array.from({ length: Math.min(item.box_count, 4) }, () => ""),
        "", TRENDING_REACTIONS, "",
      ));
      trendingCache = templates.length >= 12 ? templates : fallbackTrendingTemplates();
    } catch {
      trendingCache = fallbackTrendingTemplates();
    } finally {
      window.clearTimeout(timeout);
      trendingRequest = null;
    }
    return trendingCache;
  })();
  return trendingRequest;
}

function fallbackTrendingTemplates(): MemeTemplate[] {
  return TRENDING_FALLBACK.map((item) => meme(
    `imgflip-${item.id}`, item.id, item.name, item.url, item.box_count,
    Array.from({ length: Math.min(item.box_count, 4) }, () => ""), "", TRENDING_REACTIONS, "",
  ));
}

function sample<T>(items: T[], count: number): T[] {
  const pool = [...items];
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, count);
}

export function getMemesForWeather(tempC: number, condition: string, language: LanguageCode = "en", trendingCount = 4, unit: TempUnit = "C"): WeatherMeme[] {
  const result: WeatherMeme[] = [];
  const usedTemplateIds = new Set<string>();

  for (const band of TEMP_MEMES) {
    if (tempC >= band.min && tempC < band.max) {
      const choices = sample(band.memes, Math.min(2, band.memes.length));
      choices.forEach((item) => {
        usedTemplateIds.add(item.templateId);
        result.push(templateToMeme(item));
      });
      break;
    }
  }

  const conditionMemes = sample(
    (CONDITION_MEMES[condition] ?? []).filter((item) => !usedTemplateIds.has(item.templateId)),
    2,
  );
  conditionMemes.forEach((item) => {
    usedTemplateIds.add(item.templateId);
    result.push(templateToMeme(item));
  });

  const mood: MemeMood = tempC <= 10 ? "cold" : tempC >= 25 ? "hot" : condition === "rain" || condition === "drizzle" || condition === "snow" || condition === "thunderstorm" ? "wet" : "mild";
  const copy = TRENDING_COPY[language] ?? TRENDING_COPY.en;
  const shownTemp = unit === "F" ? tempC * 9 / 5 + 32 : tempC;
  const formattedTemp = new Intl.NumberFormat(language, { maximumFractionDigits: 0 }).format(shownTemp);
  const tempLabel = `${formattedTemp}°${unit}`;
  let recent: string[] = [];
  try {
    recent = JSON.parse(localStorage.getItem("memeweather-recent-imgflip") || "[]") as string[];
  } catch {
    recent = [];
  }
  const prior = new Set(recent);
  const templates = trendingCache ?? fallbackTrendingTemplates();
  let candidates = templates.filter((item) => !usedTemplateIds.has(item.templateId) && !prior.has(item.id));
  if (candidates.length < trendingCount) candidates = templates.filter((item) => !usedTemplateIds.has(item.templateId));
  const selected = sample(candidates, trendingCount);
  const [weatherPhrase, moodPhrase] = copy[mood];
  const localizedRelatableLines = language === "en" ? ENGLISH_RELATABLE_LINES : RELATABLE_LINES[language];
  const relatablePhrases = [...new Set((localizedRelatableLines?.[mood] ?? []).map((line) => line.replace(/\{temp\}/g, tempLabel)))];
  const genericPhrases = [
        weatherPhrase,
        moodPhrase,
        `${weatherPhrase} · ${tempLabel}`,
        `${tempLabel}: ${moodPhrase}`,
        `${moodPhrase} — ${tempLabel}`,
        `${weatherPhrase}! ${moodPhrase}`,
        `${moodPhrase}… ${tempLabel}`,
        `${tempLabel} · ${weatherPhrase}`,
      ];
  const uniqueGenericPhrases = [...new Set(genericPhrases.filter((phrase) => !relatablePhrases.includes(phrase)))];
  const uniquePhrases = [
    ...sample(relatablePhrases, Math.min(selected.length, relatablePhrases.length)),
    ...sample(uniqueGenericPhrases, Math.max(0, selected.length - relatablePhrases.length)),
  ];
  for (const [index, template] of selected.entries()) {
    const phrase = uniquePhrases[index] ?? `${weatherPhrase} · ${tempLabel}`;
    result.push({
      id: template.id,
      title: template.templateName,
      caption: phrase,
      imageUrl: template.templateUrl,
      overlayText: [phrase],
      reactions: TRENDING_REACTIONS,
      vibe: `${moodPhrase} · ${tempLabel}`,
    });
  }
  try {
    localStorage.setItem("memeweather-recent-imgflip", JSON.stringify([...recent, ...selected.map((item) => item.id)].slice(-16)));
  } catch {
    // Random selection still works when browser storage is unavailable.
  }

  return sample(result, result.length);
}

function templateToMeme(t: MemeTemplate): WeatherMeme {
  return {
    id: t.id,
    title: t.templateName,
    caption: t.caption,
    imageUrl: t.templateUrl,
    overlayText: t.boxes,
    reactions: t.reactions,
    vibe: t.vibe,
  };
}

export function getVibeSummary(tempC: number, condition: string): string {
  const tempBand = TEMP_MEMES.find((b) => tempC >= b.min && tempC < b.max);
  const tempVibe = tempBand?.memes[0]?.vibe ?? "";
  const condMemes = CONDITION_MEMES[condition];
  const condVibe = condMemes?.[0]?.vibe ?? "";

  if (tempVibe && condVibe) return `${tempVibe} — ${condVibe}`;
  return tempVibe || condVibe || "Just weather being weather";
}

// Animation configuration for the current weather
export interface AnimationConfig {
  shake: "none" | "mild" | "strong";
  layers: string[]; // CSS classes for overlay layers
  shimmer: string; // CSS class for content shimmer (applied to content wrapper, not root)
}

export function getAnimationConfig(tempC: number, condition: string, windSpeed?: number, precipitation = 0, isDay = true): AnimationConfig {
  if (condition === "thunderstorm") {
    return { shake: "none", layers: ["anim-layer-rain-tint", "anim-layer-rain-fall", ...(precipitation >= 2 ? ["anim-layer-rain-heavy"] : []), "anim-layer-lightning"], shimmer: "" };
  }
  if (condition === "rain" || condition === "drizzle") {
    return { shake: "none", layers: ["anim-layer-rain-tint", "anim-layer-rain-fall", ...(precipitation >= 2 ? ["anim-layer-rain-heavy"] : []), ...(windSpeed && windSpeed > 25 ? ["anim-layer-rain-wind"] : [])], shimmer: "" };
  }
  if (condition === "snow") {
    return { shake: "none", layers: ["anim-layer-snow-tint", "anim-layer-snow-fall"], shimmer: "" };
  }
  if (condition === "fog") {
    return { shake: "none", layers: ["anim-layer-fog-1"], shimmer: "" };
  }
  if (!isDay) {
    return { shake: "none", layers: ["anim-layer-night"], shimmer: "" };
  }
  if (condition === "cloudy") {
    return { shake: "none", layers: ["anim-layer-cloudy"], shimmer: "" };
  }
  if (tempC <= 0) {
    return { shake: "none", layers: ["anim-layer-cold"], shimmer: "" };
  }
  if (tempC <= 10) {
    const layers = ["anim-layer-cold-mild"];
    if (windSpeed && windSpeed > 25) layers.push("anim-layer-wind-streaks");
    return { shake: "none", layers, shimmer: "" };
  }
  if (tempC >= 32) {
    return { shake: "none", layers: ["anim-layer-scorching", "anim-layer-sun-rays"], shimmer: "" };
  }
  if (tempC >= 25) {
    return { shake: "none", layers: ["anim-layer-hot", "anim-layer-sun-rays"], shimmer: "" };
  }
  if (tempC >= 18 && tempC < 25) {
    return { shake: "none", layers: ["anim-layer-perfect", "anim-layer-sun-rays"], shimmer: "" };
  }
  return { shake: "none", layers: ["anim-layer-clear", "anim-layer-sun-rays"], shimmer: "" };
}

// Kept for backward compatibility
export function getAnimationClass(tempC: number, condition: string): string {
  if (condition === "thunderstorm") return "anim-thunderstorm";
  if (condition === "rain" || condition === "drizzle") return "anim-rain";
  if (condition === "snow") return "anim-snow";
  if (condition === "fog") return "anim-fog";
  if (tempC <= 0) return "anim-freezing";
  if (tempC <= 10) return "anim-cold";
  if (tempC >= 32) return "anim-scorching";
  if (tempC >= 25) return "anim-hot";
  if (tempC >= 18 && tempC < 25) return "anim-perfect";
  return "anim-clear";
}
