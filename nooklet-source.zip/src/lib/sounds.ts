const BASE = "https://www.myinstants.com/media/sounds";

export type SoundName =
  | "bruh"
  | "vineBoom"
  | "emotionalDamage"
  | "wow"
  | "tada"
  | "crickets"
  | "applause"
  | "sadViolin"
  | "fart"
  | "dunDunDun";

const SOUND_URLS: Record<SoundName, string> = {
  bruh: `${BASE}/bruh-sound-effect_WstdzdM.mp3`,
  vineBoom: `${BASE}/bass-drop-vine-boom.mp3`,
  emotionalDamage: `${BASE}/emotional-damage-meme.mp3`,
  wow: `${BASE}/anime-wow-sound-effect.mp3`,
  tada: `${BASE}/joker-tada.mp3`,
  crickets: `${BASE}/awkward-cricket-sound-effect.mp3`,
  applause: `${BASE}/aplause-loud.mp3`,
  sadViolin: `${BASE}/air-horn-sad-violin-preview-mp3cut_1.mp3`,
  fart: `${BASE}/fart-meme-sound.mp3`,
  dunDunDun: `${BASE}/dun-dun-dun-sound-effect-brass_8nFBccR.mp3`,
};

const audioCache: Partial<Record<SoundName, HTMLAudioElement>> = {};

function getAudio(name: SoundName): HTMLAudioElement {
  if (!audioCache[name]) {
    const audio = new Audio(SOUND_URLS[name]);
    audio.preload = "none";
    audio.volume = 0.5;
    audioCache[name] = audio;
  }
  return audioCache[name]!;
}

let enabled = true;

export function setSoundEnabled(on: boolean) {
  enabled = on;
}

export function isSoundEnabled() {
  return enabled;
}

export function playSound(name: SoundName) {
  if (!enabled) return;
  try {
    const audio = getAudio(name);
    audio.currentTime = 0;
    audio.play().catch(() => {
      // Autoplay policy — user must interact first; ignore errors
    });
  } catch {
    // Audio not supported
  }
}

export function pickRandomSound(names: SoundName[]): SoundName {
  return names[Math.floor(Math.random() * names.length)];
}
