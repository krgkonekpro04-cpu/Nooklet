export type TempUnit = "C" | "F";

export function celsiusToFahrenheit(c: number): number {
  return (c * 9) / 5 + 32;
}

export function formatTemp(celsius: number, unit: TempUnit): string {
  if (unit === "F") return `${Math.round(celsiusToFahrenheit(celsius))}°F`;
  return `${Math.round(celsius)}°C`;
}

export function formatTempShort(celsius: number, unit: TempUnit): string {
  if (unit === "F") return `${Math.round(celsiusToFahrenheit(celsius))}°`;
  return `${Math.round(celsius)}°`;
}

export function kmhToMph(kmh: number): number {
  return kmh * 0.621371;
}

export function formatWind(kmh: number, unit: TempUnit): string {
  if (unit === "F") return `${Math.round(kmhToMph(kmh))} mph`;
  return `${Math.round(kmh)} km/h`;
}
