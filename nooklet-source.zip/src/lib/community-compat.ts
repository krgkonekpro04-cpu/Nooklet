export function isMissingColumn(error: unknown, column: string): boolean {
  if (!error || typeof error !== "object") return false;
  const record = error as { code?: string; message?: string; details?: string; hint?: string };
  const message = [record.message, record.details, record.hint].filter(Boolean).join(" ").toLowerCase();
  return (record.code === "42703" || record.code === "PGRST204" || message.includes("does not exist") || message.includes("schema cache"))
    && message.includes(column.toLowerCase());
}

export function getCommunityError(error: unknown, fallback: string): string {
  if (error instanceof Error && error.message) return error.message;
  if (error && typeof error === "object" && "message" in error && typeof error.message === "string") return error.message;
  return fallback;
}
