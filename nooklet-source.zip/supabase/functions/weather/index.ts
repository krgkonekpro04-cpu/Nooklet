const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface GeoResult {
  name: string;
  latitude: number;
  longitude: number;
  country: string;
  admin1?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const lat = url.searchParams.get("lat");
    const lon = url.searchParams.get("lon");
    const city = url.searchParams.get("city");
    const lang = url.searchParams.get("lang") || "en";

    // If searching by city name, geocode first
    if (city && !lat) {
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=${lang}&format=json`;
      const geoRes = await fetch(geoUrl);
      if (!geoRes.ok) {
        return new Response(
          JSON.stringify({ error: "Geocoding failed" }),
          { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const geoData = await geoRes.json();
      if (!geoData.results || geoData.results.length === 0) {
        return new Response(
          JSON.stringify({ error: `City "${city}" not found` }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const result: GeoResult = geoData.results[0];
      return new Response(
        JSON.stringify({
          lat: result.latitude,
          lon: result.longitude,
          name: result.name,
          country: result.country,
          admin1: result.admin1,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    if (!lat || !lon) {
      return new Response(
        JSON.stringify({ error: "Missing lat/lon or city parameter" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Open-Meteo free API — no key needed. Includes current + hourly + daily forecast.
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl,cloud_cover,uv_index&hourly=temperature_2m,weather_code,precipitation_probability&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,uv_index_max,sunrise,sunset&timezone=auto&forecast_days=5`;

    const weatherRes = await fetch(weatherUrl);
    if (!weatherRes.ok) {
      const errText = await weatherRes.text();
      return new Response(
        JSON.stringify({ error: `Weather API error: ${errText}` }),
        { status: weatherRes.status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const data = await weatherRes.json();

    return new Response(
      JSON.stringify(data),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
