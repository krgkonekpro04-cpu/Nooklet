-- Add square, user-uploaded profile images while keeping emoji avatars as fallback.
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS avatar_url text;

-- Posts and replies denormalize the current avatar for quick display.
ALTER TABLE public.forum_posts
  ADD COLUMN IF NOT EXISTS avatar_url text;

ALTER TABLE public.forum_replies
  ADD COLUMN IF NOT EXISTS avatar_url text;
