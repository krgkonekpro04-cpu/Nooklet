/*
# Add forum_likes table for one-like-per-user

## Overview
Currently forum post reactions are stored as a jsonb map on forum_posts, which
allows unlimited reactions from the same user. This migration adds a dedicated
forum_likes table that enforces one like per user per post via a unique constraint.

## New Tables
1. `forum_likes`
   - `id` (uuid, PK)
   - `post_id` (uuid, FK to forum_posts ON DELETE CASCADE)
   - `user_id` (uuid, FK to auth.users ON DELETE CASCADE, default auth.uid())
   - `created_at` (timestamptz)
   - Unique constraint on (post_id, user_id) — prevents duplicate likes

## Security
- RLS enabled on forum_likes
- SELECT: authenticated can read all likes (to show who liked)
- INSERT: authenticated can only insert their own like
- DELETE: authenticated can only delete their own like

## Notes
1. The unique constraint on (post_id, user_id) is the key enforcement —
   a user physically cannot insert two rows for the same post.
2. The frontend will toggle likes by inserting or deleting rows.
*/

CREATE TABLE IF NOT EXISTS forum_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_likes ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "likes_select_all" ON forum_likes;
CREATE POLICY "likes_select_all" ON forum_likes FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "likes_insert_own" ON forum_likes;
CREATE POLICY "likes_insert_own" ON forum_likes FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "likes_delete_own" ON forum_likes;
CREATE POLICY "likes_delete_own" ON forum_likes FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Unique constraint: one like per user per post
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'unique_like_per_user'
  ) THEN
    ALTER TABLE forum_likes ADD CONSTRAINT unique_like_per_user UNIQUE (post_id, user_id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_forum_likes_post_id ON forum_likes(post_id);
