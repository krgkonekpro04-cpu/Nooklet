-- Optional, per-account Nooklet workspace backup for cross-device restore.
-- The app only uploads a snapshot after the signed-in user presses Sync.
CREATE TABLE IF NOT EXISTS public.nooklet_workspace_snapshots (
  account_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  snapshot jsonb NOT NULL CHECK (jsonb_typeof(snapshot) = 'object'),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.nooklet_workspace_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "nooklet_snapshots_read_own" ON public.nooklet_workspace_snapshots;
CREATE POLICY "nooklet_snapshots_read_own"
  ON public.nooklet_workspace_snapshots FOR SELECT TO authenticated
  USING (auth.uid() = account_id);

DROP POLICY IF EXISTS "nooklet_snapshots_insert_own" ON public.nooklet_workspace_snapshots;
CREATE POLICY "nooklet_snapshots_insert_own"
  ON public.nooklet_workspace_snapshots FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = account_id);

DROP POLICY IF EXISTS "nooklet_snapshots_update_own" ON public.nooklet_workspace_snapshots;
CREATE POLICY "nooklet_snapshots_update_own"
  ON public.nooklet_workspace_snapshots FOR UPDATE TO authenticated
  USING (auth.uid() = account_id)
  WITH CHECK (auth.uid() = account_id);

GRANT SELECT, INSERT, UPDATE ON public.nooklet_workspace_snapshots TO authenticated;
