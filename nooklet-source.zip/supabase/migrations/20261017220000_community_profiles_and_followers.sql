-- Community profiles, follow counts, and reliable public profile photo access.

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE public.forum_posts ADD COLUMN IF NOT EXISTS avatar_url text;
ALTER TABLE public.forum_replies ADD COLUMN IF NOT EXISTS avatar_url text;

CREATE TABLE IF NOT EXISTS public.forum_follows (
  follower_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  followed_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_id, followed_id),
  CONSTRAINT forum_follows_no_self_follow CHECK (follower_id <> followed_id)
);

ALTER TABLE public.forum_follows ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "follows_select_all" ON public.forum_follows;
CREATE POLICY "follows_select_all" ON public.forum_follows
  FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "follows_insert_own" ON public.forum_follows;
CREATE POLICY "follows_insert_own" ON public.forum_follows
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = follower_id AND follower_id <> followed_id);
DROP POLICY IF EXISTS "follows_delete_own" ON public.forum_follows;
CREATE POLICY "follows_delete_own" ON public.forum_follows
  FOR DELETE TO authenticated USING (auth.uid() = follower_id);

CREATE INDEX IF NOT EXISTS idx_forum_follows_followed_id
  ON public.forum_follows(followed_id);

CREATE OR REPLACE FUNCTION public.get_forum_profile_stats(target_user_id uuid)
RETURNS TABLE(post_count bigint, subscriber_count bigint, total_likes bigint)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT
    (SELECT count(*) FROM public.forum_posts p WHERE p.user_id = target_user_id),
    (SELECT count(*) FROM public.forum_follows f WHERE f.followed_id = target_user_id),
    (SELECT count(*)
      FROM public.forum_likes l
      JOIN public.forum_posts p ON p.id = l.post_id
      WHERE p.user_id = target_user_id);
$$;

GRANT EXECUTE ON FUNCTION public.get_forum_profile_stats(uuid) TO authenticated;

-- Make sure the image bucket remains public so avatar/post thumbnail URLs load
-- in community cards and profiles. Uploads remain restricted to each user's folder.
INSERT INTO storage.buckets (id, name, public)
VALUES ('forum-photos', 'forum-photos', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS "forum_photos_read_all" ON storage.objects;
DROP POLICY IF EXISTS "forum_photos_upload_auth" ON storage.objects;
DROP POLICY IF EXISTS "forum_photos_delete_own" ON storage.objects;
DROP POLICY IF EXISTS "forum_photos_upload_own_folder" ON storage.objects;
DROP POLICY IF EXISTS "forum_photos_delete_own_folder" ON storage.objects;

CREATE POLICY "forum_photos_read_all" ON storage.objects
  FOR SELECT TO public USING (bucket_id = 'forum-photos');
CREATE POLICY "forum_photos_upload_own_folder" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'forum-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "forum_photos_delete_own_folder" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'forum-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
