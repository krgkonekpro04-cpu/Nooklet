/*
# Create meme_reactions table (single-tenant, no auth)

1. New Tables
- `meme_reactions`
  - `id` (uuid, primary key)
  - `meme_id` (text, not null) — identifies which weather meme was reacted to
  - `reaction` (text, not null) — the emoji reaction string (e.g. "😂", "💀", "🔥")
  - `created_at` (timestamptz, default now())
2. Security
- Enable RLS on `meme_reactions`.
- Allow anon + authenticated CRUD because the data is intentionally shared/public (no sign-in screen).
3. Notes
- This is a single-tenant app with no auth — anyone can react to memes and see aggregate counts.
- Reactions are grouped by `meme_id` to show global totals across all users.
*/

CREATE TABLE IF NOT EXISTS meme_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  meme_id text NOT NULL,
  reaction text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_meme_reactions_meme_id ON meme_reactions(meme_id);

ALTER TABLE meme_reactions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_reactions" ON meme_reactions;
CREATE POLICY "anon_select_reactions" ON meme_reactions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reactions" ON meme_reactions;
CREATE POLICY "anon_insert_reactions" ON meme_reactions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_reactions" ON meme_reactions;
CREATE POLICY "anon_delete_reactions" ON meme_reactions FOR DELETE
  TO anon, authenticated USING (true);
