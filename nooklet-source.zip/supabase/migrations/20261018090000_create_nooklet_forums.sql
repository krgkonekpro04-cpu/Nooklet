-- Nooklet: independent small forums with their own discussion feeds.

CREATE TABLE IF NOT EXISTS public.forums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (char_length(name) BETWEEN 2 AND 48),
  slug text NOT NULL UNIQUE,
  description text NOT NULL CHECK (char_length(description) BETWEEN 4 AND 240),
  topic text NOT NULL DEFAULT 'Other',
  emoji text NOT NULL DEFAULT '🪴',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.forums ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "forums_read_signed_in" ON public.forums;
CREATE POLICY "forums_read_signed_in" ON public.forums
  FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "forums_create_signed_in" ON public.forums;
CREATE POLICY "forums_create_signed_in" ON public.forums
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
DROP POLICY IF EXISTS "forums_edit_owner" ON public.forums;
CREATE POLICY "forums_edit_owner" ON public.forums
  FOR UPDATE TO authenticated USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);
DROP POLICY IF EXISTS "forums_delete_owner" ON public.forums;
CREATE POLICY "forums_delete_owner" ON public.forums
  FOR DELETE TO authenticated USING (auth.uid() = created_by);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.forums TO authenticated;

-- A shared starter space keeps existing forum posts available after the update.
INSERT INTO public.forums (id, name, slug, description, topic, emoji)
VALUES (
  '11111111-1111-4111-8111-111111111111',
  'The Commons',
  'the-commons',
  'A friendly place to introduce yourself, share what you are into, and find your people.',
  'Other',
  '🪴'
)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.forum_posts
  ADD COLUMN IF NOT EXISTS forum_id uuid REFERENCES public.forums(id) ON DELETE CASCADE;

UPDATE public.forum_posts
SET forum_id = '11111111-1111-4111-8111-111111111111'
WHERE forum_id IS NULL;

ALTER TABLE public.forum_posts ALTER COLUMN forum_id SET NOT NULL;
CREATE INDEX IF NOT EXISTS idx_forum_posts_forum_created
  ON public.forum_posts(forum_id, created_at DESC);

COMMENT ON TABLE public.forums IS 'Independent Nooklet communities, each with a focused discussion feed.';
