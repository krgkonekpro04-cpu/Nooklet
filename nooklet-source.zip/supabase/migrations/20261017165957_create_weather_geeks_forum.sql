/*
# Create Weather Geeks Community Forum

## Overview
This migration creates the database tables for a community forum called "Weather Geeks"
where authenticated users can post about weather, reply to posts, and upload photos.

## New Tables

1. `profiles`
   - `id` (uuid, PK, references auth.users) — the user's auth ID
   - `username` (text, unique, not null) — display name in the forum
   - `avatar_emoji` (text, default '🌤️') — emoji avatar for the user
   - `created_at` (timestamptz)

2. `forum_posts`
   - `id` (uuid, PK)
   - `user_id` (uuid, not null, default auth.uid(), references auth.users)
   - `username` (text, not null) — denormalized for fast display
   - `avatar_emoji` (text, not null, default '🌤️') — denormalized for fast display
   - `location_name` (text) — weather location the post is about
   - `weather_summary` (text) — short weather description at post time
   - `temperature` (text) — temperature string at post time
   - `body` (text, not null) — the message text
   - `photo_url` (text) — optional uploaded photo URL (Supabase Storage)
   - `reactions` (jsonb, default '{}') — map of emoji to count
   - `reply_count` (integer, default 0) — cached count of replies
   - `created_at` (timestamptz, default now())

3. `forum_replies`
   - `id` (uuid, PK)
   - `post_id` (uuid, not null, references forum_posts ON DELETE CASCADE)
   - `user_id` (uuid, not null, default auth.uid(), references auth.users)
   - `username` (text, not null) — denormalized
   - `avatar_emoji` (text, not null, default '🌤️') — denormalized
   - `body` (text, not null) — reply text
   - `photo_url` (text) — optional photo
   - `created_at` (timestamptz, default now())

## Security — RLS

### profiles
- SELECT: authenticated users can read all profiles (forum is visible to logged-in users)
- INSERT: a user can only insert their own profile
- UPDATE: a user can only update their own profile

### forum_posts
- SELECT: authenticated users can read all posts (public forum)
- INSERT: authenticated users can only insert their own posts
- UPDATE: users can only update their own posts (e.g., reactions)
- DELETE: users can only delete their own posts

### forum_replies
- SELECT: authenticated users can read all replies
- INSERT: authenticated users can only insert their own replies
- DELETE: users can only delete their own replies
- UPDATE: users can only update their own replies

## Storage
A public storage bucket `forum-photos` is created for user-uploaded photos.
Policies allow authenticated users to upload and read photos.

## Notes
1. Owner columns default to auth.uid() so frontend inserts that omit user_id still pass RLS.
2. Denormalized username/avatar_emoji on posts/replies avoids joins for display.
3. reply_count on forum_posts is maintained by triggers for performance.
*/

-- === PROFILES ===
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  avatar_emoji text NOT NULL DEFAULT '🌤️',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- === FORUM POSTS ===
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  avatar_emoji text NOT NULL DEFAULT '🌤️',
  location_name text,
  weather_summary text,
  temperature text,
  body text NOT NULL,
  photo_url text,
  reactions jsonb NOT NULL DEFAULT '{}'::jsonb,
  reply_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "posts_select_all" ON forum_posts;
CREATE POLICY "posts_select_all" ON forum_posts FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "posts_insert_own" ON forum_posts;
CREATE POLICY "posts_insert_own" ON forum_posts FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "posts_update_own" ON forum_posts;
CREATE POLICY "posts_update_own" ON forum_posts FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "posts_delete_own" ON forum_posts;
CREATE POLICY "posts_delete_own" ON forum_posts FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- === FORUM REPLIES ===
CREATE TABLE IF NOT EXISTS forum_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES forum_posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL,
  avatar_emoji text NOT NULL DEFAULT '🌤️',
  body text NOT NULL,
  photo_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE forum_replies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "replies_select_all" ON forum_replies;
CREATE POLICY "replies_select_all" ON forum_replies FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "replies_insert_own" ON forum_replies;
CREATE POLICY "replies_insert_own" ON forum_replies FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "replies_update_own" ON forum_replies;
CREATE POLICY "replies_update_own" ON forum_replies FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "replies_delete_own" ON forum_replies;
CREATE POLICY "replies_delete_own" ON forum_replies FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- === INDEXES ===
CREATE INDEX IF NOT EXISTS idx_forum_posts_created_at ON forum_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_forum_replies_post_id ON forum_replies(post_id, created_at);

-- === TRIGGER: auto-create profile on signup ===
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'weather_geek_' || substr(NEW.id::text, 1, 6))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- === TRIGGER: update reply_count on forum_posts ===
CREATE OR REPLACE FUNCTION update_reply_count()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.forum_posts SET reply_count = reply_count + 1 WHERE id = NEW.post_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.forum_posts SET reply_count = reply_count - 1 WHERE id = OLD.post_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS on_reply_insert ON forum_replies;
CREATE TRIGGER on_reply_insert
  AFTER INSERT ON forum_replies
  FOR EACH ROW EXECUTE FUNCTION update_reply_count();

DROP TRIGGER IF EXISTS on_reply_delete ON forum_replies;
CREATE TRIGGER on_reply_delete
  AFTER DELETE ON forum_replies
  FOR EACH ROW EXECUTE FUNCTION update_reply_count();

-- === STORAGE BUCKET ===
INSERT INTO storage.buckets (id, name, public)
VALUES ('forum-photos', 'forum-photos', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: authenticated users can upload, everyone can read
DROP POLICY IF EXISTS "forum_photos_read_all" ON storage.objects;
CREATE POLICY "forum_photos_read_all" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'forum-photos');

DROP POLICY IF EXISTS "forum_photos_upload_auth" ON storage.objects;
CREATE POLICY "forum_photos_upload_auth" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'forum-photos');

DROP POLICY IF EXISTS "forum_photos_delete_own" ON storage.objects;
CREATE POLICY "forum_photos_delete_own" ON storage.objects
  FOR DELETE TO authenticated USING (bucket_id = 'forum-photos' AND owner = auth.uid());
